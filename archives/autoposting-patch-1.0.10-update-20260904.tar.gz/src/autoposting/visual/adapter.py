from __future__ import annotations

import re
from typing import Any, Iterable

from .marks import is_author_avatar

GENERIC_HOW = ("安装步骤和文档", "文档在项目主页", "开源仓库，安装", "打开仓库按文档")
LATIN_RE = re.compile(r"[A-Za-z]")
CJK_RE = re.compile(r"[\u3400-\u9fff]")

KIND_ONE_LINER = {
    "Agent": "它可以帮你把不同的 AI 角色组织起来一起干活，而不是只会聊天。",
    "CLI": "它可以帮你在终端里直接调用 AI，少绕一层界面。",
    "MCP": "它可以帮你把外部工具接到 AI 上，让助手真能动手做事。",
    "RAG": "它可以帮你让 AI 先查自己的资料再回答，少一本正经地胡说。",
    "模型": "它可以帮你把模型跑起来、试起来，少在云上绕一圈。",
    "框架": "它可以帮你少写重复的胶水代码，把 AI 功能拼进自己的项目。",
    "WebUI": "它可以帮你用网页把 AI 能力点开就用，不用先啃命令行。",
    "SDK": "它可以帮你把 AI 能力接到自己的程序里，少从零对接。",
    "数据集": "它可以帮你拿到能直接练、能直接评的数据，少自己到处爬。",
    "插件": "它可以帮你把 AI 接到已经在用的工具里。",
}

KIND_DOES = {
    "Agent": ["把不同角色的 AI 分开工", "让它们互相交接任务", "一起给出能检查的结果"],
    "CLI": ["在终端里直接提问", "把常用操作写成命令", "结果立刻打在屏幕上"],
    "MCP": ["把外部工具接到助手上", "让 AI 真的能操作东西", "少停留在纯聊天"],
    "RAG": ["先查自己的资料再回答", "把文档变成可问的知识", "减少凭空编造"],
    "模型": ["把模型在本地或自己的机器跑起来", "方便试效果、比效果"],
    "框架": ["少写重复胶水代码", "把 AI 能力嵌进现有项目"],
    "WebUI": ["打开网页就能用", "把复杂操作收成按钮"],
    "SDK": ["用几行代码接到自己的程序", "少自己对接接口细节"],
    "数据集": ["提供能直接用的样本", "方便训练和评测"],
    "插件": ["装进已经在用的工具", "用熟悉的界面调用 AI"],
}

KIND_HOW = {
    "Agent": ["先定角色和各自职责", "用任务把它们串起来", "看过程，再改提示词"],
    "CLI": ["装到本机命令行", "对着项目直接下指令", "不满意就改一句话再跑"],
    "MCP": ["在助手里启用这个接口", "把要操作的工具连上", "用平常说话的方式指挥它"],
    "RAG": ["把资料放进它能读的地方", "提问时先检索再生成", "不对的地方补文档再问"],
    "模型": ["选好要跑的模型", "按说明启动", "用自己的例子试一遍"],
    "框架": ["装进现有项目", "按模块把能力接上", "先跑通一个小例子"],
    "WebUI": ["启动服务", "打开页面", "在界面上点着试"],
    "SDK": ["引入这个库", "填自己的密钥或模型", "先跑官方最小例子"],
    "数据集": ["下载或克隆这份数据", "按字段说明读进去", "先抽一小份看质量"],
    "插件": ["在宿主工具里安装", "打开权限", "用一条真实任务试"],
}

KIND_AUDIENCE = {
    "Agent": ["想搭小型 AI 团队的人", "想把流程交给助手的产品或运营"],
    "CLI": ["习惯终端的开发者", "不想开网页就能用模型的人"],
    "MCP": ["已经在用 AI 助手、还想让它动手的人"],
    "RAG": ["有一堆内部文档、希望 AI 先查再答的人"],
    "模型": ["想自己跑模型、对比效果的人"],
    "框架": ["要把 AI 嵌进产品里的开发者"],
    "WebUI": ["更想点按钮、不想记命令的人"],
    "SDK": ["要在自己程序里调 AI 的开发者"],
    "数据集": ["做训练、评测、研究的人"],
    "插件": ["已经有常用工具、只想加一层 AI 的人"],
}

KIND_SCENE = {
    "Agent": ["本地把开发、内容和运营串成一条流水线", "先用一个真实任务看完整协作"],
    "CLI": ["在项目目录里快速试验提示词", "把重复命令交给模型跑"],
    "MCP": ["让助手读写文件、调用外部服务", "把日常工具接进对话里"],
    "RAG": ["拿公司或个人文档来问答", "先检索、再写成能核对的回答"],
    "模型": ["本机试模型、比速度和效果", "不把数据送到别人的云上"],
    "框架": ["在现有代码库里加一层 AI 能力", "先做一个最小可运行的功能"],
    "WebUI": ["给不会命令行的同事试用", "把演示收成一个页面"],
    "SDK": ["在自己的服务里调用模型", "把生成结果接到业务接口"],
    "数据集": ["训练前先看样本长什么样", "用公开数据做对比实验"],
    "插件": ["在编辑器或浏览器里直接叫 AI", "不离开正在用的窗口"],
}


def ranking_from_repos(
    repos: list[dict[str, Any]],
    *,
    brand: str = "AutoPosting",
    series: str = "GitHub 本周爆火 AI 项目榜",
    issue: str = "",
    date_range: str = "",
) -> dict[str, Any]:
    items = []
    tags: list[str] = []
    for index, repo in enumerate(repos[:10], start=1):
        kind = str(repo.get("kind") or repo.get("category") or "")
        if kind and kind not in tags:
            tags.append(kind)
        items.append(
            {
                "rank": int(repo.get("rank") or index),
                "name": str(repo.get("name") or ""),
                "description": str(repo.get("summary") or repo.get("description") or ""),
                "category": kind,
                "logo": _safe_logo(repo),
                "url": str(repo.get("url") or ""),
                "metric": {
                    "label": "Stars",
                    "value": int(repo.get("stars") or 0),
                },
            }
        )
    return {
        "page": "ranking-overview",
        "brand": brand,
        "series": series,
        "issue": issue or "本周",
        "dateRange": date_range,
        "kicker": "WEEKLY RANKING",
        "title": "GitHub",
        "subtitle": "本周爆火 AI 项目榜",
        "source": "GitHub",
        "footer": "专业 AI 科技媒体 · 每周更新",
        "tags": tags[:6],
        "items": items,
    }


def project_from_repo(
    repo: dict[str, Any],
    *,
    brand: str = "AutoPosting",
    series: str = "GitHub 本周爆火 AI 项目榜",
    issue: str = "",
    page_number: str = "",
) -> dict[str, Any]:
    kind = str(repo.get("kind") or "AI 工具")
    features = to_bullets(repo.get("does") or repo.get("description") or "")
    if not features:
        features = list(KIND_DOES.get(kind) or ["把这个开源工具用起来"])
    how = [item for item in to_bullets(repo.get("how") or "") if not is_generic_how(item)]
    if not how:
        how = list(KIND_HOW.get(kind) or ["按自己的任务试一遍", "看它能不能省事", "再决定要不要留下"])
    audience = to_bullets(repo.get("audience") or "")
    scene = to_bullets(repo.get("scene") or "")
    if audience and not scene:
        scene = list(KIND_SCENE.get(kind) or audience)
        audience = list(KIND_AUDIENCE.get(kind) or audience)
    if not audience:
        audience = list(KIND_AUDIENCE.get(kind) or ["想先看懂再决定要不要用的人"])
    if not scene:
        scene = list(KIND_SCENE.get(kind) or ["先拿一个真实小任务试"])
    tagline = str(repo.get("summary") or repo.get("description") or "")
    if is_generic_how(tagline) or _looks_english(tagline):
        tagline = str(repo.get("name") or "")
    return {
        "page": "project-detail",
        "brand": brand,
        "series": series,
        "issue": issue or "本周",
        "pageNumber": page_number,
        "rank": int(repo.get("rank") or 1),
        "category": kind,
        "name": str(repo.get("name") or ""),
        "tagline": tagline,
        "description": str(repo.get("description") or ""),
        "keyMessage": capability_line(repo),
        "logo": _safe_logo(repo),
        "markSvg": str(repo.get("markSvg") or ""),
        "features": features,
        "how": how,
        "audience": audience,
        "scene": scene,
        "url": str(repo.get("url") or ""),
        "source": "GitHub",
        "footer": "专业 AI 科技媒体 · 每周更新",
    }


def to_bullets(text: Any, *, limit: int = 5, max_len: int = 28) -> list[str]:
    if isinstance(text, (list, tuple)):
        parts = [str(item).strip(" -•\t") for item in text if str(item).strip()]
    else:
        raw = str(text or "").strip()
        if not raw or is_generic_how(raw):
            return []
        if "\n" in raw:
            parts = [line.strip(" -•\t") for line in raw.splitlines() if line.strip()]
        else:
            parts = _split(raw)
        if len(parts) == 1 and len(parts[0]) > 36:
            parts = [
                piece.strip()
                for piece in re.split(r"[。；;]|(?<=[\u4e00-\u9fff])，(?=[\u4e00-\u9fff]{4,})", parts[0])
                if piece.strip()
            ]
    cleaned: list[str] = []
    for part in parts:
        piece = re.sub(r"^(可以|能够|支持|提供)", "", part).strip(" ，。、；;")
        if len(piece) > max_len:
            piece = piece[: max_len - 1].rstrip() + "…"
        if piece and piece not in cleaned and not is_generic_how(piece) and not _looks_english(piece):
            cleaned.append(piece)
        if len(cleaned) >= limit:
            break
    return cleaned


def capability_line(repo: dict[str, Any]) -> str:
    kind = str(repo.get("kind") or "")
    for candidate in (repo.get("summary"), repo.get("description"), repo.get("does")):
        text = str(candidate or "").strip()
        if not text or is_generic_how(text) or _looks_english(text):
            continue
        if "帮你" in text or text.startswith("它"):
            return _clip_line(text, 72)
        return _clip_line("它可以帮你" + _bare_capability(text), 72)
    return KIND_ONE_LINER.get(kind, "它可以帮你先看懂这个工具能干什么，再决定要不要用。")


def is_generic_how(text: str) -> bool:
    compact = (text or "").replace(" ", "")
    return any(hint.replace(" ", "") in compact for hint in GENERIC_HOW)


def _safe_logo(repo: dict[str, Any]) -> str:
    url = str(repo.get("icon_url") or repo.get("logo") or "")
    if not url or is_author_avatar(url):
        return ""
    return url


def _bare_capability(text: str) -> str:
    piece = re.sub(r"^(这是|这款|一个|一种)", "", text.strip())
    return piece or text.strip()


def _looks_english(text: str) -> bool:
    latin = len(LATIN_RE.findall(text or ""))
    cjk = len(CJK_RE.findall(text or ""))
    return latin > cjk


def _clip_line(text: str, limit: int) -> str:
    value = " ".join((text or "").split())
    if len(value) <= limit:
        return value
    return value[: limit - 1].rstrip() + "…"


def _metrics(repo: dict[str, Any]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = [{"label": "Stars", "value": int(repo.get("stars") or 0)}]
    week = int(repo.get("stars_week") or 0)
    if week:
        rows.append({"label": "本周", "value": week})
    return rows


def _split(text: str) -> list[str]:
    for separator in ("、", "，", ",", "；", ";"):
        if separator in text:
            return [part.strip() for part in text.split(separator) if part.strip()]
    return [text.strip()] if text.strip() else []
