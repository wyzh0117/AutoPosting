from __future__ import annotations

from pathlib import Path
from typing import Any

from autoposting.github_weekly import week_window_start

from .adapter import project_from_repo, ranking_from_repos
from .pipeline import render_page
from .tokens import resolve_tokens


def render_weekly_visual(
    repos: list[dict[str, Any]],
    jobs: list[dict[str, Any]],
    out_dir: Path,
    theme: str = "dark",
    palette: dict[str, str] | None = None,
    screenshot: bool = True,
) -> list[dict[str, Any]]:
    tokens = resolve_tokens(theme, palette)
    target = Path(out_dir)
    target.mkdir(parents=True, exist_ok=True)
    date_range = week_window_start()
    total = max(len(repos), 1)
    rendered: list[dict[str, Any]] = []
    for job in jobs:
        kind = str(job.get("kind") or "")
        stem = str(job.get("id") or kind or "page")
        if kind == "cover":
            payload = ranking_from_repos(repos, issue="本周", date_range=date_range)
        else:
            repo = _match_repo(repos, job)
            if repo is None:
                rendered.append(dict(job))
                continue
            rank = int(repo.get("rank") or job.get("rank") or 1)
            payload = project_from_repo(
                repo,
                issue="本周",
                page_number=f"{rank + 1:02d} / {total + 1:02d}",
            )
        result = render_page(
            payload,
            out_dir=target,
            screenshot=screenshot,
            tokens=tokens,
            file_stem=stem,
        )
        row = dict(job)
        if result.get("png"):
            filename = f"{stem}.png"
            row["file"] = filename
            row["url"] = f"/api/generated/github-weekly/{filename}"
        row["selected"] = True
        rendered.append(row)
    return rendered


def _match_repo(repos: list[dict[str, Any]], job: dict[str, Any]) -> dict[str, Any] | None:
    rank = int(job.get("rank") or 0)
    title = str(job.get("title") or "")
    for repo in repos:
        if rank and int(repo.get("rank") or 0) == rank:
            return repo
    for repo in repos:
        if title and str(repo.get("name") or "") == title:
            return repo
    return None
