from __future__ import annotations

from typing import Any

from . import components as c
from .css import stylesheet
from .rules import apply_project_rules, apply_ranking_rules
from .tokens import load_tokens


def render_html(payload: dict[str, Any], tokens: dict[str, Any] | None = None) -> str:
    resolved = tokens or load_tokens()
    page = payload.get("page")
    if page == "ranking-overview":
        body = ranking_overview(payload)
        page_class = "page page-ranking"
    elif page == "project-detail":
        body = project_detail(payload)
        page_class = "page page-project"
    else:
        raise ValueError(f"unsupported page: {page}")
    return (
        "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=1080\">"
        f"<title>{_title(payload)}</title><style>{stylesheet(resolved)}</style></head>"
        f"<body><div class=\"{page_class}\">{body}</div></body></html>"
    )


def ranking_overview(payload: dict[str, Any]) -> str:
    data = apply_ranking_rules(payload)
    return "".join(
        [
            c.brand_header(str(data.get("brand") or ""), str(data.get("issue") or "")),
            c.hero_title(str(data.get("title") or ""), str(data.get("subtitle") or "")),
            c.issue_meta(
                str(data.get("issue") or ""),
                str(data.get("dateRange") or ""),
                str(data.get("kicker") or ""),
            ),
            c.ranking_list(data.get("items") or []),
            c.topic_tags(data.get("tags") or []),
            c.footer(str(data.get("footer") or data.get("source") or ""), "01 / 11"),
        ]
    )


def project_detail(payload: dict[str, Any]) -> str:
    data = apply_project_rules(payload)
    return "".join(
        [
            c.brand_header(str(data.get("brand") or ""), str(data.get("issue") or "")),
            '<div class="c-title-row">'
            f"{c.rank_pill(int(data.get('rank') or 1))}"
            f"{c.category_tag(str(data.get('category') or ''))}"
            "</div>",
            c.hero_title(str(data.get("name") or ""), str(data.get("tagline") or "")),
            c.hero_visual(str(data.get("heroVisual") or ""), "Main Visual"),
            c.quote_card("一句话看懂", str(data.get("keyMessage") or "")),
            '<div class="c-split">'
            f"{c.feature_list(data.get('features') or [])}"
            f"{c.workflow_diagram(data.get('workflow') or [])}"
            "</div>",
            '<div class="c-split">'
            f"{c.audience_card(data.get('audience') or [])}"
            f"{c.url_card(str(data.get('url') or ''), str(data.get('urlDisplay') or ''))}"
            "</div>",
            c.footer(
                str(data.get("footer") or data.get("source") or ""),
                str(data.get("pageNumber") or ""),
            ),
        ]
    )


def _title(payload: dict[str, Any]) -> str:
    return str(payload.get("name") or payload.get("title") or "visual")
