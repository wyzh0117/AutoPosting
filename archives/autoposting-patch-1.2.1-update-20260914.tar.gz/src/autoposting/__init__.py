"""Local-first AI news collection and drafting pipeline."""

__version__ = "1.2.1"
