import json
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from autoposting.db import Database
from autoposting.llm import LLMError
from autoposting.models import Source
from autoposting.skill_finder import (
    FETCH_DEADLINE_SECONDS,
    GAP_REASON,
    MAX_FETCHES,
    MIN_STARS,
    SKILLS_SH_MIN_INSTALLS,
    SKILLS_SH_PER_QUERY,
    SKILLS_SH_SEARCH_URL,
    SKILLS_SH_SOURCE,
    SKILL_PATHS,
    SEARCH_TEMPLATES,
    _FetchBudget,
    _fair_share,
    _ingest_repo,
    _names_from_web,
    _skills_sh_search,
    add_manual_skills,
    cap_skills,
    decompose_coverage,
    fetch_skill_md,
    find_skills,
    passes_quality,
    quality_reason,
    render_skill_package,
    reset_skill_finder_state,
    skills_as_repos,
)
from autoposting.skill_links import parse_skill_links
from autoposting.web import INDEX_HTML, WebApp, create_server


PODCAST_CHAIN = [
    {"id": "c1", "name": "选题", "role": "入口"},
    {"id": "c2", "name": "脚本", "role": "准备"},
    {"id": "c3", "name": "录音", "role": "制作"},
    {"id": "c4", "name": "剪辑", "role": "制作"},
    {"id": "c5", "name": "封面", "role": "装配"},
    {"id": "c6", "name": "发布", "role": "交付"},
]

PODCAST_STAGES = [
    {
        "id": "topic",
        "name": "选题",
        "queries": ["播客选题", "podcast topic"],
        "required": True,
    },
    {
        "id": "script",
        "name": "脚本",
        "queries": ["播客脚本", "podcast script"],
        "required": True,
    },
    {
        "id": "record",
        "name": "录音",
        "queries": ["播客录音", "podcast recording"],
        "required": True,
    },
    {
        "id": "edit",
        "name": "剪辑",
        "queries": ["播客剪辑", "podcast edit"],
        "required": True,
    },
    {
        "id": "cover",
        "name": "封面",
        "queries": ["播客封面", "podcast cover art"],
        "required": True,
    },
    {
        "id": "publish",
        "name": "发布",
        "queries": ["播客发布", "podcast publish"],
        "required": True,
    },
]


def _coverage_json() -> str:
    return json.dumps(
        {
            "goal": "从零做出一档可上线播客",
            "title": "从零做播客技能包",
            "theme": "播客从选题到上线",
            "chain": PODCAST_CHAIN,
            "stages": PODCAST_STAGES,
        },
        ensure_ascii=False,
    )


def _repo_item(
    full_name: str,
    *,
    stars: int,
    description: str,
    pushed_at: str,
    topics: list[str] | None = None,
) -> dict[str, object]:
    owner, name = full_name.split("/", 1)
    return {
        "full_name": full_name,
        "name": name,
        "description": description,
        "stargazers_count": stars,
        "html_url": f"https://github.com/{full_name}",
        "language": "Python",
        "topics": topics or ["claude-code-skill"],
        "owner": {"login": owner, "avatar_url": f"https://github.com/{owner}.png"},
        "pushed_at": pushed_at,
        "created_at": pushed_at,
    }


def _skill_md(name: str, stage: str) -> str:
    return f"# {name}\n\n解决播客流程里的{stage}。\n"


class SkillFinderTests(unittest.TestCase):
    def setUp(self) -> None:
        reset_skill_finder_state()
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.now = datetime(2026, 9, 12, tzinfo=timezone.utc)
        self.fresh = "2026-08-20T00:00:00Z"
        self.stale = "2024-01-01T00:00:00Z"
        # Fake skills.sh rows, matched by needle in the search terms. Empty by
        # default so the offline GitHub tests keep their exact expectations.
        self.skills_sh_rows: list[tuple[str, dict[str, object]]] = []

    def _complete(self, prompt: str) -> str:
        if "打包结果" in prompt:
            ids = [
                "acme/podcast-topic",
                "acme/podcast-script",
                "acme/podcast-record",
                "acme/podcast-edit",
                "acme/podcast-cover",
                "acme/podcast-publish",
            ]
            body = "从零做播客。地图：选题到发布。\n" + "\n".join(
                f"{item} 用于对应阶段" for item in ids
            )
            for item in ids:
                self.assertIn(item, prompt)
            return json.dumps(
                {"title": "从零做播客技能包", "body": body + "\nAIGC"},
                ensure_ascii=False,
            )
        return _coverage_json()

    def _skills_sh_response(self, terms: str) -> dict[str, object]:
        rows = [row for needle, row in self.skills_sh_rows if needle in terms]
        return {"query": terms, "searchType": "fuzzy", "searchVersion": "legacy", "skills": rows}

    def _github_get(self, url: str, *, gap_first_pass: bool = True) -> object:
        parsed = urlparse(url)
        if parsed.netloc == SKILLS_SH_SOURCE and parsed.path == "/api/search":
            terms = parse_qs(parsed.query).get("q", [""])[0]
            return self._skills_sh_response(terms)
        if parsed.netloc == "api.github.com" and parsed.path == "/search/repositories":
            query = parse_qs(parsed.query).get("q", [""])[0]
            if "stale-empty" in query:
                return {
                    "items": [
                        _repo_item(
                            "old/stale-empty",
                            stars=0,
                            description="empty shell",
                            pushed_at=self.stale,
                        )
                    ]
                }
            if "封面" in query or "cover art" in query:
                if gap_first_pass and "claude skill" not in query and "filename:SKILL.md" not in query:
                    return {"items": []}
                return {
                    "items": [
                        _repo_item(
                            "acme/podcast-cover",
                            stars=42,
                            description="播客封面 skill",
                            pushed_at=self.fresh,
                        )
                    ]
                }
            mapping = (
                ("选题", "acme/podcast-topic", "播客选题"),
                ("topic", "acme/podcast-topic", "播客选题"),
                ("脚本", "acme/podcast-script", "播客脚本"),
                ("script", "acme/podcast-script", "播客脚本"),
                ("录音", "acme/podcast-record", "播客录音"),
                ("recording", "acme/podcast-record", "播客录音"),
                ("剪辑", "acme/podcast-edit", "播客剪辑"),
                ("edit", "acme/podcast-edit", "播客剪辑"),
                ("发布", "acme/podcast-publish", "播客发布"),
                ("publish", "acme/podcast-publish", "播客发布"),
            )
            for needle, full_name, desc in mapping:
                if needle in query:
                    return {
                        "items": [
                            _repo_item(
                                full_name,
                                stars=80,
                                description=desc,
                                pushed_at=self.fresh,
                            )
                        ]
                    }
            return {"items": []}
        if "anthropics/skills" in url or "topic:claude-code-skill" in url or "topic:agent-skills" in url:
            raise RuntimeError("github_fetch_failed:optional-root")
        if "raw.githubusercontent.com" in url or "/contents/" in url:
            if "stale-empty" in url:
                raise RuntimeError("github_fetch_failed:missing-skill")
            for full_name, stage in (
                ("acme/podcast-topic", "选题"),
                ("acme/podcast-script", "脚本"),
                ("acme/podcast-record", "录音"),
                ("acme/podcast-edit", "剪辑"),
                ("acme/podcast-cover", "封面"),
                ("acme/podcast-publish", "发布"),
            ):
                if full_name in url:
                    return _skill_md(full_name.split("/", 1)[1], stage)
            raise RuntimeError("github_fetch_failed:unknown")
        raise RuntimeError(f"github_fetch_failed:{url}")

    def test_coverage_decompose_and_second_pass_fills_gap(self) -> None:
        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        self.assertGreaterEqual(len(result["stages"]), 6)
        cover = next(stage for stage in result["stages"] if stage["id"] == "cover")
        self.assertFalse(cover.get("gap"))
        names = {str(skill["source_id"]) for skill in result["skills"]}
        self.assertIn("acme/podcast-cover", names)
        self.assertIn("acme/podcast-topic", names)

    def test_quality_gate_drops_zero_star_stale_without_skill_md(self) -> None:
        hit = {
            "name": "stale-empty",
            "source_id": "old/stale-empty",
            "stars": 0,
            "pushed_at": self.stale,
            "skill_md": "",
            "skill_path": "",
            "url": "https://github.com/old/stale-empty",
            "registry": False,
        }
        self.assertFalse(passes_quality(hit, now=self.now))
        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        ids = {str(skill["source_id"]) for skill in result["skills"]}
        self.assertNotIn("old/stale-empty", ids)

    def test_package_article_contains_every_source_id(self) -> None:
        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        body = str(result["article"]["body"])
        for skill in result["skills"]:
            self.assertIn(str(skill["source_id"]), body)
            self.assertIn(str(skill["name"]), body)
        package = Path(str(result["package_path"]))
        self.assertTrue((package / "index.json").is_file())
        self.assertTrue((package / "images").is_dir())

    def test_llm_missing_raises_skill_search_failed(self) -> None:
        with self.assertRaises(LLMError) as caught:
            find_skills(
                "从零做播客",
                complete=None,
                github_get=lambda _url: {"items": []},
                web_search=lambda _query: [],
                now=self.now,
                output_root=self.root / "skills",
            )
        self.assertEqual("skill_search_failed", caught.exception.code)
        self.assertFalse(any(self.root.rglob("index.json")))

    def test_network_budget_caps_http_instead_of_crawling_every_repo(self) -> None:
        calls: list[str] = []

        def getter(url: str) -> object:
            calls.append(url)
            if "skills.sh" in url:
                return {"skills": []}
            if "api.github.com/search/repositories" in url:
                return {
                    "items": [
                        _repo_item(
                            f"flood/repo-{index}",
                            stars=50,
                            description="generic skill",
                            pushed_at=self.fresh,
                        )
                        for index in range(10)
                    ]
                }
            if "raw.githubusercontent.com" in url or "/contents/" in url:
                return "# flood\n\nskill\n"
            return {"full_name": "flood/repo-0"}

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                return json.dumps(
                    {"title": "预算内技能包", "body": "收录来源见列表。\nAIGC"},
                    ensure_ascii=False,
                )
            return _coverage_json()

        result = find_skills(
            "从零做播客",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
            max_fetches=18,
            fetch_deadline_seconds=30,
        )
        self.assertLessEqual(len(calls), 18)
        self.assertTrue(result["stages"])
        self.assertTrue(result["skills"])

    def test_on_event_emits_skills_before_images(self) -> None:
        events: list[tuple[str, dict[str, object]]] = []

        def on_event(kind: str, payload: dict[str, object] | None = None) -> None:
            events.append((kind, payload or {}))

        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
            on_event=on_event,
        )
        kinds = [kind for kind, _payload in events]
        self.assertIn("skill", kinds)
        self.assertIn("skills_ready", kinds)
        first_skill = kinds.index("skill")
        ready = kinds.index("skills_ready")
        self.assertLess(first_skill, ready)
        self.assertTrue(all(kind != "image" for kind in kinds[: ready + 1]))
        if "image" in kinds:
            self.assertGreater(kinds.index("image"), ready)
        self.assertTrue(result["skills"])
        self.assertEqual("skills_ready", result.get("phase"))

    def test_gap_stages_stay_visible_with_marker_but_absent_from_article(self) -> None:
        article_prompt: dict[str, str] = {}

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                article_prompt["text"] = prompt
                self.assertNotIn('"gap": true', prompt)
                self.assertNotIn("缺口", prompt)
                body = "从零做播客。地图：选题到发布。\nacme/podcast-topic 选题\nAIGC"
                return json.dumps({"title": "从零做播客技能包", "body": body}, ensure_ascii=False)
            stages = [dict(item) for item in PODCAST_STAGES]
            return json.dumps(
                {"title": "从零做播客技能包", "theme": "播客从选题到上线", "stages": stages},
                ensure_ascii=False,
            )

        def getter(url: str) -> object:
            parsed = urlparse(url)
            if parsed.netloc == SKILLS_SH_SOURCE:
                return self._skills_sh_response("")
            if parsed.netloc == "api.github.com" and parsed.path == "/search/repositories":
                query = parse_qs(parsed.query).get("q", [""])[0]
                if "选题" in query or "topic" in query:
                    return {
                        "items": [
                            _repo_item(
                                "acme/podcast-topic",
                                stars=80,
                                description="播客选题",
                                pushed_at=self.fresh,
                            )
                        ]
                    }
                return {"items": []}
            if "anthropics/skills" in url:
                raise RuntimeError("github_fetch_failed:optional-root")
            if "raw.githubusercontent.com" in url or "/contents/" in url:
                if "acme/podcast-topic" in url:
                    return _skill_md("podcast-topic", "选题")
                raise RuntimeError("github_fetch_failed:missing")
            raise RuntimeError(f"github_fetch_failed:{url}")

        result = find_skills(
            "从零做播客",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        # B4: every coverage stage stays visible; empty ones carry an explicit gap.
        self.assertEqual(
            [str(stage["id"]) for stage in PODCAST_STAGES],
            [str(stage["id"]) for stage in result["stages"]],
        )
        gaps = [stage for stage in result["stages"] if stage.get("gap")]
        filled = [stage for stage in result["stages"] if not stage.get("gap")]
        self.assertEqual(["topic"], [str(stage["id"]) for stage in filled])
        self.assertEqual(
            ["script", "record", "edit", "cover", "publish"],
            [str(stage["id"]) for stage in gaps],
        )
        self.assertTrue(all(stage.get("gap_reason") == GAP_REASON for stage in gaps))
        self.assertEqual(
            ["topic"], [str(group.get("stage_id") or "") for group in result["groups"]]
        )
        self.assertTrue(all(not skill.get("gap") for skill in result["skills"]))
        self.assertEqual(["acme/podcast-topic"], [str(item["source_id"]) for item in result["skills"]])
        body = str(result["article"]["body"])
        self.assertNotIn("缺口", body)
        self.assertIn("acme/podcast-topic", article_prompt["text"])
        repos = skills_as_repos(result["skills"])
        self.assertEqual(1, len(repos))
        self.assertNotIn("缺口", json.dumps(repos, ensure_ascii=False))

    def test_same_query_reuses_skills_when_github_rate_limits(self) -> None:
        first = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=False),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-a",
        )
        self.assertGreaterEqual(len(first["skills"]), 1)
        first_ids = {str(skill["source_id"]) for skill in first["skills"]}

        def blocked(_url: str) -> object:
            raise RuntimeError("github_fetch_failed:403 rate limit")

        second = find_skills(
            "  从零做播客  ",
            complete=self._complete,
            github_get=blocked,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-b",
        )
        second_ids = {str(skill["source_id"]) for skill in second["skills"]}
        self.assertTrue(first_ids & second_ids, msg=f"first={first_ids} second={second_ids}")
        self.assertGreaterEqual(len(second["skills"]), 1)

    def test_pipeline_emits_seven_progress_steps_then_article_and_skills_ready(self) -> None:
        events: list[tuple[str, dict[str, object]]] = []

        def on_event(kind: str, payload: dict[str, object] | None = None) -> None:
            events.append((kind, payload or {}))

        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
            on_event=on_event,
        )
        progress_steps = [
            str((payload.get("progress") or {}).get("step") or "")
            for kind, payload in events
            if kind == "progress"
        ]
        ordered: list[str] = []
        for step in progress_steps:
            if step and step not in ordered:
                ordered.append(step)
        self.assertEqual(
            ["understanding", "chain", "decompose", "keywords", "search", "group", "compose"],
            ordered,
        )
        kinds = [kind for kind, _payload in events]
        self.assertIn("article", kinds)
        self.assertIn("skills_ready", kinds)
        compose_at = next(
            index
            for index, (kind, payload) in enumerate(events)
            if kind == "progress" and str((payload.get("progress") or {}).get("step") or "") == "compose"
        )
        self.assertLess(compose_at, kinds.index("article"))
        self.assertLess(kinds.index("article"), kinds.index("skills_ready"))
        progress = result.get("progress") if isinstance(result.get("progress"), dict) else {}
        self.assertEqual(7, progress.get("step_total"))
        self.assertEqual("从零做出一档可上线播客", result.get("goal"))
        self.assertTrue(result.get("chain"))
        self.assertEqual("c1", str((result.get("chain") or [{}])[0].get("id") or ""))
        self.assertTrue(result.get("groups"))
        self.assertEqual("skills_ready", result.get("phase"))
        labels = {
            str((payload.get("progress") or {}).get("step") or ""): str(
                (payload.get("progress") or {}).get("label") or ""
            )
            for kind, payload in events
            if kind == "progress"
        }
        self.assertEqual("理解需求", labels.get("understanding"))
        self.assertEqual("还原生产链", labels.get("chain"))
        self.assertEqual("分解工作流", labels.get("decompose"))
        self.assertEqual("生成关键词", labels.get("keywords"))
        self.assertEqual("查找 Skill", labels.get("search"))
        self.assertEqual("还原分组", labels.get("group"))
        self.assertEqual("组合工作流", labels.get("compose"))

    def test_pipeline_snapshot_progress_elapsed_ms_increases_across_events(self) -> None:
        events: list[tuple[str, dict[str, object]]] = []

        def on_event(kind: str, payload: dict[str, object] | None = None) -> None:
            events.append((kind, payload or {}))

        find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
            on_event=on_event,
        )
        elapsed = [
            int((payload.get("progress") or {}).get("elapsed_ms") or 0)
            for kind, payload in events
            if kind == "progress"
        ]
        self.assertGreaterEqual(len(elapsed), 7)
        self.assertEqual(elapsed, sorted(elapsed))
        self.assertGreater(elapsed[-1], elapsed[0])
        started = [
            str((payload.get("progress") or {}).get("started_at") or "")
            for kind, payload in events
            if kind == "progress"
        ]
        self.assertTrue(all(started))
        self.assertEqual(1, len(set(started)))

    def test_pipeline_search_progress_names_module_and_keyword(self) -> None:
        events: list[tuple[str, dict[str, object]]] = []

        def on_event(kind: str, payload: dict[str, object] | None = None) -> None:
            events.append((kind, payload or {}))

        find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
            on_event=on_event,
        )
        search_details = [
            str((payload.get("progress") or {}).get("detail") or "")
            for kind, payload in events
            if kind == "progress"
            and str((payload.get("progress") or {}).get("step") or "") == "search"
        ]
        self.assertTrue(search_details)
        named = [detail for detail in search_details if detail.startswith("正在检索：") and " · " in detail]
        self.assertTrue(named, msg=f"search details={search_details}")
        joined = "\n".join(named)
        self.assertIn("选题", joined)
        self.assertTrue(any("播客选题" in detail or "podcast topic" in detail for detail in named))

    def test_pipeline_at_most_two_llm_completions(self) -> None:
        prompts: list[str] = []

        def complete(prompt: str) -> str:
            prompts.append(prompt)
            return self._complete(prompt)

        find_skills(
            "从零做播客",
            complete=complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        self.assertLessEqual(len(prompts), 2)
        self.assertGreaterEqual(len(prompts), 2)

    def test_pipeline_default_fetch_budget_covers_both_sources(self) -> None:
        # Two search sources per query now share the budget, so it doubled.
        self.assertEqual(160, MAX_FETCHES)
        self.assertEqual(240, FETCH_DEADLINE_SECONDS)
        import inspect

        params = inspect.signature(find_skills).parameters
        self.assertEqual(160, params["max_fetches"].default)
        self.assertEqual(240, params["fetch_deadline_seconds"].default)
        calls: list[str] = []

        def getter(url: str) -> object:
            calls.append(url)
            return self._github_get(url, gap_first_pass=False)

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                return json.dumps(
                    {"title": "从零做播客技能包", "body": "先选题再发布。\nAIGC"},
                    ensure_ascii=False,
                )
            return _coverage_json()

        result = find_skills(
            "从零做播客",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-deadline",
            max_fetches=12,
            fetch_deadline_seconds=30,
        )
        self.assertLessEqual(len(calls), 12)
        self.assertTrue(result["skills"])

    def test_pipeline_groups_omit_empty_modules_article_has_source_ids_no_gap(self) -> None:
        article_prompt: dict[str, str] = {}

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                article_prompt["text"] = prompt
                self.assertNotIn('"gap": true', prompt)
                self.assertNotIn("缺口", prompt)
                body = "先选题再脚本。\nacme/podcast-topic 选题\nAIGC"
                return json.dumps({"title": "从零做播客技能包", "body": body}, ensure_ascii=False)
            return _coverage_json()

        def getter(url: str) -> object:
            parsed = urlparse(url)
            if parsed.netloc == SKILLS_SH_SOURCE:
                return self._skills_sh_response("")
            if parsed.netloc == "api.github.com" and parsed.path == "/search/repositories":
                query = parse_qs(parsed.query).get("q", [""])[0]
                if "选题" in query or "topic" in query:
                    return {
                        "items": [
                            _repo_item(
                                "acme/podcast-topic",
                                stars=80,
                                description="播客选题",
                                pushed_at=self.fresh,
                            )
                        ]
                    }
                return {"items": []}
            if "anthropics/skills" in url:
                raise RuntimeError("github_fetch_failed:optional-root")
            if "raw.githubusercontent.com" in url or "/contents/" in url:
                if "acme/podcast-topic" in url:
                    return _skill_md("podcast-topic", "选题")
                raise RuntimeError("github_fetch_failed:missing")
            raise RuntimeError(f"github_fetch_failed:{url}")

        result = find_skills(
            "从零做播客",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-groups",
        )
        self.assertEqual(
            [str(stage["id"]) for stage in PODCAST_STAGES],
            [str(stage["id"]) for stage in result["stages"]],
        )
        groups = result.get("groups") if isinstance(result.get("groups"), list) else []
        self.assertEqual(["topic"], [str(group.get("stage_id") or "") for group in groups])
        self.assertEqual(["acme/podcast-topic"], list(groups[0].get("skill_ids") or []))
        self.assertEqual(
            ["topic"], [str(stage["id"]) for stage in result["stages"] if not stage.get("gap")]
        )
        self.assertTrue(all(not skill.get("gap") for skill in result["skills"]))
        body = str(result["article"]["body"])
        self.assertIn("acme/podcast-topic", body)
        self.assertNotIn("缺口", body)

    def test_pipeline_no_sleep_padding_in_skill_finder(self) -> None:
        import inspect

        from autoposting import skill_finder as mod

        source = inspect.getsource(mod)
        self.assertNotIn("time.sleep(", source)

    def test_empty_fetch_results_are_retried_instead_of_cached_as_no_skills(self) -> None:
        calls = 0

        def search(_query: str) -> list[dict[str, str]]:
            nonlocal calls
            calls += 1
            return [] if calls == 1 else [{"title": "a skill"}]

        budget = _FetchBudget(
            lambda _url: {"items": []},
            search,
            max_fetches=4,
            deadline=time.monotonic() + 30,
        )
        self.assertEqual([], budget.search("same term"))
        self.assertEqual([{"title": "a skill"}], budget.search("same term"))
        self.assertEqual(2, calls)

    def test_repeated_query_reuses_one_coverage_plan(self) -> None:
        calls = 0

        def complete(_prompt: str) -> str:
            nonlocal calls
            calls += 1
            return _coverage_json()

        first = decompose_coverage("同一个查找词", complete)
        second = decompose_coverage("同一个查找词", lambda _prompt: "not used")
        self.assertEqual(first, second)
        self.assertEqual(1, calls)
        first["stages"][0]["gap"] = True
        self.assertFalse(second["stages"][0].get("gap"))

    def test_nonempty_rate_limit_get_and_search_are_not_cached(self) -> None:
        get_calls = 0

        def getter(_url: str) -> object:
            nonlocal get_calls
            get_calls += 1
            if get_calls == 1:
                return {"status": 403, "message": "rate limit"}
            return {"items": [{"full_name": "acme/skill"}]}

        budget = _FetchBudget(
            getter,
            lambda _query: [],
            max_fetches=4,
            deadline=time.monotonic() + 30,
        )
        self.assertEqual(403, budget.get("https://example.test/repo")["status"])
        self.assertEqual(
            [{"full_name": "acme/skill"}],
            budget.get("https://example.test/repo")["items"],
        )
        self.assertEqual(2, get_calls)

        search_calls = 0

        def search(_query: str) -> list[dict[str, str]]:
            nonlocal search_calls
            search_calls += 1
            if search_calls == 1:
                return [{"status_code": 429, "error": "too many requests"}]
            return [{"title": "skill"}]

        budget = _FetchBudget(
            lambda _url: {},
            search,
            max_fetches=4,
            deadline=time.monotonic() + 30,
        )
        self.assertEqual([], budget.search("same term"))
        self.assertEqual([{"title": "skill"}], budget.search("same term"))
        self.assertEqual(2, search_calls)

    def test_github_rate_limit_parks_the_api_and_names_the_reason(self) -> None:
        """A 403 from api.github.com must park that quota, not read as RuntimeError."""
        calls: list[str] = []

        class _Limited(RuntimeError):
            kind = "rate_limited"
            reset_at = time.time() + 3600

        def getter(url: str) -> object:
            calls.append(url)
            raise _Limited(f"github_fetch_failed:rate limit exceeded (403):{url}")

        budget = _FetchBudget(
            getter, lambda _query: [], max_fetches=10, deadline=time.monotonic() + 30
        )
        with self.assertRaises(_Limited):
            budget.get("https://api.github.com/repos/acme/skill/contents")
        self.assertEqual(["github:rate_limited"], budget.reasons)
        # The core quota is parked...
        self.assertFalse(budget.github_api_ok("https://api.github.com/repos/acme/other/contents"))
        # ...raw CDN probes never are, so SKILL.md can still be located.
        self.assertTrue(budget.github_api_ok("https://raw.githubusercontent.com/acme/other/HEAD/SKILL.md"))
        # The search quota is a separate bucket: only its own 403 parks it.
        self.assertTrue(budget.github_api_ok("https://api.github.com/search/repositories?q=x"))
        self.assertEqual(1, len(calls))

    def test_quota_snapshot_parks_a_resource_before_the_403_arrives(self) -> None:
        from autoposting import skill_finder as mod

        budget = _FetchBudget(
            lambda _url: {}, lambda _query: [], max_fetches=10, deadline=time.monotonic() + 30
        )
        state = {"limit": 60, "remaining": 1, "reset": time.time() + 600, "resource": "core"}
        original = mod._github_quota_state
        mod._github_quota_state = lambda: dict(state)
        self.addCleanup(setattr, mod, "_github_quota_state", original)
        self.assertFalse(budget.github_api_ok("https://api.github.com/repos/acme/x/contents"))
        self.assertIn("github:rate_limited", budget.reasons)
        # A snapshot for the other bucket must not park this one.
        state["resource"] = "search"
        budget2 = _FetchBudget(
            lambda _url: {}, lambda _query: [], max_fetches=10, deadline=time.monotonic() + 30
        )
        self.assertTrue(budget2.github_api_ok("https://api.github.com/repos/acme/x/contents"))

    def test_fetch_skill_md_falls_back_to_raw_layouts_when_the_api_is_parked(self) -> None:
        calls: list[str] = []

        def getter(url: str) -> object:
            calls.append(url)
            if url.endswith("/video-edit/SKILL.md"):
                return "# video-edit\n\n剪掉废话。\n"
            raise RuntimeError("github_fetch_failed:404")

        text, path = fetch_skill_md(
            "acme/skills", getter, "video-edit", api_ok=lambda _url: False
        )
        self.assertIn("剪掉废话", text)
        self.assertEqual("video-edit/SKILL.md", path)
        self.assertTrue(calls)
        self.assertFalse([url for url in calls if urlparse(url).netloc == "api.github.com"])

    def test_probe_404_is_not_reported_as_a_degraded_source(self) -> None:
        """Walking SKILL_PATHS 404s on purpose; that is not a source failure."""
        from autoposting import github_weekly as gh

        error = gh.GitHubFetchError(
            "not_found", "https://raw.githubusercontent.com/a/b/HEAD/SKILL.md", 404
        )

        def getter(_url: str) -> object:
            raise error

        budget = _FetchBudget(
            getter, lambda _query: [], max_fetches=5, deadline=time.monotonic() + 30
        )
        with self.assertRaises(gh.GitHubFetchError):
            budget.get("https://raw.githubusercontent.com/a/b/HEAD/SKILL.md")
        self.assertFalse(budget.degraded)
        self.assertEqual([], budget.reasons)
        # A real source failure still reports, and with the friendly token.
        bad = gh.GitHubFetchError(
            "unreachable", "https://raw.githubusercontent.com/a/b/HEAD/SKILL.md"
        )
        budget = _FetchBudget(
            lambda _url: (_ for _ in ()).throw(bad),
            lambda _query: [],
            max_fetches=5,
            deadline=time.monotonic() + 30,
        )
        with self.assertRaises(gh.GitHubFetchError):
            budget.get("https://raw.githubusercontent.com/a/b/HEAD/SKILL.md")
        self.assertEqual(["github:unreachable"], budget.reasons)

    def test_nested_cache_values_are_isolated_on_read_and_write(self) -> None:
        payload = {"items": [{"metadata": {"labels": []}}]}
        budget = _FetchBudget(
            lambda _url: payload,
            lambda _query: [{"metadata": {"labels": []}}],
            max_fetches=4,
            deadline=time.monotonic() + 30,
        )
        first = budget.get("https://example.test/nested")
        first["items"][0]["metadata"]["labels"].append("mutated")
        second = budget.get("https://example.test/nested")
        self.assertEqual([], second["items"][0]["metadata"]["labels"])

        first_search = budget.search("nested")
        first_search[0]["metadata"]["labels"].append("mutated")
        second_search = budget.search("nested")
        self.assertEqual([], second_search[0]["metadata"]["labels"])

    def test_find_same_query_is_stable_and_different_query_is_isolated(self) -> None:
        def plan(label: str) -> str:
            stages = [
                {
                    "id": f"stage-{index}",
                    "name": f"模块{index}",
                    "queries": [f"{label} 模块{index}"],
                    "required": True,
                }
                for index in range(1, 7)
            ]
            return json.dumps(
                {
                    "goal": label,
                    "title": label,
                    "theme": label,
                    "chain": [],
                    "stages": stages,
                },
                ensure_ascii=False,
            )

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                return json.dumps({"title": "结果", "body": "AIGC"}, ensure_ascii=False)
            label = "alpha" if "alpha" in prompt else "beta"
            return plan(label)

        def getter(url: str) -> object:
            if "skills.sh" in url:
                return self._skills_sh_response("")
            if "api.github.com/repos/anthropics/skills/contents" in url:
                return []
            if "api.github.com/search/repositories" in url:
                if "alpha" not in url:
                    return {"items": []}
                return {
                    "items": [
                        _repo_item(
                            "acme/alpha-skill",
                            stars=50,
                            description="alpha",
                            pushed_at=self.fresh,
                        )
                    ]
                }
            if "raw.githubusercontent.com/acme/alpha-skill" in url:
                return "# alpha\n\nskill\n"
            return {}

        first = find_skills(
            " alpha ",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "stable-a",
        )
        second = find_skills(
            "alpha",
            complete=complete,
            github_get=lambda _url: {"status": 429, "message": "rate limit"},
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "stable-b",
        )
        self.assertEqual(
            {str(skill["source_id"]) for skill in first["skills"]},
            {str(skill["source_id"]) for skill in second["skills"]},
        )
        self.assertFalse(first.get("degraded"))
        self.assertTrue(second.get("degraded"))

        different = find_skills(
            "beta",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "isolated",
        )
        self.assertFalse(different["skills"])

    # ---- skills.sh source adapter (B1) -------------------------------------

    def test_skills_sh_search_decodes_json_and_uses_urlencoded_free_endpoint(self) -> None:
        payload = json.dumps(
            {
                "query": "视频制作",
                "searchType": "fuzzy",
                "searchVersion": "legacy",
                "skills": [
                    {
                        "id": "genmedia-labs/skills/video-edit",
                        "skillId": "video-edit",
                        "name": "video-edit",
                        "installs": 513911,
                        "source": "genmedia-labs/skills",
                    },
                    {
                        "id": "skills.volces.com/byted-drama",
                        "skillId": "byted-drama",
                        "name": "byted-drama",
                        "installs": 694,
                        "source": "skills.volces.com",
                    },
                ],
            },
            ensure_ascii=False,
        )
        seen: dict[str, str] = {}

        def getter(url: str) -> object:
            seen["url"] = url
            return payload

        hits = _skills_sh_search("视频制作", getter)
        self.assertTrue(seen["url"].startswith(SKILLS_SH_SEARCH_URL + "?"))
        self.assertIn("q=%E8%A7%86%E9%A2%91%E5%88%B6%E4%BD%9C", seen["url"])
        self.assertNotIn("site:github.com", seen["url"])
        self.assertEqual(2, len(hits))
        first = hits[0]
        self.assertEqual(SKILLS_SH_SOURCE, first["source"])
        self.assertEqual("genmedia-labs/skills/video-edit", first["source_id"])
        self.assertEqual("video-edit", first["name"])
        self.assertEqual(513911, first["installs"])
        self.assertEqual("genmedia-labs/skills", first["full_name"])
        # A `source` that is not a GitHub repo stays unresolved instead of crashing.
        self.assertEqual("", hits[1]["full_name"])
        self.assertEqual("skills.volces.com/byted-drama", hits[1]["source_id"])

    def test_skills_sh_search_never_raises_on_bad_payloads(self) -> None:
        bad_payloads = [
            ("not json at all", []),
            ("{broken", []),
            ({"skills": 3}, []),
            ({"skills": None}, []),
            (None, []),
            ([], []),
        ]
        for payload, expected in bad_payloads:
            with self.subTest(payload=payload):
                self.assertEqual(expected, _skills_sh_search("video", lambda _url, p=payload: p))
        weird = _skills_sh_search(
            "video",
            lambda _url: {"skills": [{"id": "a/b", "installs": None, "source": "a/b"}]},
        )
        self.assertEqual(1, len(weird))
        self.assertEqual(0, weird[0]["installs"])
        self.assertTrue(weird[0]["installs_missing"])

    def test_skills_sh_install_floor_qualifies_where_stars_would_fail(self) -> None:
        hit = {
            "name": "video-edit",
            "source_id": "genmedia-labs/skills/video-edit",
            "source": SKILLS_SH_SOURCE,
            "installs": SKILLS_SH_MIN_INSTALLS,
            "stars": 0,
            "skill_md": "# video-edit\n\n剪辑\n",
            "skill_path": "SKILL.md",
            "pushed_at": self.stale,
            "registry": False,
        }
        ok, reason = quality_reason(hit, now=self.now)
        self.assertTrue(ok, reason)
        self.assertIn("installs", reason)
        self.assertTrue(passes_quality(hit, now=self.now))

        low = dict(hit, installs=SKILLS_SH_MIN_INSTALLS - 1)
        ok, reason = quality_reason(low, now=self.now)
        self.assertFalse(ok)
        self.assertEqual(f"installs<{SKILLS_SH_MIN_INSTALLS}", reason)

        # The install branch never rescues a GitHub hit.
        github = {
            "name": "x",
            "source_id": "acme/x",
            "source": "GitHub",
            "stars": MIN_STARS - 1,
            "installs": 10**9,
            "skill_md": "# x\n\nDo the thing.",
            "skill_path": "SKILL.md",
            "pushed_at": self.stale,
        }
        self.assertFalse(passes_quality(github, now=self.now))
        self.assertTrue(passes_quality(dict(github, stars=MIN_STARS), now=self.now))

    def test_github_hits_without_skill_file_still_fail_the_gate(self) -> None:
        hit = {
            "name": "stale-empty",
            "source_id": "old/stale-empty",
            "source": "GitHub",
            "stars": 0,
            "installs": 0,
            "skill_md": "",
            "skill_path": "",
            "url": "https://github.com/old/stale-empty",
            "registry": False,
        }
        ok, reason = quality_reason(hit, now=self.now)
        self.assertFalse(ok)
        self.assertEqual("no_skill_md", reason)

    def test_skills_sh_hits_are_collected_with_source_and_installs(self) -> None:
        self.skills_sh_rows = [
            (
                "剪辑",
                {
                    "id": "genmedia-labs/skills/video-edit",
                    "skillId": "video-edit",
                    "name": "video-edit",
                    "installs": 513911,
                    "source": "genmedia-labs/skills",
                },
            )
        ]

        def getter(url: str) -> object:
            if "genmedia-labs/skills" in url and (
                "raw.githubusercontent.com" in url or "/contents" in url
            ):
                return "# video-edit\n\n视频剪辑 skill\n"
            return self._github_get(url, gap_first_pass=False)

        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-sh",
        )
        rows = [skill for skill in result["skills"] if skill["source"] == SKILLS_SH_SOURCE]
        self.assertTrue(rows, msg=json.dumps(result["skills"], ensure_ascii=False))
        row = rows[0]
        self.assertEqual("genmedia-labs/skills/video-edit", row["source_id"])
        self.assertEqual("video-edit", row["name"])
        self.assertEqual(513911, row["installs"])
        self.assertEqual("SKILL.md", row["skill_path"])
        self.assertIn(SKILLS_SH_SOURCE, {str(skill["source"]) for skill in result["skills"]})
        repos = skills_as_repos(result["skills"])
        # B5: `kind` is the capability category; `source` carries the origin.
        sh_repo = next(item for item in repos if item["full_name"] == "genmedia-labs/skills/video-edit")
        self.assertEqual(SKILLS_SH_SOURCE, sh_repo["source"])
        self.assertEqual("genmedia-labs", sh_repo["owner"])
        self.assertNotEqual(SKILLS_SH_SOURCE, sh_repo["kind"])
        self.assertEqual("视频", sh_repo["kind"])

    def test_monorepo_layout_probes_the_skill_name_not_the_repo_name(self) -> None:
        """D-1: skills.sh monorepos keep skills in sibling dirs.

        `genmedia-labs/skills` hosts `video-edit/SKILL.md`, so substituting the
        repo basename would 404 every probe and reject the source's most popular
        entries.
        """
        repo = "genmedia-labs/skills"
        skill = "video-edit"
        body = "# video-edit\n\nEdit existing video."
        seen: list[str] = []

        def getter(url: str) -> object:
            seen.append(url)
            if url.endswith("/contents"):
                return [{"name": skill, "type": "dir"}, {"name": "README.md", "type": "file"}]
            if url.endswith(f"{skill}/SKILL.md") and "raw.githubusercontent.com" in url:
                return body
            raise RuntimeError("github_http_404")

        reset_skill_finder_state()
        text, path = fetch_skill_md(repo, getter, skill)
        self.assertEqual(body, text)
        self.assertEqual(f"{skill}/SKILL.md", path)
        self.assertTrue(
            any(f"{skill}/SKILL.md" in url for url in seen),
            msg=f"the skill directory was never probed: {seen}",
        )

    def test_rate_limited_candidate_is_not_recorded_as_verified(self) -> None:
        """D-2: a 403 must not fabricate a SKILL.md path that clears the gate.

        Before this fix a rate limit produced `skill_path="SKILL.md"` with empty
        content, which satisfied the gate and made coverage reports claim files
        that were never located.
        """
        reset_skill_finder_state()

        def getter(url: str) -> object:
            raise RuntimeError("github_http_403")

        collected: list[dict[str, object]] = []
        ledger: list[dict[str, object]] = []
        _ingest_repo(
            _repo_item("acme/flood", stars=9999, description="generic skill", pushed_at=self.fresh),
            {"id": "s1", "name": "选题"},
            getter,
            collected,
            set(),
            self.now,
            registry=False,
            ledger=ledger,
        )
        self.assertEqual([], collected, msg="unverified candidate must not be collected")
        self.assertTrue(
            any(row.get("reason") == "no_skill_md" for row in ledger),
            msg=f"expected a no_skill_md rejection, got {ledger}",
        )

    def test_a_declared_skill_path_alone_does_not_clear_the_gate(self) -> None:
        """D-2: evidence must be the located file, not a path string."""
        hit = {
            "name": "unverified",
            "source_id": "acme/unverified",
            "source": "GitHub",
            "stars": MIN_STARS + 100,
            "skill_path": "SKILL.md",
            "url": "https://github.com/acme/unverified",
            "pushed_at": self.fresh,
        }
        ok, reason = quality_reason(hit, now=self.now)
        self.assertFalse(ok)
        self.assertEqual("no_skill_md", reason)
        # Carried-over verification from a previous run is still honoured.
        self.assertTrue(passes_quality(dict(hit, skill_verified=True), now=self.now))
        # ...but a real located file is the normal path.
        self.assertTrue(passes_quality(dict(hit, skill_md="# x"), now=self.now))

    def test_skills_sh_monorepo_siblings_survive_repo_level_dedupe(self) -> None:
        """One skills.sh repo can host many skills; dedupe must key on the skill."""
        reset_skill_finder_state()

        def getter(url: str) -> object:
            if url.endswith("/contents"):
                return [{"name": "video-edit", "type": "dir"}, {"name": "video-script", "type": "dir"}]
            if "raw.githubusercontent.com" in url:
                return "# skill\n\nDo the thing."
            raise RuntimeError("github_http_404")

        collected: list[dict[str, object]] = []
        seen: set[str] = set()
        stage = {"id": "edit", "name": "剪辑"}
        for skill_id in ("acme/skills/video-edit", "acme/skills/video-script"):
            _ingest_repo(
                {
                    "source": SKILLS_SH_SOURCE,
                    "source_id": skill_id,
                    "source_repo": "acme/skills",
                    "full_name": "acme/skills",
                    "name": skill_id.rsplit("/", 1)[-1],
                    "url": f"https://skills.sh/{skill_id}",
                    "installs": 5000,
                },
                stage,
                getter,
                collected,
                seen,
                self.now,
                registry=False,
            )
        self.assertEqual(
            ["video-edit", "video-script"],
            sorted(str(row["name"]) for row in collected),
            msg=f"sibling skills from one repo were deduped away: {collected}",
        )

    def test_stage_floor_keeps_one_call_for_every_later_stage(self) -> None:
        """D-10: a generous per-stage floor must not starve a wide map's tail."""
        class _Budget:
            def __init__(self, max_fetches: int) -> None:
                self.max_fetches = max_fetches
                self.calls = 0
                self.deadline = 0.0

        for budget, stages in ((24, 12), (10, 8), (160, 8)):
            with self.subTest(budget=budget, stages=stages):
                tracker = _Budget(budget)
                shares = []
                for index in range(stages):
                    shares.append(_fair_share(tracker, stages - index))
                    tracker.calls += shares[-1]
                self.assertGreaterEqual(min(shares), 1)
                self.assertLessEqual(sum(shares), budget)

    def test_skills_sh_failure_keeps_github_results_and_degrades(self) -> None:
        cases = (
            ("403", RuntimeError("skills_sh_http_403")),
            ("429", RuntimeError("skills_sh_http_429")),
            ("unreachable", OSError("skills_sh_unreachable")),
            ("timeout", TimeoutError("skills_sh_timeout")),
        )
        for label, failure in cases:
            with self.subTest(label=label):
                reset_skill_finder_state()

                def getter(url: str, failure: Exception = failure) -> object:
                    if "skills.sh" in url:
                        raise failure
                    return self._github_get(url, gap_first_pass=False)

                result = find_skills(
                    "从零做播客",
                    complete=self._complete,
                    github_get=getter,
                    web_search=lambda _query: [],
                    now=self.now,
                    output_root=self.root / f"skills-sh-{label}",
                )
                self.assertTrue(result["degraded"], label)
                reasons = " ".join(str(item) for item in result["degraded_reasons"])
                self.assertIn(SKILLS_SH_SOURCE, reasons, msg=reasons)
                self.assertTrue(result["skills"], label)
                self.assertTrue(
                    all(skill["source"] == "GitHub" for skill in result["skills"]), label
                )
                self.assertTrue(result["stages"], label)

    def test_unparseable_skills_sh_payload_degrades_but_never_raises(self) -> None:
        def getter(url: str) -> object:
            if "skills.sh" in url:
                return {"query": "x", "skills": "not-a-list"}
            return self._github_get(url, gap_first_pass=False)

        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-sh-unparseable",
        )
        self.assertTrue(result["degraded"])
        self.assertIn(f"{SKILLS_SH_SOURCE}:unparseable", result["degraded_reasons"])
        self.assertTrue(result["skills"])

    def test_ingest_accepts_skills_sh_source_without_owner_repo(self) -> None:
        collected: list[dict[str, object]] = []
        seen: set[str] = set()
        ledger: list[dict[str, object]] = []
        _ingest_repo(
            {
                "source": SKILLS_SH_SOURCE,
                "source_id": "skills.volces.com/byted-drama",
                "name": "byted-drama",
                "installs": 694,
                "plain": True,
                "url": "https://skills.sh/skills.volces.com/byted-drama",
            },
            {"id": "edit", "name": "剪辑"},
            lambda _url: None,
            collected,
            seen,
            self.now,
            registry=False,
            ledger=ledger,
        )
        # No locatable SKILL.md: kept out of the results, but the reason is recorded.
        self.assertEqual([], collected)
        self.assertEqual(1, len(ledger))
        self.assertEqual("no_skill_md", ledger[0]["reason"])
        self.assertEqual("skills.volces.com/byted-drama", ledger[0]["source_id"])

    def test_names_from_web_preserves_non_github_links(self) -> None:
        refs = _names_from_web(
            [
                {"url": "https://github.com/acme/foo", "title": "foo"},
                {"url": "https://github.com/acme/foo/blob/main/README.md", "title": "dupe"},
                {"url": "https://skills.sh/genmedia-labs/skills/video-edit", "title": "video"},
                {"url": "https://skills.sh/trending", "title": "trending"},
                {"url": "https://example.com/blog/skill", "title": "other"},
            ]
        )
        self.assertEqual(
            ["GitHub", SKILLS_SH_SOURCE, SKILLS_SH_SOURCE, "web"],
            [ref["source"] for ref in refs],
        )
        self.assertEqual("acme/foo", refs[0]["full_name"])
        self.assertEqual("genmedia-labs/skills", refs[1]["full_name"])
        self.assertEqual("video-edit", refs[1]["name"])
        self.assertEqual("genmedia-labs/skills/video-edit", refs[1]["source_id"])
        self.assertEqual("trending", refs[2]["section"])
        self.assertEqual("https://example.com/blog/skill", refs[3]["url"])

    def test_skill_md_probes_every_documented_layout(self) -> None:
        name = "video-edit"
        self.assertEqual(
            (
                "SKILL.md",
                "{name}/SKILL.md",
                ".agents/skills/{name}/SKILL.md",
                ".claude/skills/{name}/SKILL.md",
                "skills/{name}/SKILL.md",
                ".cursor/skills/{name}/SKILL.md",
            ),
            SKILL_PATHS,
        )
        for template in SKILL_PATHS:
            path = template.format(name=name)
            with self.subTest(layout=path):

                def getter(url: str, path: str = path) -> object:
                    if "/HEAD/" in url:
                        tail = url.split("/HEAD/", 1)[-1]
                    elif "/contents/" in url:
                        tail = url.rsplit("/contents/", 1)[-1]
                    else:
                        tail = url
                    if tail == path:
                        return f"# {name}\n\n视频剪辑\n"
                    raise RuntimeError("github_fetch_failed:404")

                text, found = fetch_skill_md(f"acme/{name}", getter)
                self.assertIn("视频剪辑", text)
                self.assertEqual(path, found)

    def test_nested_layouts_are_only_probed_when_the_root_listing_advertises_them(self) -> None:
        calls: list[str] = []

        def getter(url: str) -> object:
            calls.append(url)
            if url.endswith("/contents"):
                return [{"name": "README.md", "type": "file"}]
            raise RuntimeError("github_fetch_failed:404")

        self.assertEqual(("", ""), fetch_skill_md("acme/video-edit", getter))
        self.assertTrue(any(url.endswith("/contents") for url in calls))
        self.assertFalse(any("skills/video-edit" in url for url in calls))

        nested = ".claude/skills/video-edit/SKILL.md"

        def advertised(url: str) -> object:
            if url.endswith("/contents"):
                return [{"name": ".claude", "type": "dir"}]
            if url.endswith("/contents/" + nested):
                return "# nested\n\n视频剪辑\n"
            raise RuntimeError("github_fetch_failed:404")

        text, found = fetch_skill_md("acme/video-edit", advertised)
        self.assertIn("nested", text)
        self.assertEqual(nested, found)

    def test_wide_coverage_map_still_searches_tail_stages(self) -> None:
        stages = [
            {
                "id": f"stage-{index:02d}",
                "name": f"模块{index}",
                "queries": [f"模块{index} 检索词"],
                "required": True,
            }
            for index in range(1, 13)
        ]

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                return json.dumps({"title": "宽覆盖", "body": "AIGC"}, ensure_ascii=False)
            return json.dumps(
                {"goal": "宽覆盖", "title": "宽覆盖", "theme": "宽覆盖", "chain": [], "stages": stages},
                ensure_ascii=False,
            )

        searched: list[str] = []

        def getter(url: str) -> object:
            parsed = urlparse(url)
            if parsed.netloc == SKILLS_SH_SOURCE:
                searched.append(parse_qs(parsed.query).get("q", [""])[0])
                return {"skills": []}
            if parsed.netloc == "api.github.com" and parsed.path == "/search/repositories":
                searched.append(parse_qs(parsed.query).get("q", [""])[0])
                return {"items": []}
            if "anthropics/skills" in url:
                return []
            return {}

        result = find_skills(
            "宽覆盖检索",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-wide",
            max_fetches=36,
            fetch_deadline_seconds=30,
        )
        self.assertIn("模块12", " ".join(searched))
        self.assertEqual(12, len(result["stages"]))
        self.assertTrue(all(stage["gap"] for stage in result["stages"]))
        self.assertTrue(all(stage.get("fetches", 0) >= 1 for stage in result["stages"]))
        budget = result["budget"]
        self.assertEqual(36, budget["max_fetches"])
        self.assertLessEqual(budget["calls"], 36)
        self.assertGreaterEqual(budget["stage_quota_skips"], 1)
        self.assertFalse(result["degraded"], msg=str(result["degraded_reasons"]))
        # one row per stage per pass (12 first pass + 12 gap-fill pass)
        self.assertEqual(24, len(budget["stages"]))

    def test_snapshot_exposes_budget_consumption_and_rejections(self) -> None:
        self.skills_sh_rows = [
            (
                "剪辑",
                {
                    "id": "tiny/skills/weak-skill",
                    "skillId": "weak-skill",
                    "name": "weak-skill",
                    "installs": 3,
                    "source": "tiny/skills",
                },
            )
        ]

        def getter(url: str) -> object:
            if "tiny/skills" in url and (
                "raw.githubusercontent.com" in url or "/contents" in url
            ):
                return "# weak-skill\n\n视频剪辑\n"
            return self._github_get(url, gap_first_pass=True)

        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills-observable",
        )
        budget = result["budget"]
        self.assertEqual(MAX_FETCHES, budget["max_fetches"])
        self.assertGreater(budget["calls"], 0)
        self.assertEqual(budget["calls"], budget["fetch_calls"] + budget["search_calls"])
        self.assertLessEqual(sum(int(row["calls"]) for row in budget["stages"]), budget["calls"])
        self.assertTrue(any(int(row["calls"]) >= 1 for row in budget["stages"]))
        rejected = result["rejected"]
        self.assertIsInstance(rejected, list)
        self.assertTrue(rejected)
        self.assertEqual("tiny/skills/weak-skill", rejected[0]["source_id"])
        self.assertEqual(f"installs<{SKILLS_SH_MIN_INSTALLS}", rejected[0]["reason"])
        self.assertTrue(all(row.get("reason") for row in rejected))
        self.assertLessEqual(len(rejected), 20)

    def test_source_level_grep_finds_no_github_filtered_skills_sh_template(self) -> None:
        module_path = Path(sys.modules["autoposting.skill_finder"].__file__).resolve()
        grep = (
            "import pathlib, sys\n"
            "lines = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8').splitlines()\n"
            "mentions = [i + 1 for i, line in enumerate(lines) if 'skills.sh' in line]\n"
            "filtered = [i for i in mentions if 'site:github.com' in lines[i - 1]]\n"
            "print(len(mentions))\n"
            "print(','.join(str(i) for i in filtered))\n"
        )
        done = subprocess.run(
            [sys.executable, "-c", grep, str(module_path)],
            capture_output=True,
            text=True,
            check=True,
        )
        lines = done.stdout.splitlines()
        mention_count = int(lines[0])
        filtered_lines = lines[1] if len(lines) > 1 else ""
        self.assertGreaterEqual(mention_count, 1)
        self.assertEqual("", filtered_lines)
        # The dispatch table itself: GitHub keeps the filter, skills.sh has none.
        self.assertIn("site:github.com", SEARCH_TEMPLATES["github"]("视频制作"))
        self.assertEqual("视频制作", SEARCH_TEMPLATES[SKILLS_SH_SOURCE]("视频制作"))
        self.assertNotIn("github.com", SEARCH_TEMPLATES[SKILLS_SH_SOURCE]("视频制作"))

    def test_budget_stage_slices_are_fair_and_observable(self) -> None:
        budget = _FetchBudget(
            lambda _url: {},
            lambda _query: [],
            max_fetches=12,
            deadline=time.monotonic() + 30,
        )
        budget.start_stage("a", "甲", 4)
        budget.get("https://example.test/a-1")
        budget.get("https://example.test/a-2")
        self.assertEqual(2, budget.end_stage())
        budget.start_stage("b", "乙", 0)
        with self.assertRaises(RuntimeError):
            budget.get("https://example.test/b-1")
        self.assertEqual(0, budget.end_stage())
        report = budget.report()
        self.assertEqual(1, report["stage_quota_skips"])
        self.assertFalse(report["degraded"])
        self.assertEqual([2, 0], [row["calls"] for row in report["stages"]])

    def test_stage_time_slice_also_hands_every_stage_real_time(self) -> None:
        budget = _FetchBudget(
            lambda _url: {},
            lambda _query: [],
            max_fetches=100,
            deadline=time.monotonic() + 30,
        )
        budget.start_stage("a", "甲", 100, seconds=0.0)
        with self.assertRaises(RuntimeError):
            budget.get("https://example.test/a-1")
        self.assertEqual(0, budget.end_stage())
        self.assertEqual(1, budget.stage_quota_skips)
        # Running out of a stage's own slice is not an upstream failure.
        self.assertFalse(budget.degraded)
        self.assertTrue(budget.remaining())

    def test_skills_sh_rows_are_capped_per_query(self) -> None:
        payload = {
            "skills": [
                {
                    "id": f"acme/skills/s{index}",
                    "name": f"s{index}",
                    "installs": 1000 - index,
                    "source": "acme/skills",
                }
                for index in range(60)
            ]
        }
        hits = _skills_sh_search("video", lambda _url: payload)
        self.assertEqual(SKILLS_SH_PER_QUERY, len(hits))
        self.assertEqual("acme/skills/s0", hits[0]["source_id"])


class SkillPosterCopyTests(unittest.TestCase):
    """B5: skill posters must carry valid, per-skill text — not repeated filler."""

    SKILLS = [
        {
            "name": "douyin-video",
            "source_id": "yzfly/douyin-mcp-server/douyin-video",
            "source": "skills.sh",
            "installs": 1857,
            "stage_name": "剪辑",
            "url": "https://skills.sh/yzfly/douyin-mcp-server/douyin-video",
            "description": "Download and edit Douyin videos",
            "skill_excerpt": "Use this skill to clip short videos.",
        },
        {
            "name": "video-script",
            "source_id": "acme/video-script",
            "source": "GitHub",
            "installs": 300,
            "stage_name": "脚本与分镜",
            "url": "https://github.com/acme/video-script",
            "description": "把口播稿拆成分镜表",
            "skill_excerpt": "先读选题。\n再按 30 秒一段拆镜头。",
        },
        {
            "name": "thumbnail-kit",
            "source_id": "acme/thumbnail-kit",
            "source": "GitHub",
            "installs": 120,
            "stage_name": "封面与标题",
            "url": "https://github.com/acme/thumbnail-kit",
            "description": "批量生成视频封面",
        },
        {
            "name": "voice-over",
            "source_id": "acme/voice-over",
            "source": "skills.sh",
            "installs": 900,
            "stage_name": "配音与字幕",
            "url": "https://skills.sh/acme/voice-over",
            "description": "generate voiceover audio",
        },
        {
            "name": "review-metrics",
            "source_id": "acme/review-metrics",
            "source": "GitHub",
            "installs": 400,
            "stage_name": "数据复盘",
            "url": "https://github.com/acme/review-metrics",
            "description": "视频数据复盘看板和结论",
        },
    ]

    def test_kind_is_a_capability_category_never_the_source(self) -> None:
        rows = skills_as_repos(self.SKILLS)
        kinds = [str(row["kind"]) for row in rows]
        for kind in kinds:
            self.assertNotIn(kind, {"GitHub", "registry", "skills.sh"})
        # Distinct capabilities for genuinely different skills.
        self.assertIn("视频", kinds)
        self.assertIn("写作", kinds)
        self.assertIn("图像", kinds)
        self.assertEqual(len(set(kinds)), len(kinds))

    def test_every_poster_board_is_pairwise_distinct(self) -> None:
        from autoposting.visual.adapter import project_from_repo

        payloads = [project_from_repo(row) for row in skills_as_repos(self.SKILLS)]
        self.assertEqual(len(self.SKILLS), len(payloads))
        for field in ("category", "keyMessage", "features", "how", "audience", "scene"):
            values = [json.dumps(payload[field], ensure_ascii=False) for payload in payloads]
            self.assertEqual(
                len(values),
                len(set(values)),
                msg=f"{field} 在两个 skill 之间完全相同：{values}",
            )
        for payload in payloads:
            self.assertTrue(str(payload["keyMessage"]).strip())
            self.assertTrue(payload["features"])
            self.assertTrue(payload["how"])
            self.assertTrue(payload["audience"])
            # No English may leak onto a Chinese poster.
            for board in ("features", "how", "audience", "scene"):
                for row in payload[board]:
                    self.assertRegex(str(row), r"[\u4e00-\u9fff]", msg=f"{board} 出现非中文条目 {row!r}")

    def test_render_plan_carries_no_github_weekly_branding(self) -> None:
        import re
        import tempfile

        with tempfile.TemporaryDirectory() as raw:
            out = Path(raw)

            def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
                png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
                return png_path

            snapshot = {
                "title": "视频制作技能包",
                "theme": "从选题到发布",
                "stages": [
                    {"id": "edit", "name": "剪辑"},
                    {"id": "cover", "name": "封面与标题", "gap": True, "gap_reason": GAP_REASON},
                ],
                "skills": self.SKILLS[:2],
            }
            cards = render_skill_package(snapshot, out, screenshot_fn=fake_shot)
            self.assertEqual(len(self.SKILLS[:2]) + 1, len(cards))
            self.assertEqual("cover", cards[0]["kind"])
            for html_path in out.glob("*.html"):
                text = html_path.read_text(encoding="utf-8")
                self.assertNotIn("GitHub", text, msg=f"{html_path.name} 印了 GitHub 周榜品牌")
                self.assertIsNone(
                    re.search(r"20\d\d年第", text), msg=f"{html_path.name} 印了周次"
                )
                self.assertNotIn("01 / 11", text, msg=f"{html_path.name} 页码写死")
                self.assertNotIn("9:16", text)
            cover = (out / "cover.html").read_text(encoding="utf-8")
            self.assertIn("SKILL FINDER", cover)
            self.assertIn("c-smart-cover-kicker", cover)
            poster = (out / "01-douyin-video.html").read_text(encoding="utf-8")
            # page number total is the real package size, not a hardcoded 11
            self.assertIn("02 / 03", poster)

    def test_degenerate_inputs_still_produce_distinct_boards(self) -> None:
        """Adversarial B5: a batch must never print the same board twice.

        Real searches can return several skills with the same capability, the
        same stage, or even the same source description. Every poster still has
        to be tellable apart without inventing capabilities.
        """
        from autoposting.visual.adapter import project_from_repo

        cases = {
            "english-only same category": [
                {
                    "name": f"video-tool-{i}",
                    "source_id": f"acme/video-tool-{i}",
                    "installs": 100 + i,
                    "stage_name": f"阶段{i}",
                    "description": "video editing automation tool",
                    "skill_excerpt": "Use this to edit videos.",
                }
                for i in range(1, 6)
            ],
            "no stage and no description": [
                {"name": f"skill-{i}", "source_id": f"acme/skill-{i}", "installs": 10}
                for i in range(1, 6)
            ],
            "identical description, different stages": [
                {
                    "name": f"dup-{i}",
                    "source_id": f"acme/dup-{i}",
                    "installs": 50,
                    "stage_name": f"环节{i}",
                    "description": "批量生成视频封面",
                }
                for i in range(1, 4)
            ],
            "identical description and stage": [
                {
                    "name": f"same-{i}",
                    "source_id": f"acme/same-{i}",
                    "installs": 50,
                    "stage_name": "封面",
                    "description": "批量生成视频封面",
                }
                for i in range(1, 6)
            ],
        }
        for label, skills in cases.items():
            with self.subTest(case=label):
                payloads = [project_from_repo(row) for row in skills_as_repos(skills)]
                self.assertEqual(len(skills), len(payloads))
                for field in ("keyMessage", "features", "how", "audience", "scene"):
                    values = [json.dumps(payload[field], ensure_ascii=False) for payload in payloads]
                    self.assertEqual(
                        len(values), len(set(values)), msg=f"{label}: {field} 重复 —— {values}"
                    )
                for payload in payloads:
                    # Labels may be spliced in, but no label may stack twice.
                    joined = " ".join(
                        str(item) for board in ("features", "how", "audience", "scene")
                        for item in payload[board]
                    )
                    self.assertNotIn("这一环，接手", joined)
                    self.assertLessEqual(joined.count("这一步要用的材料备齐"), 1)

    def test_install_count_is_the_popularity_signal(self) -> None:
        rows = skills_as_repos(self.SKILLS[:1])
        self.assertEqual(1857, rows[0]["stars"])
        self.assertEqual("1.9k", rows[0]["stars_label"])
        self.assertEqual(1857, rows[0]["installs"])

    def test_copy_layer_is_shared_with_the_weekly_lane(self) -> None:
        import tempfile

        seen: list[list[dict[str, object]]] = []

        def copy_writer(repos: list[dict[str, object]]) -> list[dict[str, object]]:
            seen.append(repos)
            return [
                dict(repo, summary="给做短视频的人，要交片的时候，把粗剪先做出来。",
                     does="按脚本排好素材。\n切出可用片段。", how="把素材放进去跑一遍。",
                     audience="一个人管多个账号的运营。", scene="素材堆着又要赶交期的时候。")
                for repo in repos
            ]

        with tempfile.TemporaryDirectory() as raw:
            def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
                png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
                return png_path

            render_skill_package(
                {"title": "t", "stages": [], "skills": self.SKILLS[:1]},
                Path(raw),
                screenshot_fn=fake_shot,
                copy_writer=copy_writer,
            )
        self.assertEqual(1, len(seen))
        self.assertTrue(seen[0][0]["full_name"])
        # The weekly copy merge matches on full_name, so the skill lane must set it.
        self.assertEqual("yzfly/douyin-mcp-server/douyin-video", seen[0][0]["full_name"])

    def test_rerender_prunes_pages_that_are_no_longer_in_the_package(self) -> None:
        """A shrinking result set must not leave last query's pages behind.

        The lane reuses one package directory (and a shared `latest`), so stale
        `*.html`/`*.png` would keep the previous page totals visible next to the
        new ones.
        """
        import tempfile

        with tempfile.TemporaryDirectory() as raw:
            out = Path(raw)

            def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
                png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
                return png_path

            first = render_skill_package(
                {"title": "t", "stages": [], "skills": self.SKILLS[:3]},
                out,
                screenshot_fn=fake_shot,
            )
            self.assertEqual(4, len(first))
            stale_html = out / "03-thumbnail-kit.html"
            self.assertTrue(stale_html.is_file())

            second = render_skill_package(
                {"title": "t", "stages": [], "skills": self.SKILLS[:1]},
                out,
                screenshot_fn=fake_shot,
            )
            self.assertEqual(2, len(second))
            self.assertFalse(stale_html.is_file(), msg="上一轮的页面没有被清掉")
            self.assertFalse((out / "03-thumbnail-kit.png").exists())
            self.assertEqual(
                ["01-douyin-video.html", "01-douyin-video.png", "cover.html", "cover.png"],
                sorted(path.name for path in out.iterdir()),
            )

    def test_copy_writer_failure_keeps_template_copy(self) -> None:
        import tempfile

        def boom(repos: list[dict[str, object]]) -> list[dict[str, object]]:
            raise LLMError("llm_api_failed", "模型挂了")

        with tempfile.TemporaryDirectory() as raw:
            def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
                png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
                return png_path

            cards = render_skill_package(
                {"title": "t", "stages": [], "skills": self.SKILLS[:1]},
                Path(raw),
                screenshot_fn=fake_shot,
                copy_writer=boom,
            )
        self.assertEqual(2, len(cards))


class ManualSkillPasteTests(unittest.TestCase):
    """Pasted links are user state: they must reach intro, stage and poster."""

    def setUp(self) -> None:
        reset_skill_finder_state()
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def _getter(self):
        calls: list[str] = []

        def getter(url: str) -> object:
            calls.append(url)
            if url.endswith("/artifacts-builder/SKILL.md"):
                return "# artifacts-builder\n\n用组件搭可视化页面，做数据看板。\n"
            if url.endswith("/video-edit/SKILL.md"):
                return "# video-edit\n\n剪掉废话，按短视频节奏重排时间线。\n"
            if url.endswith("/alpha/SKILL.md"):
                return "# alpha\n\n写口播稿。\n"
            if url.endswith("/beta/SKILL.md"):
                return "# beta\n\n做封面标题。\n"
            if url.endswith("/repos/acme/toolkit"):
                return {
                    "full_name": "acme/toolkit",
                    "description": "视频工具箱",
                    "stargazers_count": 120,
                    "html_url": "https://github.com/acme/toolkit",
                    "pushed_at": "2026-09-01T00:00:00Z",
                    "owner": {"avatar_url": "https://avatars.example/acme.png"},
                    "topics": ["video"],
                }
            raise RuntimeError("github_fetch_failed:404")

        return getter, calls

    def _snapshot(self) -> dict[str, object]:
        return {
            "query": "从零做播客",
            "title": "从零做播客技能包",
            "theme": "播客从选题到上线",
            "stages": [
                {"id": "topic", "name": "选题", "queries": ["播客选题"], "required": True},
                {"id": "edit", "name": "剪辑", "queries": ["视频剪辑"], "required": True},
            ],
            "skills": [],
            "article": {"title": "从零做播客技能包", "body": "旧介绍文"},
            "images": [{"id": "cover", "url": "/api/generated/skills/cover.png"}],
            "phase": "done",
        }

    def test_pasted_links_join_the_package_with_intro_and_stage(self) -> None:
        getter, _calls = self._getter()
        candidates, rejects = parse_skill_links(
            "https://github.com/anthropics/skills/tree/main/artifacts-builder\n"
            "https://github.com/acme/toolkit/blob/main/video-edit/SKILL.md"
        )
        self.assertEqual([], rejects)
        result = add_manual_skills(self._snapshot(), candidates, getter=getter)
        names = [str(row["name"]) for row in result["skills"]]
        self.assertEqual(["artifacts-builder", "video-edit"], names)
        for row in result["skills"]:
            self.assertTrue(row["manual"], msg="粘贴的 skill 必须标记为 manual")
            self.assertTrue(str(row["skill_excerpt"]).strip(), msg="海报文案要有 SKILL.md 摘要")
            self.assertEqual("手动补充", row["stage_name"])
        stages = {str(stage["id"]): stage for stage in result["stages"]}
        self.assertIn("manual", stages)
        self.assertFalse(stages["manual"]["gap"], msg="有 skill 的手动补充环节不能算缺口")
        body = str(result["article"]["body"])
        self.assertIn("artifacts-builder", body)
        self.assertIn("video-edit", body)
        self.assertEqual("从零做播客技能包", result["article"]["title"])
        self.assertEqual([], result["images"], msg="旧海报作废，等重新出图")
        self.assertEqual("skills_ready", result["phase"])
        self.assertEqual(2, len(result["manual_skills"]))

    def test_monorepo_siblings_both_enter_the_package(self) -> None:
        """Two skills pasted from one repo are two skills, not one."""
        getter, _calls = self._getter()
        candidates, rejects = parse_skill_links(
            "https://github.com/acme/monorepo/tree/main/alpha\n"
            "https://github.com/acme/monorepo/tree/main/beta"
        )
        self.assertEqual([], rejects)
        self.assertEqual(2, len(candidates))
        result = add_manual_skills(self._snapshot(), candidates, getter=getter)
        names = sorted(str(row["name"]) for row in result["skills"])
        self.assertEqual(["alpha", "beta"], names)
        self.assertEqual(2, len(result["manual_skills"]))
        self.assertEqual(0, result["paste_replaced"], msg="同仓库的新兄弟是新增，不是替换")
        # Re-pasting one of them replaces just that slot.
        again = add_manual_skills(result, candidates[:1], getter=getter)
        self.assertEqual(2, len(again["skills"]))
        self.assertEqual(2, len(again["manual_skills"]))
        self.assertEqual(1, again["paste_replaced"], msg="同一槽位重复粘贴才算替换")

    def test_pasted_skill_description_skips_front_matter(self) -> None:
        """A SKILL.md starts with YAML; the description must be prose, not `name:`."""
        from autoposting.skill_finder import _first_paragraph

        markdown = (
            "---\n"
            "name: web-artifacts-builder\n"
            "description: build artifacts\n"
            "license: MIT\n"
            "---\n\n"
            "# web-artifacts-builder\n\n"
            "用组件搭可视化页面，做数据看板。\n"
        )
        self.assertEqual("用组件搭可视化页面，做数据看板。", _first_paragraph(markdown))

    def test_pasted_skill_reaches_the_poster_plan(self) -> None:
        getter, _calls = self._getter()
        candidates, _rejects = parse_skill_links("https://github.com/acme/toolkit/tree/main/video-edit")
        result = add_manual_skills(self._snapshot(), candidates, getter=getter)

        def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
            png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
            return png_path

        cards = render_skill_package(result, self.root, screenshot_fn=fake_shot)
        self.assertEqual(2, len(cards), msg="封面 + 每个收录 skill 一张项目卡")
        self.assertEqual("cover", cards[0]["kind"])
        self.assertEqual("poster", cards[1]["kind"])
        self.assertIn("video-edit", str(cards[1]["id"]))

    def test_repeated_paste_replaces_instead_of_duplicating(self) -> None:
        getter, _calls = self._getter()
        candidates, _rejects = parse_skill_links("https://github.com/acme/toolkit/tree/main/video-edit")
        first = add_manual_skills(self._snapshot(), candidates, getter=getter)
        second = add_manual_skills(first, candidates, getter=getter)
        self.assertEqual(1, len(second["skills"]))
        self.assertEqual(1, len(second["manual_skills"]))

    def test_paste_works_without_a_search_and_without_a_model(self) -> None:
        getter, _calls = self._getter()
        candidates, _rejects = parse_skill_links("https://github.com/acme/toolkit/tree/main/video-edit")
        result = add_manual_skills(None, candidates, getter=getter)
        self.assertEqual(1, len(result["skills"]))
        self.assertEqual("skills_ready", result["phase"])
        self.assertEqual("手动补充", result["stages"][0]["name"])
        self.assertTrue(str(result["article"]["body"]).strip())
        self.assertIn("video-edit", str(result["article"]["body"]))

    def test_paste_writes_the_package_directory(self) -> None:
        getter, _calls = self._getter()
        candidates, _rejects = parse_skill_links("https://github.com/acme/toolkit/tree/main/video-edit")
        result = add_manual_skills(
            self._snapshot(), candidates, getter=getter, output_root=self.root / "skills"
        )
        package = Path(str(result["package_path"]))
        self.assertTrue(package.is_dir())
        self.assertIn("video-edit", (package / "article.md").read_text(encoding="utf-8"))
        self.assertTrue((package / "skills" / "acme-toolkit.md").is_file())

    def test_cap_keeps_pasted_skills_and_a_search_reinjects_them(self) -> None:
        manual = {
            "name": "video-edit",
            "source_id": "acme/toolkit",
            "manual": True,
            "stage_id": "edit",
            "skill_md": "# video-edit\n\n剪辑。\n",
        }
        many = [
            {
                "name": f"skill-{index}",
                "source_id": f"acme/skill-{index}",
                "stage_id": "topic",
                "stars": 500 - index,
            }
            for index in range(24)
        ]
        kept = cap_skills(many + [manual], PODCAST_STAGES)
        self.assertEqual(16, len(kept))
        self.assertIn(manual, kept, msg="粘贴的 skill 不能被热度排序挤掉")

        reuses = 0

        def complete(prompt: str) -> str:
            nonlocal reuses
            reuses += 1
            return _coverage_json()

        def getter(_url: str) -> object:
            raise RuntimeError("github_fetch_failed:offline")

        result = find_skills(
            "从零做播客",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            output_root=self.root / "skills",
            previous={"manual_skills": [manual], "query": "从零做播客"},
        )
        names = [str(row["name"]) for row in result["skills"]]
        self.assertIn("video-edit", names, msg="再查一次也要保住粘贴的 skill")
        manual_rows = [row for row in result["skills"] if row.get("manual")]
        self.assertEqual(1, len(manual_rows))
        self.assertGreaterEqual(reuses, 1)

    def test_stage_matching_puts_a_pasted_skill_in_its_coverage_stage(self) -> None:
        getter, _calls = self._getter()
        candidates, _rejects = parse_skill_links("https://github.com/acme/toolkit/tree/main/video-edit")
        snapshot = self._snapshot()
        snapshot["stages"] = [
            {"id": "edit", "name": "剪辑", "queries": ["剪掉废话"], "required": True},
        ]
        result = add_manual_skills(snapshot, candidates, getter=getter)
        self.assertEqual("edit", result["skills"][0]["stage_id"])
        self.assertEqual("剪辑", result["skills"][0]["stage_name"])


class _MemoryCredentialStore:
    """Offline stand-in for the macOS keychain used by the web API tests."""

    def __init__(self) -> None:
        self.values: dict[str, str] = {}

    def get(self, endpoint_id: str) -> str | None:
        return self.values.get(endpoint_id)

    def set(self, endpoint_id: str, api_key: str) -> None:
        self.values[endpoint_id] = api_key

    def delete(self, endpoint_id: str) -> None:
        self.values.pop(endpoint_id, None)


class SkillFinderApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.db = Database(self.root / "autoposting.db")
        self.db.initialize()
        self.sources = (
            Source("lab_blog", "AI Lab", "rss", "https://lab.example/feed.xml", "S1", ("models",), True, 15),
        )
        for source in self.sources:
            self.db.upsert_source(source)
        self.credentials = _MemoryCredentialStore()
        self.fetched: list[str] = []

        def github_get(url: str) -> object:
            self.fetched.append(url)
            if url.endswith("/video-edit/SKILL.md"):
                return "# video-edit\n\n剪掉废话，按短视频节奏重排时间线。\n"
            if url.endswith("/repos/acme/toolkit"):
                return {
                    "full_name": "acme/toolkit",
                    "description": "视频工具箱",
                    "stargazers_count": 120,
                    "html_url": "https://github.com/acme/toolkit",
                    "pushed_at": "2026-09-01T00:00:00Z",
                    "owner": {"avatar_url": "https://avatars.example/acme.png"},
                }
            raise RuntimeError("github_fetch_failed:404")

        self.app = WebApp(
            self.db,
            self.sources,
            self.root / "packages",
            fetcher=lambda _: b"",
            page_fetcher=lambda _: b"",
            github_fetcher=github_get,
            credential_store=self.credentials,
        )
        self.server = create_server(self.app, "127.0.0.1", 0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.temp_dir.cleanup()

    def _request(self, method: str, path: str, payload: object = None) -> tuple[int, dict[str, object]]:
        body = None
        headers = {}
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.base_url + path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read().decode("utf-8"))

    def test_skills_lane_has_paste_box_and_github_token_box(self) -> None:
        """Pasted links and the optional token live in the skills lane only."""
        html = INDEX_HTML
        self.assertIn('id="skill-links"', html)
        self.assertIn('id="skill-paste-btn"', html)
        self.assertIn('id="skill-paste-hint"', html)
        self.assertIn("/api/skills/paste", html)
        self.assertIn('id="skill-token-box"', html)
        self.assertIn('id="skill-github-token"', html)
        self.assertIn("/api/skills/github-token", html)
        # Same lane scoping as the search row: hidden by default, shown only in 技能栏.
        self.assertRegex(
            html,
            r"#skill-search-row,[^{]*#skill-stage-chips[^{]*#skill-paste-row[^{]*"
            r"#skill-paste-hint[^{]*#skill-token-box[^{]*\{[^}]*display:none",
        )
        self.assertIn("body.lane-skills #skill-paste-row{display:flex", html)
        self.assertIn("body.lane-skills #skill-token-box{display:block", html)
        # Pasting runs the same two steps a search does: package first, then posters.
        paste = html[html.index("function pasteSkills()") : html.index("function openSkillsLightbox(")]
        self.assertIn("renderSkillPackage(data)", paste)
        self.assertIn("renderSkillImages()", paste)
        self.assertIn('$("skill-links").value = ""', paste)
        self.assertIn("data.unverified", paste)
        self.assertIn("没读到 SKILL.md", paste)
        self.assertIn('$("skill-paste-btn").addEventListener("click", pasteSkills)', html)
        self.assertIn('$("skill-token-save").addEventListener("click", saveGithubToken)', html)
        self.assertIn('$("skill-token-clear").addEventListener("click", clearGithubToken)', html)

    def test_degraded_note_speaks_chinese_not_reason_tokens(self) -> None:
        """`github:rate_limited` must not reach the page as a raw token."""
        html = INDEX_HTML
        self.assertIn("function degradeLabel(", html)
        self.assertIn("function degradedSummary(", html)
        self.assertIn('"github:rate_limited"', html)
        self.assertIn("GitHub 接口限流", html)
        self.assertIn("配置 GitHub Token", html)
        note_fn = html[html.index("function degradedSummary(") : html.index("function renderSkillPackage(")]
        self.assertIn("githubTokenConfigured", note_fn)
        render = html[html.index("function renderSkillPackage(") : html.index("function queuedSkillImages(")]
        self.assertIn("degradedSummary(reasons)", render)
        self.assertIn("degradedNote.title = reasons.join", render)

    def test_gap_note_explains_candidates_that_ran_out_of_time(self) -> None:
        """A gap caused by the time slice must not read as 'nothing exists'."""
        html = INDEX_HTML
        note_fn = html[html.index("function renderSkillPackage(") : html.index("function queuedSkillImages(")]
        self.assertIn('"stage_quota"', note_fn)
        self.assertIn("pack.rejected", note_fn)
        self.assertIn("因为本轮检索时间用完没能验证", note_fn)

    def test_search_rejects_empty_query(self) -> None:
        status, payload = self._request("POST", "/api/skills/search", {"query": ""})
        self.assertEqual(400, status)
        self.assertFalse(payload["ok"])

    def test_paste_endpoint_adds_links_to_the_package(self) -> None:
        status, payload = self._request(
            "POST",
            "/api/skills/paste",
            {"links": "https://github.com/acme/toolkit/tree/main/video-edit"},
        )
        self.assertEqual(200, status)
        self.assertTrue(payload["ok"])
        self.assertEqual(1, payload["added"])
        self.assertEqual(1, payload["count"])
        skill = (payload.get("skills") or [])[0]
        self.assertEqual("video-edit", skill["name"])
        self.assertTrue(skill["manual"])
        self.assertIn("video-edit", str((payload.get("article") or {}).get("body")))
        self.assertIn("manual", [str(stage["id"]) for stage in payload["stages"]])
        saved = self.app.database.get_skill_finder() or {}
        self.assertEqual(1, len(saved.get("manual_skills") or []))
        # The package directory is written too, so 出图 has a package to fill.
        self.assertTrue(Path(str(payload["package_path"])).is_dir())

    def test_paste_endpoint_reports_unusable_links(self) -> None:
        status, payload = self._request(
            "POST", "/api/skills/paste", {"links": "https://gitlab.com/a/b\n你好"}
        )
        self.assertEqual(200, status)
        self.assertEqual(0, payload["added"])
        reasons = {row["reason"] for row in payload.get("rejected") or []}
        self.assertEqual({"unsupported_host", "not_a_link"}, reasons)

    def test_paste_endpoint_validates_input(self) -> None:
        self.assertEqual(400, self._request("POST", "/api/skills/paste", {"links": ""})[0])
        self.assertEqual(400, self._request("POST", "/api/skills/paste", {"links": 3})[0])
        self.assertEqual(
            400, self._request("POST", "/api/skills/paste", {"links": "x" * 4001})[0]
        )

    def test_paste_result_has_its_own_visible_line(self) -> None:
        """The render overwrites the shared status line, so the paste result needs its own."""
        html = INDEX_HTML
        self.assertIn('id="skill-paste-status"', html)
        self.assertRegex(
            html,
            r"#skill-paste-hint[^{]*#skill-paste-status[^{]*#skill-token-box[^{]*\{[^}]*display:none",
        )
        self.assertIn("body.lane-skills #skill-paste-status:not([hidden]){display:block;}", html)
        self.assertIn('$("skill-paste-status")', html)
        self.assertIn("node.hidden = !text;", html)
        paste = html[html.index("function setPasteStatus(") : html.index("function renderGithubTokenState(")]
        self.assertIn("setPasteStatus", paste)
        self.assertIn('setPasteStatus(summary', paste)
        self.assertIn("替换 ", paste)
        # The input is not truncated by the browser any more: the client checks the
        # length itself so a cut-off tail cannot become a phantom repo.
        links_input = html[html.index('id="skill-links"') : html.index('id="skill-paste-btn"')]
        self.assertNotIn("maxlength", links_input)
        self.assertIn("链接太长", paste)

    def test_render_status_updates_are_lane_scoped(self) -> None:
        """A render that finishes after a lane switch must not talk in another lane."""
        html = INDEX_HTML
        render_fn = html[html.index("function renderSkillImages()") : html.index("function exportSkillImages()")]
        self.assertIn("laneStatus", render_fn)
        self.assertIn('state.lane === "skills"', render_fn)
        self.assertIn("skill_package_changed", render_fn)
        self.assertIn("重新点「生成图片」", render_fn)

    def test_paste_reports_links_without_a_readable_skill_file(self) -> None:
        """A pasted link whose SKILL.md cannot be read still enters, but is flagged."""
        status, payload = self._request(
            "POST", "/api/skills/paste", {"links": "https://github.com/acme/hidden"}
        )
        self.assertEqual(200, status)
        self.assertEqual(1, payload["added"], msg="用户明确粘贴的链接不能静默丢弃")
        self.assertEqual(["hidden"], payload["unverified"])
        skill = (payload.get("skills") or [])[0]
        self.assertEqual("", skill["skill_excerpt"])
        self.assertTrue(skill["manual"])

    def test_paste_endpoint_caps_one_paste_at_the_package_skill_cap(self) -> None:
        links = "\n".join(f"https://github.com/acme/skill-{index}" for index in range(20))
        status, payload = self._request("POST", "/api/skills/paste", {"links": links})
        self.assertEqual(200, status)
        self.assertEqual(16, len(payload.get("manual_skills") or []))
        overflow = [row for row in payload.get("rejected") or [] if row["reason"] == "too_many"]
        self.assertEqual(4, len(overflow))

    def test_paste_is_refused_only_by_a_live_render(self) -> None:
        """A stale `rendering` phase (crash, restart) must not park the paste box."""
        self.app.database.save_skill_finder(
            {"query": "x", "phase": "rendering", "skills": [], "stages": [], "images": []}
        )
        status, payload = self._request(
            "POST",
            "/api/skills/paste",
            {"links": "https://github.com/acme/toolkit/tree/main/video-edit"},
        )
        self.assertEqual(200, status)
        self.assertEqual(1, payload["added"])
        self.app._skill_render_active = True
        try:
            status, payload = self._request(
                "POST", "/api/skills/paste", {"links": "https://github.com/acme/hidden"}
            )
            self.assertEqual(400, status)
            self.assertEqual("skill_render_running", payload["error"])
        finally:
            self.app._skill_render_active = False
        self.assertIn("skill_render_running", INDEX_HTML)

    def test_failed_render_resets_the_phase_for_the_next_paste(self) -> None:
        """A render that blows up must not leave the package stuck in `rendering`."""
        package = self.root / "skills" / "pkg"
        (package / "images").mkdir(parents=True)
        self.app.database.save_skill_finder(
            {
                "query": "从零做播客",
                "title": "技能包",
                "stages": [{"id": "topic", "name": "选题"}],
                "skills": [{"name": "s", "source_id": "acme/s", "stage_id": "topic"}],
                "article": {"title": "t", "body": "b\nAIGC"},
                "images": [],
                "package_path": str(package),
                "phase": "skills_ready",
            }
        )

        def exploding_renderer(repos, jobs, out_dir, theme="dark", palette=None):
            raise RuntimeError("boom")

        self.app.visual_renderer = exploding_renderer
        with self.assertRaises(RuntimeError):
            self.app.skills_render({})
        saved = self.app.database.get_skill_finder() or {}
        self.assertEqual("skills_ready", saved.get("phase"))
        self.assertIn("boom", str(saved.get("render_error") or ""))
        status, payload = self._request(
            "POST", "/api/skills/paste", {"links": "https://github.com/acme/hidden"}
        )
        self.assertEqual(200, status, msg="失败的出图不能把粘贴入口锁死")
        self.assertEqual(2, payload["count"])

    def test_render_refuses_to_overwrite_a_package_that_moved(self) -> None:
        """A paste during a render must win; the stale render must not delete it."""
        self.app.database.save_skill_finder(
            {"query": "q", "phase": "skills_ready", "skills": [], "stages": ["x"], "images": [], "revision": 3}
        )
        stale_revision = self.app._skill_revision()
        status, payload = self._request(
            "POST",
            "/api/skills/paste",
            {"links": "https://github.com/acme/toolkit/tree/main/video-edit"},
        )
        self.assertEqual(200, status)
        self.assertEqual(4, payload["revision"], msg="粘贴必须推进 revision")
        with self.assertRaises(ValueError):
            self.app._save_skill_render_fields(
                stale_revision, {"images": [{"id": "cover"}]}, expected_phase="done"
            )
        saved = self.app.database.get_skill_finder() or {}
        self.assertEqual(["video-edit"], [row["name"] for row in saved.get("skills") or []])
        self.assertEqual("skills_ready", saved.get("phase"))

    def test_github_token_endpoint_stores_never_echoes_and_clears(self) -> None:
        status, payload = self._request(
            "POST", "/api/skills/github-token", {"token": "ghp_secret_value"}
        )
        self.assertEqual(200, status)
        self.assertTrue(payload["configured"])
        self.assertNotIn("ghp_secret_value", json.dumps(payload))
        self.assertEqual(
            "ghp_secret_value", self.credentials.values.get("github:token")
        )
        from autoposting.github_weekly import github_token

        self.assertEqual("ghp_secret_value", github_token())
        snapshot = self.app.skills_snapshot()
        self.assertTrue(snapshot["github_token"])
        self.assertNotIn("ghp_secret_value", json.dumps(snapshot))

        status, payload = self._request("POST", "/api/skills/github-token", {"token": ""})
        self.assertEqual(200, status)
        self.assertFalse(payload["configured"])
        self.assertNotIn("github:token", self.credentials.values)
        self.assertEqual("", github_token())
        self.assertFalse(self.app.skills_snapshot()["github_token"])
        self.assertEqual(
            400, self._request("POST", "/api/skills/github-token", {"token": 5})[0]
        )

    def test_search_returns_502_when_llm_missing(self) -> None:
        status, payload = self._request("POST", "/api/skills/search", {"query": "从零做播客"})
        self.assertEqual(502, status)
        self.assertEqual("skill_search_failed", payload["error"])
        self.assertTrue(payload.get("error_code"))

    def test_skills_lane_shows_studio_gallery_without_autorender(self) -> None:
        """B3/D4: 查找 and 出图 are two separately controlled stages."""
        html = INDEX_HTML
        self.assertIn('id="skills-studio"', html)
        self.assertIn('id="skills-gallery"', html)
        self.assertIn("body.lane-skills #skills-studio", html)
        self.assertIn("body.lane-skills #skills-gallery", html)
        self.assertIn("skills_ready", html)
        self.assertIn("function renderSkillImages()", html)
        search_fn = html[html.index("function searchSkills()") : html.index("function renderSkillImages()")]
        # A finished search lays out placeholder tiles and stops there.
        self.assertNotIn("renderSkillImages()", search_fn)
        self.assertIn("queueSkillImagesForRender()", search_fn)
        self.assertIn('phase === "skills_ready"', html)
        # The only trigger for real rendering is the explicit button.
        self.assertIn('$("skills-render-btn").addEventListener("click", renderSkillImages);', html)
        # No per-tile re-render endpoint exists (D4: stage-level split only).
        self.assertNotIn("/api/skills/image", html)
        gallery_fn = html[html.index("function renderSkillsGallery()") : html.index("function toggleSkillImage(")]
        self.assertTrue(
            "会自动出图" in gallery_fn or "排队中" in gallery_fn or "queued" in gallery_fn,
            msg="gallery empty state must be visible",
        )

    def test_skills_snapshot_restores_article_from_package(self) -> None:
        package = self.root / "skills" / "pkg"
        package.mkdir(parents=True)
        (package / "article.md").write_text("# 从零做播客技能包\n\n完整介绍文\nAIGC\n", encoding="utf-8")
        self.app.database.save_skill_finder(
            {
                "query": "从零做播客",
                "title": "从零做播客技能包",
                "article": {"title": "", "body": ""},
                "package_path": str(package),
                "skills": [],
                "stages": [],
                "images": [],
                "phase": "done",
            }
        )
        payload = self.app.skills_snapshot()
        self.assertIn("完整介绍文", str((payload.get("article") or {}).get("body") or ""))
        saved = self.app.database.get_skill_finder() or {}
        self.assertIn("完整介绍文", str((saved.get("article") or {}).get("body") or ""))

    def test_skills_lane_puts_gallery_above_article(self) -> None:
        """B2/D3 (reversed decision): image area on top, article below.

        The original contract kept the article above the gallery; 1.3.0 reverses
        that so the skill lane matches the GitHub weekly lane (toolbar → gallery →
        text). The article stays fully readable because it is now a bounded
        internal scroll box, not because it sits first in the document.
        """
        html = INDEX_HTML
        self.assertIn('id="skills-article"', html)
        self.assertIn('id="skills-body"', html)
        self.assertLess(
            html.index('id="skills-gallery"'),
            html.index('id="skills-article"'),
            msg="D3: 图片区必须在介绍文上方",
        )
        gallery = html.index('id="skills-gallery"')
        toolbar = html.index('id="skills-render-btn"')
        self.assertLess(toolbar, gallery, msg="工具栏必须紧贴画廊上方")
        self.assertNotIn('id="skills-article"', html[toolbar:gallery])
        article_css = html.split("#skills-article{")[1].split("}")[0]
        self.assertIn("max-height", article_css)
        self.assertIn("overflow-y:auto", article_css)
        self.assertIn("查找完成后会生成介绍文", html)
        poll_fn = html[html.index("function skillArticleReady(") : html.index("function searchSkills()")]
        compact = poll_fn.replace(" ", "").replace("\n", "")
        self.assertIn("article.body", compact)
        self.assertIn("skillArticleReady", poll_fn)
        self.assertNotIn(
            'if (phase === "skills_ready" || phase === "rendering" || phase === "done") { return data; }',
            " ".join(poll_fn.split()),
        )

    def test_skills_render_keeps_article_written_during_render(self) -> None:
        package = self.root / "skills" / "pkg"
        (package / "images").mkdir(parents=True)
        self.app.database.save_skill_finder(
            {
                "query": "从零做播客",
                "title": "从零做播客技能包",
                "theme": "播客从选题到上线",
                "stages": [{"id": "topic", "name": "选题", "queries": ["播客选题"], "required": True}],
                "skills": [
                    {
                        "name": "podcast-topic",
                        "source_id": "acme/podcast-topic",
                        "stage_id": "topic",
                        "stage_name": "选题",
                        "stars": 12,
                        "url": "https://github.com/acme/podcast-topic",
                        "skill_path": "SKILL.md",
                        "description": "选题",
                    }
                ],
                "article": {"title": "", "body": ""},
                "images": [],
                "package_path": str(package),
                "phase": "skills_ready",
            }
        )
        article = {"title": "从零做播客技能包", "body": "地图：选题到发布。\nacme/podcast-topic\nAIGC"}

        def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
            current = dict(self.app.database.get_skill_finder() or {})
            current["article"] = article
            self.app.database.save_skill_finder(current)
            png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
            return png_path

        def fake_render(repos, jobs, out_dir, theme="dark", palette=None):
            out_dir.mkdir(parents=True, exist_ok=True)
            rendered = []
            for job in jobs:
                filename = f"{job['id']}.png"
                (out_dir / filename).write_bytes(b"png")
                row = dict(job)
                row["file"] = filename
                rendered.append(row)
            return rendered

        self.app.skill_screenshot = fake_shot
        self.app.visual_renderer = fake_render
        payload = self.app.skills_render({})
        saved = self.app.database.get_skill_finder() or {}
        self.assertEqual(article["body"], (payload.get("article") or {}).get("body"))
        self.assertEqual(article["body"], (saved.get("article") or {}).get("body"))
        self.assertEqual("done", payload.get("phase"))

    def test_skill_search_btn_css_keeps_lookup_on_one_line(self) -> None:
        html = INDEX_HTML
        self.assertIn('id="skill-search-btn"', html)
        self.assertIn(">查找</button>", html)
        css = html[html.index("body.lane-skills #skill-search-row") : html.index("body.lane-skills #skill-stage-chips")]
        self.assertIn("#skill-search-btn", css)
        self.assertIn("white-space:nowrap", css)
        self.assertIn("min-width", css)
        self.assertIn("height:40px", css)
        self.assertIn("width:auto", css)
        self.assertIn("min-width:0", css)
        self.assertIn("flex:1", css)
        self.assertIn("display:inline-flex", css)
        self.assertIn("align-items:center", css)
        self.assertIn("justify-content:center", css)

    def test_paint_wait_drops_sliding_meter_keeps_abort(self) -> None:
        html = INDEX_HTML
        paint = html[html.index("function paintWait()") : html.index("function formatTime(")]
        self.assertNotIn("wait-meter", paint)
        self.assertNotIn("wait-bar", paint)
        self.assertNotIn("waitSlide", html)
        self.assertIn("wait-stop", paint)
        self.assertIn("waitStop(", paint)
        self.assertIn("停止", paint)
        self.assertIn("wait-spinner", paint)
        wait_stop = html[html.index("function waitStop(") : html.index("function scheduleWaitHide(")]
        self.assertIn(".abort.abort()", wait_stop)
        self.assertIn('waitFail("已停止"', wait_stop)
        search = html[html.index("function searchSkills()") : html.index("function renderSkillImages()")]
        self.assertIn("abortSkillSearch", search)
        poll = html[html.index("function pollSkillSnapshot()") : html.index("function searchSkills()")]
        self.assertIn("abortSkillSearch", poll)
        banner_css = html[html.index("#wait-banner{") : html.index("#wait-jobs{") + 160]
        self.assertIn("pointer-events:none", banner_css)
        stop_css = html[html.index(".wait-stop{") : html.index(".wait-stop:hover")]
        self.assertIn("pointer-events:auto", stop_css)
        wait_css = html[html.index("#wait-banner{") : html.index("main{")]
        self.assertNotIn(".wait-meter", wait_css)
        self.assertNotIn(".wait-bar", wait_css)

    def test_poll_skill_snapshot_continues_seven_search_phases(self) -> None:
        html = INDEX_HTML
        poll = html[html.index("function pollSkillSnapshot()") : html.index("function searchSkills()")]
        for phase in ('"understanding"', '"chain"', '"decompose"', '"keywords"', '"search"', '"group"', '"compose"'):
            self.assertIn(phase, poll)
        self.assertIn("skillArticleReady", poll)
        # B3: polling a finished search must not kick off image generation.
        self.assertNotIn("renderSkillImages()", poll)
        self.assertIn('phase === "skills_ready"', poll)
        self.assertIn('phase === "error"', poll)
        self.assertIn("pollSkillSnapshot()", poll)
        self.assertIn("setTimeout", poll)

    def test_skill_search_wait_detail_uses_progress_step_index(self) -> None:
        html = INDEX_HTML
        paint = html[html.index("function paintWait()") : html.index("function formatTime(")]
        self.assertIn("skill_search", paint)
        self.assertIn("skillsPackage.progress", paint)
        self.assertIn("step_index", paint)
        self.assertIn("step_total", paint)
        self.assertIn(".label", paint)
        self.assertIn("第 ", paint)
        self.assertIn(" 步 · ", paint)
        self.assertIn("查找中", paint)


if __name__ == "__main__":
    unittest.main()
