{style}

Cover still-life: a tall cream ranking card standing on charcoal linen, brass pin, faint grid. Hand-lettered title 'GitHub' and subtitle '本周爆火ai工具'. Ten small tactile tokens arranged top to bottom representing: {ranking}. Camera slightly above, 50mm, shallow depth, 3:4 crop.
