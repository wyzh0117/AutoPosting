"""Fixed 9:16 Xiaohongshu note cards. Layout is template-owned."""

from __future__ import annotations

import re

XHS_CARD_WIDTH = 1080
XHS_CARD_HEIGHT = 1920
XHS_MAX_CARDS = 18
XHS_PAGE_CHARS = 380
XHS_PLACEHOLDER_ID = "@小红书号"
_BLANK_RE = re.compile(r"\n\s*\n")


def first_paragraph(text: str) -> str:
    cleaned = (text or "").strip()
    if not cleaned:
        return ""
    return _BLANK_RE.split(cleaned, maxsplit=1)[0].strip().split("\n", 1)[0].strip()


def paginate_text(text: str, limit: int = XHS_PAGE_CHARS) -> list[str]:
    cleaned = (text or "").strip()
    if not cleaned:
        return []
    if limit < 1:
        return [cleaned]
    paragraphs = [part.strip() for part in _BLANK_RE.split(cleaned) if part.strip()]
    pages: list[str] = []
    current = ""
    for paragraph in paragraphs:
        for chunk in _chunks(paragraph, limit):
            candidate = chunk if not current else f"{current}\n\n{chunk}"
            if len(candidate) <= limit:
                current = candidate
                continue
            if current:
                pages.append(current)
            current = chunk
    if current:
        pages.append(current)
    return pages


def build_xhs_cards(
    title: str,
    manuscript: str,
    *,
    cover_url: str = "",
    handle: str = "",
) -> dict[str, object]:
    label = handle.strip() or XHS_PLACEHOLDER_ID
    remainder = (manuscript or "").strip()
    cover: dict[str, object] = {
        "kind": "cover",
        "title": title,
        "handle": label,
        "avatar": "",
        "width": XHS_CARD_WIDTH,
        "height": XHS_CARD_HEIGHT,
        "image_url": "",
        "lede": "",
    }
    if cover_url.strip():
        cover["image_url"] = cover_url.strip()
    else:
        lede, remainder = _split_lede(remainder)
        cover["lede"] = lede
    pages = paginate_text(remainder)[: XHS_MAX_CARDS - 1]
    cards = [cover]
    for page in pages:
        cards.append(
            {
                "kind": "page",
                "text": page,
                "handle": label,
                "avatar": "",
                "width": XHS_CARD_WIDTH,
                "height": XHS_CARD_HEIGHT,
            }
        )
    return {
        "width": XHS_CARD_WIDTH,
        "height": XHS_CARD_HEIGHT,
        "handle": label,
        "cards": cards,
    }


def _split_lede(text: str) -> tuple[str, str]:
    lede = first_paragraph(text)
    if not lede:
        return "", text
    rest = text.strip()
    if rest.startswith(lede):
        rest = rest[len(lede) :].lstrip()
    return lede, rest


def _chunks(text: str, limit: int) -> list[str]:
    if len(text) <= limit:
        return [text]
    return [text[index : index + limit] for index in range(0, len(text), limit)]
