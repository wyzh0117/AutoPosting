from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Callable

from autoposting.github_weekly import week_window_start

from .adapter import project_from_repo, ranking_from_repos
from .marks import is_author_avatar, resolve_mark
from .media import fetch_bytes, fetch_data_uri
from .pipeline import render_page
from .story import find_readme_logo, load_readme
from .tokens import resolve_tokens

GenerateImage = Callable[[str], bytes]


def render_weekly_visual(
    repos: list[dict[str, Any]],
    jobs: list[dict[str, Any]],
    out_dir: Path,
    theme: str = "dark",
    palette: dict[str, str] | None = None,
    screenshot: bool = True,
    generate_image: GenerateImage | None = None,
) -> list[dict[str, Any]]:
    tokens = resolve_tokens(theme, palette)
    target = Path(out_dir)
    target.mkdir(parents=True, exist_ok=True)
    catalog_dir = target.parent / "visual-marks"
    date_range = week_window_start()
    total = max(len(repos), 1)
    rendered: list[dict[str, Any]] = []
    for job in jobs:
        kind = str(job.get("kind") or "")
        stem = str(job.get("id") or kind or "page")
        if kind == "cover":
            payload = ranking_from_repos(repos, issue="本周", date_range=date_range)
            for item in payload.get("items") or []:
                if isinstance(item, dict):
                    _apply_mark(item, catalog_dir)
        else:
            repo = _match_repo(repos, job)
            if repo is None:
                rendered.append(dict(job))
                continue
            rank = int(repo.get("rank") or job.get("rank") or 1)
            payload = project_from_repo(
                repo,
                issue="本周",
                page_number=f"{rank + 1:02d} / {total + 1:02d}",
            )
            _apply_project_mark(payload, repo, catalog_dir)
        result = render_page(
            payload,
            out_dir=target,
            screenshot=screenshot,
            tokens=tokens,
            file_stem=stem,
        )
        row = dict(job)
        if result.get("png") or result.get("html"):
            filename = f"{stem}.png"
            if result.get("png"):
                row["file"] = filename
            row["url"] = f"/api/generated/github-weekly/{filename}?v={time.time_ns()}"
        row["selected"] = True
        rendered.append(row)
    return rendered


def _apply_mark(item: dict[str, Any], catalog_dir: Path) -> None:
    logo = str(item.get("logo") or "")
    if logo and not is_author_avatar(logo):
        embedded = fetch_data_uri(logo)
        item["logo"] = embedded or ""
        item["markSvg"] = ""
        if item["logo"]:
            return
    item["logo"] = ""
    mark = resolve_mark(
        name=str(item.get("name") or ""),
        kind=str(item.get("category") or ""),
        description=str(item.get("description") or ""),
        catalog_dir=catalog_dir,
    )
    item["markSvg"] = str(mark.get("svg") or "")


def _apply_project_mark(payload: dict[str, Any], repo: dict[str, Any], catalog_dir: Path) -> None:
    owner = str(repo.get("owner") or "")
    name = str(repo.get("name") or "")
    readme = load_readme(owner, name, fetch_bytes) if owner and name else ""
    found = find_readme_logo(readme, owner=owner, repo=name) if readme else ""
    if found:
        embedded = fetch_data_uri(found)
        if embedded:
            payload["logo"] = embedded
            payload["markSvg"] = ""
            return
    logo = str(payload.get("logo") or "")
    if logo and not is_author_avatar(logo):
        embedded = fetch_data_uri(logo)
        if embedded:
            payload["logo"] = embedded
            payload["markSvg"] = ""
            return
    payload["logo"] = ""
    mark = resolve_mark(
        name=name,
        kind=str(repo.get("kind") or payload.get("category") or ""),
        topics=list(repo.get("topics") or []),
        description=str(repo.get("description") or repo.get("summary") or ""),
        catalog_dir=catalog_dir,
    )
    payload["markSvg"] = str(mark.get("svg") or "")


def _match_repo(repos: list[dict[str, Any]], job: dict[str, Any]) -> dict[str, Any] | None:
    rank = int(job.get("rank") or 0)
    title = str(job.get("title") or "")
    for repo in repos:
        if rank and int(repo.get("rank") or 0) == rank:
            return repo
    for repo in repos:
        if title and str(repo.get("name") or "") == title:
            return repo
    return None
