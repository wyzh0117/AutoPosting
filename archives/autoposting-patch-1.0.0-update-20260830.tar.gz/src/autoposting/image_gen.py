"""Frozen prompts + local files for GitHub weekly model images."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

IMAGE_STYLE_BIBLE = (
    "Editorial 3:4 portrait poster, 768x1024. Young, premium, quiet luxury. "
    "Palette: warm cream paper #f4efe6, charcoal #1a1714, muted brass #c4a46a. "
    "Soft fiber paper grain, gentle inner shadow, matte lighting, no neon, "
    "no lens flare, no holograms, no cyberpunk glow, no watermarks, no UI chrome, "
    "no screenshots of GitHub, no real celebrity faces. Studio still-life, "
    "tactile objects on a dark walnut desk. Consistent weekly series look."
)
IMAGE_SIZE = "768*1024"
GenerateFn = Callable[[str], bytes]


def build_weekly_image_jobs(repos: list[dict[str, object]]) -> list[dict[str, object]]:
    names = [str(repo.get("name") or repo.get("full_name") or "") for repo in repos[:10]]
    ranking = "、".join(f"{index + 1}.{name}" for index, name in enumerate(names) if name)
    cover_prompt = (
        f"{IMAGE_STYLE_BIBLE} Cover still-life: a tall cream ranking card standing "
        f"on charcoal linen, brass pin, faint grid. Hand-lettered title 'GitHub' "
        f"and subtitle '本周爆火ai工具'. Ten small tactile tokens arranged top to "
        f"bottom representing: {ranking or 'ten unnamed AI tools'}. Camera slightly "
        f"above, 50mm, shallow depth, 3:4 crop."
    )
    jobs: list[dict[str, object]] = [
        {
            "id": "cover",
            "kind": "cover",
            "rank": 0,
            "title": "本周爆火ai工具",
            "prompt": cover_prompt,
            "url": "",
            "file": "",
            "selected": True,
        }
    ]
    for repo in repos[:10]:
        rank = int(repo.get("rank") or len(jobs))
        name = str(repo.get("name") or f"repo-{rank}")
        summary = str(repo.get("summary") or repo.get("description") or "")
        does = str(repo.get("does") or "")
        scene = str(repo.get("scene") or "")
        kind = str(repo.get("kind") or "")
        prompt = (
            f"{IMAGE_STYLE_BIBLE} Poster still-life for the AI tool '{name}' "
            f"({kind}). Hero object that visually reads as {summary}. "
            f"It does: {does}. Typical scene: {scene}. Include a small brass "
            f"numeral NO.{rank:02d} and the name '{name}' letterpressed on cream "
            f"stock. Same desk, same lighting, 3:4 crop."
        )
        jobs.append(
            {
                "id": f"{rank:02d}-{_safe_name(name)}",
                "kind": "poster",
                "rank": rank,
                "title": name,
                "prompt": prompt,
                "url": "",
                "file": "",
                "selected": True,
            }
        )
    return jobs


def render_weekly_images(
    jobs: list[dict[str, object]],
    generate: GenerateFn,
    out_dir: Path,
) -> list[dict[str, object]]:
    out_dir.mkdir(parents=True, exist_ok=True)
    rendered: list[dict[str, object]] = []
    for job in jobs:
        prompt = str(job.get("prompt") or "")
        payload = generate(prompt)
        if not payload:
            rendered.append(dict(job))
            continue
        filename = f"{job['id']}.png"
        (out_dir / filename).write_bytes(payload)
        row = dict(job)
        row["file"] = filename
        row["url"] = f"/api/generated/github-weekly/{filename}"
        row["selected"] = True
        rendered.append(row)
    return rendered


def _safe_name(name: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in "-._" else "-" for char in name)
    return cleaned.strip("-._")[:40] or "repo"
