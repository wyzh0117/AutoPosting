from __future__ import annotations

import base64
import urllib.error
import urllib.request


def fetch_data_uri(url: str, timeout: float = 6) -> str:
    raw = (url or "").strip()
    if not raw or raw.startswith("data:"):
        return raw
    if not raw.startswith(("http://", "https://")):
        return ""
    request = urllib.request.Request(
        raw,
        headers={"User-Agent": "AutoPosting-visual/1.0.6"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read(220_000)
            content_type = response.headers.get_content_type() or "image/png"
    except (OSError, urllib.error.URLError, TimeoutError, ValueError):
        return ""
    if not payload:
        return ""
    encoded = base64.b64encode(payload).decode("ascii")
    return f"data:{content_type};base64,{encoded}"
