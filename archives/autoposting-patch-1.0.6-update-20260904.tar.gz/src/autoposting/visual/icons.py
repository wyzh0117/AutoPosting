from __future__ import annotations

from html import escape
import re


def svg_id(prefix: str, seed: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", seed).strip("-")[:24] or "x"
    return f"{prefix}-{cleaned}"


def rounded_mark(name: str, kind: str = "", seed: str = "") -> str:
    uid = svg_id("mark", seed or name or kind)
    letter = escape((name or kind or "?").strip()[:1].upper() or "?")
    return f"""<svg class="c-logo-3d-svg" viewBox="0 0 128 128" aria-hidden="true">
  <defs>
    <linearGradient id="{uid}-face" x1="18%" y1="8%" x2="88%" y2="96%">
      <stop offset="0%" stop-color="currentColor" stop-opacity="0.95"/>
      <stop offset="55%" stop-color="currentColor" stop-opacity="0.72"/>
      <stop offset="100%" stop-color="currentColor" stop-opacity="0.42"/>
    </linearGradient>
    <linearGradient id="{uid}-shine" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fff" stop-opacity="0.38"/>
      <stop offset="48%" stop-color="#fff" stop-opacity="0"/>
    </linearGradient>
  </defs>
  <rect x="10" y="16" width="100" height="100" rx="28" fill="currentColor" opacity="0.18"/>
  <rect x="14" y="10" width="100" height="100" rx="28" fill="url(#{uid}-face)"/>
  <rect x="14" y="10" width="100" height="100" rx="28" fill="url(#{uid}-shine)"/>
  <text x="64" y="78" text-anchor="middle" font-size="46" font-weight="700"
    font-family="ui-sans-serif, system-ui, sans-serif" fill="#F3F0E8">{letter}</text>
</svg>"""


def feature_icon(label: str, seed: str = "") -> str:
    uid = svg_id("feat", seed or label)
    key = (label or "").lower()
    path = _feature_path(key)
    return f"""<svg class="c-feature-icon" viewBox="0 0 32 32" aria-hidden="true">
  <defs>
    <linearGradient id="{uid}" x1="20%" y1="0%" x2="80%" y2="100%">
      <stop offset="0%" stop-color="currentColor" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="currentColor" stop-opacity="0.55"/>
    </linearGradient>
  </defs>
  <rect x="1.5" y="1.5" width="29" height="29" rx="9" fill="url(#{uid})" opacity="0.16"/>
  <rect x="1.5" y="1.5" width="29" height="29" rx="9" fill="none" stroke="currentColor" stroke-width="1.4" opacity="0.55"/>
  {path}
</svg>"""


def function_schematic(steps: list[str], seed: str = "flow") -> str:
    nodes = [item.strip() for item in steps if str(item).strip()][:5]
    if not nodes:
        nodes = ["输入", "处理", "输出"]
    uid = svg_id("flow", seed)
    count = len(nodes)
    width = 1000
    height = 520
    gap = 28
    node_w = min(168, (width - 80 - gap * (count - 1)) / count)
    node_h = 72
    start_x = (width - (node_w * count + gap * (count - 1))) / 2
    y = 220
    parts = [
        f'<svg class="c-function-diagram" viewBox="0 0 {width} {height}" role="img">',
        f'<defs><linearGradient id="{uid}-panel" x1="0" y1="0" x2="1" y2="1">',
        '<stop offset="0%" stop-color="currentColor" stop-opacity="0.14"/>',
        '<stop offset="100%" stop-color="currentColor" stop-opacity="0.04"/>',
        "</linearGradient></defs>",
        f'<rect x="36" y="36" width="{width - 72}" height="{height - 72}" rx="32" fill="url(#{uid}-panel)"/>',
        f'<text x="64" y="88" fill="currentColor" font-size="22" font-weight="600" opacity="0.7">功能示意</text>',
    ]
    for index, label in enumerate(nodes):
        x = start_x + index * (node_w + gap)
        text = escape(label[:8])
        parts.append(
            f'<rect x="{x}" y="{y}" width="{node_w}" height="{node_h}" rx="18" '
            f'fill="currentColor" opacity="0.16"/>'
        )
        parts.append(
            f'<rect x="{x}" y="{y}" width="{node_w}" height="{node_h}" rx="18" '
            f'fill="none" stroke="currentColor" stroke-width="2" opacity="0.55"/>'
        )
        parts.append(
            f'<text x="{x + node_w / 2}" y="{y + 44}" text-anchor="middle" fill="currentColor" '
            f'font-size="20" font-weight="600">{text}</text>'
        )
        if index < count - 1:
            ax = x + node_w + 4
            parts.append(
                f'<path d="M{ax} {y + node_h / 2} H{ax + gap - 8} L{ax + gap - 16} {y + node_h / 2 - 7} '
                f'M{ax + gap - 8} {y + node_h / 2} L{ax + gap - 16} {y + node_h / 2 + 7}" '
                f'fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>'
            )
    parts.append("</svg>")
    return "".join(parts)


def _feature_path(key: str) -> str:
    if any(token in key for token in ("agent", "角色", "岗位")):
        return (
            '<circle cx="11" cy="12" r="3.2" fill="currentColor"/>'
            '<circle cx="21" cy="12" r="3.2" fill="currentColor"/>'
            '<path d="M6 23c.6-4 3.2-6 6.2-6s5.5 2 6.1 6M14 23c.6-4 3.2-6 6.2-6s5.5 2 6.1 6" '
            'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'
        )
    if any(token in key for token in ("分工", "split", "任务")):
        return (
            '<path d="M8 8h6v6H8zM18 8h6v6h-6zM13 18h6v6h-6z" fill="none" stroke="currentColor" '
            'stroke-width="1.8" rx="2"/>'
        )
    if any(token in key for token in ("协作", "工作流", "flow", "workflow")):
        return (
            '<path d="M7 16h18M16 7v18M10 11l6-4 6 4M10 21l6 4 6-4" fill="none" '
            'stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'
        )
    if any(token in key for token in ("反馈", "自动")):
        return (
            '<path d="M9 11a7 7 0 1 1 2 5.2L8 18" fill="none" stroke="currentColor" '
            'stroke-width="1.8" stroke-linecap="round"/>'
        )
    if any(token in key for token in ("rag", "检索", "知识")):
        return (
            '<circle cx="14" cy="14" r="6" fill="none" stroke="currentColor" stroke-width="1.8"/>'
            '<path d="M19 19l5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'
        )
    return (
        '<rect x="9" y="9" width="14" height="14" rx="4" fill="none" stroke="currentColor" stroke-width="1.8"/>'
        '<circle cx="16" cy="16" r="2.2" fill="currentColor"/>'
    )
