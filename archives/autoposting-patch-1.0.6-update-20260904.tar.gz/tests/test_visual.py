import json
import tempfile
import unittest
from pathlib import Path

from autoposting.visual.pipeline import (
    PNG_HEIGHT,
    PNG_WIDTH,
    render_examples,
    render_page,
)
from autoposting.visual.rules import apply_project_rules, apply_ranking_rules, format_compact_number
from autoposting.visual.schema import ContentValidationError, load_example, validate_content
from autoposting.visual.tokens import load_tokens, resolve_tokens, token


class DesignTokenTests(unittest.TestCase):
    def test_canvas_is_fixed_9_by_16(self) -> None:
        tokens = load_tokens()
        self.assertEqual(1080, tokens["canvas"]["width"])
        self.assertEqual(1920, tokens["canvas"]["height"])
        self.assertEqual("9:16", tokens["canvas"]["aspect"])
        self.assertEqual("#0B0D12", token("color.background"))
        self.assertEqual(16, token("radius.card"))

    def test_light_theme_switches_surface_group(self) -> None:
        dark = resolve_tokens("dark")
        light = resolve_tokens("light")
        self.assertEqual("#0B0D12", dark["color"]["background"])
        self.assertNotEqual(dark["color"]["background"], light["color"]["background"])
        self.assertNotEqual(dark["color"]["text"]["primary"], light["color"]["text"]["primary"])
        html = render_page(load_example("ranking"), screenshot=False, tokens=light)["html_text"]
        self.assertIn(light["color"]["background"], html)

    def test_palette_overrides_main_secondary_accent(self) -> None:
        tokens = resolve_tokens(
            "dark",
            {"main": "#112233", "secondary": "#334455", "accent": "#FF6600"},
        )
        self.assertEqual("#112233", tokens["color"]["background"])
        self.assertEqual("#334455", tokens["color"]["surface"])
        self.assertEqual("#FF6600", tokens["color"]["primary"])
        self.assertEqual("#FF6600", tokens["color"]["progressFill"])
        html = render_page(load_example("ranking"), screenshot=False, tokens=tokens)["html_text"]
        self.assertIn("#112233", html)
        self.assertIn("#FF6600", html)


class ContentSchemaTests(unittest.TestCase):
    def test_example_ranking_validates(self) -> None:
        payload = load_example("ranking")
        validate_content("ranking", payload)
        self.assertEqual("ranking-overview", payload["page"])
        self.assertGreaterEqual(len(payload["items"]), 3)
        self.assertNotIn("agency-agents", json.dumps(load_tokens()))

    def test_example_project_validates(self) -> None:
        payload = load_example("project")
        validate_content("project", payload)
        self.assertEqual("agency-agents", payload["name"])
        self.assertIsInstance(payload["features"], list)

    def test_missing_title_is_rejected(self) -> None:
        payload = dict(load_example("ranking"))
        payload.pop("title")
        with self.assertRaises(ContentValidationError):
            validate_content("ranking", payload)


class RenderingRuleTests(unittest.TestCase):
    def test_compact_number_and_progress(self) -> None:
        self.assertEqual("11k", format_compact_number(11000))
        payload = apply_ranking_rules(
            {
                "page": "ranking-overview",
                "brand": "AutoPosting",
                "series": "GitHub 本周爆火 AI 项目榜",
                "issue": "第1期",
                "dateRange": "2026-09-01 — 2026-09-07",
                "title": "GitHub",
                "subtitle": "本周爆火 AI 项目榜",
                "items": [
                    {
                        "rank": 1,
                        "name": "alpha",
                        "description": "d",
                        "metric": {"label": "Stars", "value": 20000},
                    },
                    {
                        "rank": 2,
                        "name": "beta",
                        "description": "d",
                        "metric": {"label": "Stars", "value": 10000},
                    },
                ],
                "tags": [],
            }
        )
        self.assertEqual("20k", payload["items"][0]["metric"]["display"])
        self.assertAlmostEqual(1.0, payload["items"][0]["progress"])
        self.assertAlmostEqual(0.5, payload["items"][1]["progress"])

    def test_drops_items_beyond_ten_and_clips_long_copy(self) -> None:
        items = [
            {
                "rank": index + 1,
                "name": "n",
                "description": "这是一句会被裁切的非常长的项目介绍" * 6,
                "metric": {"label": "Stars", "value": 100 - index},
            }
            for index in range(12)
        ]
        payload = apply_ranking_rules(
            {
                "page": "ranking-overview",
                "brand": "B",
                "series": "S",
                "issue": "1",
                "dateRange": "d",
                "title": "T",
                "subtitle": "U",
                "items": items,
                "tags": [],
            }
        )
        self.assertEqual(10, len(payload["items"]))
        self.assertLessEqual(len(payload["items"][0]["description"]), 42)

    def test_project_rules_format_url_and_features(self) -> None:
        payload = apply_project_rules(
            {
                "page": "project-detail",
                "brand": "AutoPosting",
                "series": "S",
                "issue": "1",
                "pageNumber": "02 / 11",
                "rank": 1,
                "category": "AI Agent / 多智能体",
                "name": "agency-agents",
                "tagline": "把一个 AI 团队塞进电脑里",
                "keyMessage": "将多个不同职责的 AI Agent 组织成协作团队。",
                "features": ["a", "b", "c", "d", "e", "f", "g"],
                "workflow": ["接任务", "分工", "协作", "反馈"],
                "audience": ["研究者"],
                "url": "https://github.com/example/agency-agents/tree/main/very/long/path",
                "metrics": [{"label": "Stars", "value": 11000}],
            }
        )
        self.assertEqual(5, len(payload["features"]))
        self.assertEqual("11k", payload["metrics"][0]["display"])
        self.assertTrue(payload["urlDisplay"].endswith("…") or "github.com" in payload["urlDisplay"])


class HtmlRendererTests(unittest.TestCase):
    def test_ranking_html_uses_tokens_and_components(self) -> None:
        html = render_page(load_example("ranking"), screenshot=False)["html_text"]
        self.assertIn("c-brand-header", html)
        self.assertIn("c-ranking-item", html)
        self.assertIn("c-progress-bar", html)
        self.assertIn("--color-background", html)
        self.assertIn("#0B0D12", html)
        self.assertIn("GitHub", html)
        self.assertIn("本周爆火 AI 项目榜", html)
        self.assertIn("agency-agents", html)
        self.assertIn("1080px", html)
        self.assertIn("1920px", html)

    def test_project_html_contains_required_blocks(self) -> None:
        html = render_page(load_example("project"), screenshot=False)["html_text"]
        self.assertIn("c-hero-visual", html)
        self.assertIn("c-quote-card", html)
        self.assertIn("c-feature-list", html)
        self.assertIn("c-workflow", html)
        self.assertIn("c-audience-card", html)
        self.assertIn("c-url-card", html)
        self.assertIn("agency-agents", html)
        self.assertIn("把一个 AI 团队塞进电脑里", html)
        self.assertIn("一句话看懂", html)
        self.assertIn("c-masthead", html)
        self.assertIn("c-masthead-logo", html)
        self.assertIn("c-feature-icon", html)
        self.assertIn("<svg", html)
        body = html.split("<body>", 1)[-1]
        self.assertLess(body.find("c-quote-card"), body.find("c-hero-visual"))
        self.assertIn("c-function-diagram", html)


class ExamplePngTests(unittest.TestCase):
    def test_examples_write_html_and_9_by_16_png(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        results = render_examples(Path(temp.name), screenshot=True)
        self.assertEqual(["ranking-overview", "project-detail"], [row["page"] for row in results])
        for row in results:
            html_path = Path(row["html"])
            png_path = Path(row["png"])
            self.assertTrue(html_path.is_file())
            self.assertTrue(png_path.is_file())
            self.assertGreater(png_path.stat().st_size, 20_000)
            width, height = _png_size(png_path)
            self.assertEqual((PNG_WIDTH, PNG_HEIGHT), (width, height))


class StyleBibleCompatTests(unittest.TestCase):
    def test_style_md_still_feeds_image_model_jobs(self) -> None:
        from autoposting.image_gen import build_weekly_image_jobs, load_image_prompt

        style = load_image_prompt("style")
        self.assertIn("9:16", style)
        self.assertIn("Dark Technology", style)
        jobs = build_weekly_image_jobs(
            [{"rank": 1, "name": "demo", "summary": "s", "does": "d", "scene": "sc", "kind": "CLI"}]
        )
        self.assertTrue(all(style in job["prompt"] for job in jobs))


def _png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a png: {path}")
    return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
