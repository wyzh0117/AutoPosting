from __future__ import annotations

from typing import Any

from . import components as c
from .css import stylesheet
from .rules import apply_project_rules, apply_ranking_rules
from .tokens import load_tokens


def render_html(payload: dict[str, Any], tokens: dict[str, Any] | None = None) -> str:
    resolved = tokens or load_tokens()
    page = payload.get("page")
    if page == "ranking-overview":
        body = ranking_overview(payload)
        page_class = "page page-ranking"
    elif page == "project-detail":
        body = project_detail(payload)
        page_class = "page page-project"
    else:
        raise ValueError(f"unsupported page: {page}")
    return (
        "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
        f"<meta name=\"viewport\" content=\"width={resolved['canvas']['width']}\">"
        f"<title>{_title(payload)}</title><style>{stylesheet(resolved)}</style></head>"
        f"<body><div class=\"{page_class}\">{body}</div></body></html>"
    )


def ranking_overview(payload: dict[str, Any]) -> str:
    data = apply_ranking_rules(payload)
    return "".join(
        [
            c.brand_header(str(data.get("brand") or ""), str(data.get("issue") or "")),
            c.hero_title(str(data.get("title") or ""), str(data.get("subtitle") or "")),
            c.issue_meta(
                str(data.get("issue") or ""),
                str(data.get("dateRange") or ""),
                str(data.get("kicker") or ""),
            ),
            c.ranking_list(data.get("items") or []),
            c.topic_tags(data.get("tags") or []),
            c.footer(str(data.get("footer") or data.get("source") or ""), "01 / 11"),
        ]
    )


def project_detail(payload: dict[str, Any]) -> str:
    data = apply_project_rules(payload)
    name = str(data.get("name") or "")
    return "".join(
        [
            c.brand_header(str(data.get("brand") or ""), str(data.get("issue") or "")),
            '<div class="c-project-shell">',
            '<div class="c-masthead">',
            '<div class="c-masthead-copy">',
            '<div class="c-title-row">'
            f"{c.rank_pill(int(data.get('rank') or 1))}"
            f"{c.category_tag(str(data.get('category') or ''))}"
            "</div>",
            c.hero_title(name, str(data.get("tagline") or "")),
            c.quote_card("一句话看懂", str(data.get("keyMessage") or ""), compact=True),
            "</div>",
            '<div class="c-masthead-logo">'
            f"{c.project_logo(name, str(data.get('logo') or ''), str(data.get('category') or ''), name, str(data.get('markSvg') or ''))}"
            "</div></div>",
            c.bullet_panel("做什么？", data.get("features") or [], featured=True),
            '<div class="c-project-secondary">',
            c.bullet_panel("如何实现？", data.get("how") or []),
            c.bullet_panel("适合哪些人群", data.get("audience") or []),
            c.bullet_panel("使用场景", data.get("scene") or []),
            "</div></div>",
            c.footer(
                str(data.get("footer") or data.get("source") or ""),
                str(data.get("pageNumber") or ""),
            ),
        ]
    )


def _title(payload: dict[str, Any]) -> str:
    return str(payload.get("name") or payload.get("title") or "visual")
