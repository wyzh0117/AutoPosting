# Page Schema · project-detail

回答：项目详情页由哪些组件组成、怎么排列？

## 用途

周榜中某一个仓库的详情卡片。

## 绑定内容

`ProjectContent`（`content-schemas/project.schema.json`）

## 结构

```
BrandHeader                 brand + issue
↓
RankBadge + CategoryTag     rank, category
↓
HeroTitle                   name + tagline
↓
HeroVisual                  heroVisual（可空，走占位）
↓
QuoteCard                   keyMessage
↓
FeatureList | WorkflowDiagram
↓
AudienceCard | URLCard
↓
Footer                      footer + pageNumber
```

## 布局规则

- 画布 9:16。主视觉区域 flex 伸展，避免底部空洞。
- 下半为两列 grid：能力/工作流，人群/地址。
- 不把项目文案写死在本文件。主视觉若缺，使用 Design System 的抽象光斑，不让图像模型排中文。

## 预留页面（未实现）

news-detail、tool-detail、comparison、data-insight、weekly-summary。新增时复制本文件结构，绑定新的 Content Schema，不要改 Design System。
