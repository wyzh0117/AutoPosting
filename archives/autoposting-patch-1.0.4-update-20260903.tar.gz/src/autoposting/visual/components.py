from __future__ import annotations

from html import escape
from typing import Any, Iterable


def brand_header(brand: str, trailing: str = "") -> str:
    right = f'<div class="c-issue-badge">{escape(trailing)}</div>' if trailing else ""
    return (
        f'<header class="c-brand-header">'
        f'<div class="c-brand-mark"><i></i>{escape(brand)}</div>'
        f"{right}</header>"
    )


def hero_title(title: str, subtitle: str = "") -> str:
    sub = f'<p class="c-hero-sub">{escape(subtitle)}</p>' if subtitle else ""
    return f'<h1 class="c-hero-title">{escape(title)}</h1>{sub}'


def issue_meta(issue: str, date_range: str, kicker: str = "") -> str:
    bits = [part for part in (kicker, issue, date_range) if part]
    return '<div class="c-meta-row">' + "".join(f"<span>{escape(bit)}</span>" for bit in bits) + "</div>"


def ranking_badge(rank: int) -> str:
    return f'<div class="c-ranking-badge">{int(rank):02d}</div>'


def project_logo(name: str, src: str = "") -> str:
    if src:
        return (
            f'<div class="c-project-logo"><img src="{escape(src, quote=True)}" alt=""></div>'
        )
    return f'<div class="c-project-logo">{escape(_initial(name))}</div>'


def ranking_item(item: dict[str, Any]) -> str:
    metric = item.get("metric") if isinstance(item.get("metric"), dict) else {}
    progress = float(item.get("progress") or 0)
    width = max(8, min(100, round(progress * 100)))
    return (
        f'<article class="c-ranking-item">'
        f"{ranking_badge(int(item.get('rank') or 0))}"
        f"{project_logo(str(item.get('name') or ''), str(item.get('logo') or ''))}"
        f'<div class="c-item-copy">'
        f'<div class="c-item-name">{escape(str(item.get("name") or ""))}</div>'
        f'<div class="c-item-desc">{escape(str(item.get("description") or ""))}</div>'
        f"</div>"
        f'<div class="c-metric">'
        f'<div class="c-metric-value">{escape(str(metric.get("display") or metric.get("value") or ""))}</div>'
        f'<div class="c-metric-label">{escape(str(metric.get("label") or "Stars"))}</div>'
        f'<div class="c-progress-bar"><span style="width:{width}%"></span></div>'
        f"</div></article>"
    )


def ranking_list(items: Iterable[dict[str, Any]]) -> str:
    body = "".join(ranking_item(item) for item in items)
    return f'<section class="c-ranking-list">{body}</section>'


def topic_tags(tags: Iterable[str]) -> str:
    chips = "".join(f"<span>{escape(tag)}</span>" for tag in tags if tag)
    if not chips:
        return ""
    return f'<div class="c-topic-tags">{chips}</div>'


def footer(text: str, page_number: str = "") -> str:
    right = f'<span class="c-page-number">{escape(page_number)}</span>' if page_number else "<span></span>"
    return f'<footer class="c-footer"><span>{escape(text)}</span>{right}</footer>'


def category_tag(label: str) -> str:
    return f'<span class="c-category-tag">{escape(label)}</span>'


def rank_pill(rank: int) -> str:
    return f'<span class="c-rank-pill">NO.{int(rank):02d}</span>'


def hero_visual(src: str = "", caption: str = "Hero Visual") -> str:
    image = f'<img src="{escape(src, quote=True)}" alt="">' if src else ""
    return (
        f'<div class="c-hero-visual">{image}'
        f'<div class="c-hero-caption">{escape(caption)}</div></div>'
    )


def quote_card(label: str, message: str) -> str:
    return (
        f'<section class="c-quote-card"><div class="label">{escape(label)}</div>'
        f"<p>{escape(message)}</p></section>"
    )


def feature_list(items: Iterable[str]) -> str:
    rows = "".join(f"<li>{escape(item)}</li>" for item in items if item)
    return (
        f'<section class="c-panel"><h3>核心能力</h3>'
        f'<ul class="c-feature-list">{rows}</ul></section>'
    )


def workflow_diagram(steps: Iterable[str]) -> str:
    chips = "".join(f"<span>{escape(step)}</span>" for step in steps if step)
    return f'<section class="c-panel"><h3>工作流</h3><div class="c-workflow">{chips}</div></section>'


def audience_card(people: Iterable[str]) -> str:
    text = "  ·  ".join(person for person in people if person)
    return (
        f'<section class="c-panel c-audience-card"><h3>适合人群</h3>'
        f"<p>{escape(text)}</p></section>"
    )


def url_card(url: str, display: str = "") -> str:
    shown = display or url
    return (
        f'<section class="c-panel c-url-card"><h3>项目地址</h3>'
        f"<p>{escape(shown)}</p></section>"
    )


def _initial(name: str) -> str:
    cleaned = (name or "?").strip()
    if not cleaned:
        return "?"
    return cleaned[0].upper()
