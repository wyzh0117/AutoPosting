from __future__ import annotations

from typing import Any


def ranking_from_repos(
    repos: list[dict[str, Any]],
    *,
    brand: str = "AutoPosting",
    series: str = "GitHub 本周爆火 AI 项目榜",
    issue: str = "",
    date_range: str = "",
) -> dict[str, Any]:
    items = []
    tags: list[str] = []
    for index, repo in enumerate(repos[:10], start=1):
        kind = str(repo.get("kind") or repo.get("category") or "")
        if kind and kind not in tags:
            tags.append(kind)
        items.append(
            {
                "rank": int(repo.get("rank") or index),
                "name": str(repo.get("name") or ""),
                "description": str(repo.get("summary") or repo.get("description") or ""),
                "category": kind,
                "logo": str(repo.get("icon_url") or repo.get("logo") or ""),
                "url": str(repo.get("url") or ""),
                "metric": {
                    "label": "Stars",
                    "value": int(repo.get("stars") or 0),
                },
            }
        )
    return {
        "page": "ranking-overview",
        "brand": brand,
        "series": series,
        "issue": issue or "本周",
        "dateRange": date_range,
        "kicker": "WEEKLY RANKING",
        "title": "GitHub",
        "subtitle": "本周爆火 AI 项目榜",
        "source": "GitHub",
        "footer": "专业 AI 科技媒体 · 每周更新",
        "tags": tags[:6],
        "items": items,
    }


def project_from_repo(
    repo: dict[str, Any],
    *,
    brand: str = "AutoPosting",
    series: str = "GitHub 本周爆火 AI 项目榜",
    issue: str = "",
    page_number: str = "",
) -> dict[str, Any]:
    features = [part for part in _split(str(repo.get("does") or "")) if part]
    if not features:
        features = [str(repo.get("kind") or "开源工具")]
    audience = [part for part in _split(str(repo.get("scene") or "")) if part]
    if not audience:
        audience = ["关注开源 AI 的读者"]
    return {
        "page": "project-detail",
        "brand": brand,
        "series": series,
        "issue": issue or "本周",
        "pageNumber": page_number,
        "rank": int(repo.get("rank") or 1),
        "category": str(repo.get("kind") or "AI 工具"),
        "name": str(repo.get("name") or ""),
        "tagline": str(repo.get("summary") or repo.get("description") or ""),
        "description": str(repo.get("description") or ""),
        "keyMessage": str(repo.get("how") or repo.get("summary") or repo.get("description") or ""),
        "heroVisual": "",
        "logo": str(repo.get("icon_url") or ""),
        "features": features,
        "workflow": ["阅读介绍", "打开仓库", "按文档试用"],
        "audience": audience,
        "url": str(repo.get("url") or ""),
        "source": "GitHub",
        "footer": "专业 AI 科技媒体 · 每周更新",
        "metrics": [{"label": "Stars", "value": int(repo.get("stars") or 0)}],
    }


def _split(text: str) -> list[str]:
    for separator in ("、", "，", ",", "；", ";"):
        if separator in text:
            return [part.strip() for part in text.split(separator) if part.strip()]
    return [text.strip()] if text.strip() else []
