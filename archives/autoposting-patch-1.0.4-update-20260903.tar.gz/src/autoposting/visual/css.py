from __future__ import annotations

from .tokens import flatten_tokens, load_tokens


def stylesheet() -> str:
    tokens = load_tokens()
    variables = "\n".join(f"    --{name}: {value};" for name, value in flatten_tokens().items())
    canvas = tokens["canvas"]
    safe = tokens["safeArea"]
    color = tokens["color"]
    type_ = tokens["typography"]
    space = tokens["spacing"]
    radius = tokens["radius"]
    return f"""
:root {{
{variables}
}}
* {{ box-sizing: border-box; }}
html, body {{
  margin: 0;
  padding: 0;
  width: {canvas["width"]}px;
  height: {canvas["height"]}px;
  overflow: hidden;
  background: {color["background"]};
  color: {color["text"]["primary"]};
  font-family: {type_["fontFamily"]["cjk"]};
  -webkit-font-smoothing: antialiased;
}}
.page {{
  position: relative;
  width: {canvas["width"]}px;
  height: {canvas["height"]}px;
  padding: {safe["top"]}px {safe["right"]}px {safe["bottom"]}px {safe["left"]}px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background:
    linear-gradient(180deg, rgba(139,124,255,0.07), transparent 28%),
    {color["background"]};
}}
.page::before {{
  content: "";
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient({color["backgroundGrid"]} 1px, transparent 1px),
    linear-gradient(90deg, {color["backgroundGrid"]} 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse at top, #000 40%, transparent 78%);
  pointer-events: none;
}}
.page > * {{ position: relative; z-index: 1; }}
.c-brand-header {{
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 36px;
}}
.c-brand-mark {{
  display: flex;
  align-items: center;
  gap: {space["sm"]}px;
  font-size: {type_["caption"]["size"]}px;
  font-weight: {tokens["fontWeight"]["semibold"]};
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: {color["text"]["secondary"]};
}}
.c-brand-mark i {{
  width: 14px;
  height: 14px;
  border-radius: 4px;
  background: {color["primary"]};
  box-shadow: {tokens["glow"]["accent"]};
  display: block;
}}
.c-issue-badge, .c-category-tag, .c-page-number {{
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  border: 1px solid {color["border"]};
  border-radius: {radius["pill"]}px;
  color: {color["text"]["secondary"]};
  font-size: {type_["caption"]["size"]}px;
  letter-spacing: 0.08em;
}}
.c-issue-badge, .c-page-number {{
  text-transform: uppercase;
}}
.c-category-tag {{
  letter-spacing: 0.04em;
}}
.c-hero-title {{
  margin: {space["lg"]}px 0 0;
  font-family: {type_["fontFamily"]["latin"]};
  font-size: {type_["h1"]["size"]}px;
  font-weight: {type_["h1"]["weight"]};
  line-height: {type_["h1"]["lineHeight"]};
  letter-spacing: {type_["h1"]["letterSpacing"]};
  max-height: calc({type_["h1"]["size"]}px * {type_["h1"]["lineHeight"]} * 2);
  overflow: hidden;
}}
.c-hero-sub {{
  margin: {space["sm"]}px 0 0;
  font-size: {type_["subtitle"]["size"]}px;
  font-weight: {type_["subtitle"]["weight"]};
  color: {color["text"]["secondary"]};
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}}
.c-meta-row {{
  margin-top: {space["md"]}px;
  display: flex;
  gap: {space["md"]}px;
  color: {color["text"]["muted"]};
  font-size: {type_["caption"]["size"]}px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}}
.c-ranking-list {{
  flex: 1;
  min-height: 0;
  margin-top: {space["lg"]}px;
  display: flex;
  flex-direction: column;
  gap: {space["xs"]}px;
}}
.c-ranking-item {{
  flex: 1;
  min-height: 0;
  display: grid;
  grid-template-columns: 56px 64px minmax(0, 1fr) 108px;
  align-items: center;
  gap: {space["md"]}px;
  padding: 0 {space["md"]}px;
  background: {color["surface"]};
  border: 1px solid {color["border"]};
  border-radius: {radius["card"]}px;
  box-shadow: {tokens["shadow"]["card"]};
}}
.c-ranking-badge {{
  font-family: {type_["fontFamily"]["latin"]};
  font-size: {type_["rank"]["size"]}px;
  font-weight: {type_["rank"]["weight"]};
  letter-spacing: {type_["rank"]["letterSpacing"]};
  color: {color["rank"]};
}}
.c-ranking-item:nth-child(n+4) .c-ranking-badge {{ color: {color["rankMuted"]}; }}
.c-project-logo {{
  width: 56px;
  height: 56px;
  border-radius: {radius["logo"]}px;
  border: 1px solid {color["border"]};
  background: {color["primaryMuted"]};
  color: {color["primary"]};
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  font-family: {type_["fontFamily"]["latin"]};
  font-weight: 700;
  font-size: 22px;
}}
.c-project-logo img {{ width: 100%; height: 100%; object-fit: contain; }}
.c-item-copy {{ min-width: 0; }}
.c-item-name {{
  font-family: {type_["fontFamily"]["latin"]};
  font-size: 22px;
  font-weight: 600;
  letter-spacing: -0.02em;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}}
.c-item-desc {{
  margin-top: 4px;
  font-size: 15px;
  color: {color["text"]["secondary"]};
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}}
.c-metric {{
  text-align: right;
}}
.c-metric-value {{
  font-family: {type_["fontFamily"]["latin"]};
  font-size: {type_["metric"]["size"]}px;
  font-weight: {type_["metric"]["weight"]};
  color: {color["metric"]};
}}
.c-metric-label {{
  margin-top: 2px;
  font-size: 11px;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: {color["text"]["muted"]};
}}
.c-progress-bar {{
  margin-top: 8px;
  width: 100%;
  height: 4px;
  border-radius: 999px;
  background: {color["progressTrack"]};
  overflow: hidden;
}}
.c-progress-bar > span {{
  display: block;
  height: 100%;
  border-radius: 999px;
  background: {color["progressFill"]};
}}
.c-topic-tags {{
  display: flex;
  flex-wrap: nowrap;
  gap: {space["xs"]}px;
  margin-top: {space["md"]}px;
  overflow: hidden;
}}
.c-topic-tags span {{
  flex: 0 0 auto;
  padding: 6px 12px;
  border-radius: {radius["pill"]}px;
  border: 1px solid {color["border"]};
  color: {color["text"]["secondary"]};
  font-size: 13px;
}}
.c-footer {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: {space["md"]}px;
  color: {color["text"]["muted"]};
  font-size: 13px;
  letter-spacing: 0.04em;
}}
.page-project .c-hero-title {{ font-size: 56px; margin-top: {space["md"]}px; }}
.page-project .c-hero-visual {{
  flex: 1;
  min-height: 280px;
  height: auto;
}}
.c-title-row {{
  display: flex;
  gap: {space["sm"]}px;
  align-items: center;
  margin-top: {space["md"]}px;
}}
.c-rank-pill {{
  min-width: 64px;
  height: 36px;
  padding: 0 12px;
  border-radius: {radius["pill"]}px;
  background: {color["primary"]};
  color: {color["text"]["onPrimary"]};
  font-family: {type_["fontFamily"]["latin"]};
  font-weight: 700;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}}
.c-hero-visual {{
  margin-top: {space["lg"]}px;
  height: 360px;
  border-radius: {radius["card"]}px;
  border: 1px solid {color["border"]};
  background:
    radial-gradient(circle at 30% 30%, {color["glow"]}, transparent 42%),
    radial-gradient(circle at 80% 70%, rgba(232, 213, 163, 0.16), transparent 36%),
    {color["surface"]};
  overflow: hidden;
  position: relative;
}}
.c-hero-visual img {{ width: 100%; height: 100%; object-fit: cover; }}
.c-hero-visual .c-hero-caption {{
  position: absolute;
  left: {space["lg"]}px;
  bottom: {space["lg"]}px;
  color: {color["text"]["secondary"]};
  font-size: 13px;
  letter-spacing: 0.14em;
  text-transform: uppercase;
}}
.c-quote-card {{
  margin-top: {space["lg"]}px;
  padding: {space["lg"]}px;
  border-radius: {radius["card"]}px;
  background: {color["surface"]};
  border: 1px solid {color["border"]};
}}
.c-quote-card .label {{
  font-size: 12px;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: {color["primary"]};
}}
.c-quote-card p {{
  margin: {space["sm"]}px 0 0;
  font-size: 22px;
  line-height: 1.4;
  color: {color["quote"]};
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}}
.c-split {{
  margin-top: {space["lg"]}px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: {space["md"]}px;
  min-height: 0;
}}
.c-panel {{
  padding: {space["lg"]}px;
  border-radius: {radius["card"]}px;
  background: {color["surface"]};
  border: 1px solid {color["border"]};
  min-height: 0;
}}
.c-panel h3 {{
  margin: 0 0 {space["md"]}px;
  font-size: 13px;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: {color["text"]["muted"]};
  font-weight: 600;
}}
.c-feature-list {{
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 10px;
}}
.c-feature-list li {{
  display: flex;
  gap: 10px;
  align-items: center;
  font-size: 18px;
}}
.c-feature-list li::before {{
  content: "";
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: {color["primary"]};
  flex: 0 0 auto;
}}
.c-workflow {{
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}}
.c-workflow span {{
  padding: 8px 10px;
  border-radius: {radius["sm"]}px;
  background: {color["surfaceRaised"]};
  border: 1px solid {color["border"]};
  font-size: 14px;
  color: {color["text"]["secondary"]};
}}
.c-audience-card, .c-url-card {{
  margin-top: {space["md"]}px;
}}
.c-audience-card p, .c-url-card p {{
  margin: 0;
  font-size: 18px;
  line-height: 1.45;
  color: {color["text"]["secondary"]};
}}
.c-url-card p {{
  font-family: {type_["fontFamily"]["latin"]};
  color: {color["metric"]};
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}}
""".strip()
