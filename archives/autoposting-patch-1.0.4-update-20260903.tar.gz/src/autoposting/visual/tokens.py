from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

from .paths import tokens_path


@lru_cache(maxsize=1)
def load_tokens() -> dict[str, Any]:
    path = tokens_path()
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"tokens must be an object: {path}")
    return payload


def token(path: str) -> Any:
    current: Any = load_tokens()
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            raise KeyError(path)
        current = current[part]
    return current


def flatten_tokens(node: Any = None, prefix: str = "") -> dict[str, str]:
    if node is None:
        node = load_tokens()
    flat: dict[str, str] = {}
    if isinstance(node, dict):
        for key, value in node.items():
            if key == "meta":
                continue
            child = f"{prefix}-{key}" if prefix else key
            if isinstance(value, dict) and any(isinstance(item, (dict, list)) for item in value.values()):
                flat.update(flatten_tokens(value, child))
            elif isinstance(value, dict) and all(
                not isinstance(item, (dict, list)) for item in value.values()
            ):
                for inner_key, inner_value in value.items():
                    flat[f"{child}-{inner_key}"] = _css_value(inner_value)
            else:
                flat[child] = _css_value(value)
    return flat


def _css_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)
