from __future__ import annotations

from pathlib import Path
from typing import Any

from .pages import render_html
from .schema import infer_kind, load_example, validate_content
from .screenshot import screenshot_html
from .tokens import load_tokens

PNG_WIDTH = 1080
PNG_HEIGHT = 1920


def render_page(
    payload: dict[str, Any],
    *,
    out_dir: Path | None = None,
    screenshot: bool = True,
) -> dict[str, Any]:
    kind = infer_kind(payload)
    validate_content(kind, payload)
    html = render_html(payload)
    page = str(payload["page"])
    result: dict[str, Any] = {
        "page": page,
        "kind": kind,
        "html_text": html,
        "html": "",
        "png": "",
        "width": int(load_tokens()["canvas"]["width"]),
        "height": int(load_tokens()["canvas"]["height"]),
    }
    if out_dir is None:
        return result
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / f"{page}.html"
    html_path.write_text(html, encoding="utf-8")
    result["html"] = str(html_path)
    if screenshot:
        png_path = screenshot_html(html_path, out_dir / f"{page}.png")
        result["png"] = str(png_path)
    return result


def render_examples(out_dir: Path, *, screenshot: bool = True) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for kind in ("ranking", "project"):
        payload = load_example(kind)
        target = out_dir / str(payload["page"])
        rows.append(render_page(payload, out_dir=target, screenshot=screenshot))
    return rows
