from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from .background import article_page_text
from .config import load_sources
from .content import ContentWorkflow
from .db import Database, model_endpoint_id
from .llm import (
    LLM_EFFORT,
    LLM_MODEL,
    LLM_PROVIDER,
    LLMError,
    LLMService,
    MacOSKeychainCredentialStore,
    _has_cjk,
    validate_chat_messages,
)
from .github_weekly import (
    XHS_TITLE,
    build_xhs_copy,
    fetch_weekly_ai_repos,
    week_window_start,
)
from .image_gen import build_weekly_image_jobs
from .skill_finder import find_skills, render_skill_package
from .visual.tokens import parse_palette
from .visual.weekly import render_weekly_visual
from .images import default_page_fetcher, guess_image_content_type, normalize_assets
from .publishing import PublicationError, PublicationService
from .scheduler import PublishScheduler, parse_run_at
from .article_prompt import DEFAULT_ARTICLE_PROMPT_STYLE
from .workbench import (
    DEFAULT_WECHAT_BASE_URL,
    HOTSPOT_HOUR_MAX,
    HOTSPOT_HOUR_MIN,
    HotspotService,
    WeChatPublisher,
    WechatConfigurationRequired,
    Workbench,
    XIAOHONGSHU_CREATOR_URL,
    _download_image as download_image,
    _summary,
    xhs_fields,
)

APP_VERSION = "1.2.2"
ALLOWED_HOSTS = ("127.0.0.1", "localhost")
MAX_JSON_BODY_BYTES = 1_048_576
MAX_CHAT_JSON_BODY_BYTES = 4_194_304
ACCOUNT_STORE_IDS = {
    "wechat": "account:wechat",
    "x": "account:x",
    "xiaohongshu": "account:xiaohongshu",
}


def _looks_english(text: str) -> bool:
    cjk = sum("\u3400" <= char <= "\u9fff" for char in text)
    latin = sum(char.isascii() and char.isalpha() for char in text)
    return latin > cjk

INDEX_HTML = """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AutoPosting</title>
<style>
:root {
  --bg-main: #12110e;
  --bg-card: #1b1914;
  --bg-input: #23211b;
  --bg-raised: #2a271f;
  --text-main: #f3eee4;
  --text-muted: #9a9284;
  --accent: #c4a46a;
  --accent-glow: rgba(196, 164, 106, 0.16);
  --accent-gradient-1: #d4b57a;
  --accent-gradient-2: #8a7348;
  --border: #3a352c;
  --ok: #6f9e7a;
  --err: #c47a6a;
  --warn: #c4a46a;
  --radius-lg: 20px;
  --radius-md: 14px;
  --radius-sm: 8px;
  --ease: cubic-bezier(0.22, 1, 0.36, 1);
  --t-fast: 160ms;
  --t-mid: 280ms;
  --t-slow: 460ms;
  --hotspot-list-h: 29rem;
  --favorites-drawer-w: 20rem;
  --font: "Avenir Next", "Segoe UI", -apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  --display: "Iowan Old Style", "Palatino Linotype", Palatino, "Songti SC", Georgia, serif;
}

*{box-sizing:border-box; letter-spacing:0;}
html,body{margin:0; padding:0;}
body{
  background-color:var(--bg-main); color:var(--text-main);
  font:14px/1.6 var(--font); padding:1.5rem 2rem 2rem;
  display:flex; flex-direction:column; align-items:center;
  min-height:100dvh; height:auto; overflow-x:hidden; overflow-y:auto;
  background-image:
    radial-gradient(circle at 88% -8%, rgba(196, 164, 106, 0.12), transparent 42%),
    radial-gradient(circle at 0% 110%, rgba(111, 158, 122, 0.06), transparent 34%);
}
.sr-only{position:absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0,0,0,0); white-space:nowrap; border:0;}
@keyframes rise{from{opacity:0; transform:translateY(10px);} to{opacity:1; transform:translateY(0);}}
@keyframes fade{from{opacity:0;} to{opacity:1;}}

header{
  width:100%; max-width:1400px; display:flex; align-items:center; gap:1rem;
  margin-bottom:1.15rem; flex-wrap:wrap;
  animation:rise var(--t-slow) var(--ease) both;
}
.brand{display:flex; flex-direction:column; gap:.1rem; min-width:0;}
header h1.logo{
  font-family:var(--display); font-size:1.85rem; font-weight:600; letter-spacing:.02em; margin:0;
  color:var(--text-main);
}
.brand-kicker{
  margin:0; font-size:.68rem; letter-spacing:.18em; text-transform:uppercase;
  color:var(--accent); font-weight:600;
}
#service-status{
  font-size:.72rem; color:var(--text-muted);
  background:rgba(196, 164, 106, 0.06); padding:.28rem .8rem;
  border-radius:99px; border:1px solid var(--border);
}
#config-btn{
  margin-left:auto; border-radius:99px; padding:.5rem 1.2rem;
  border:1px solid var(--border); background:var(--bg-card);
  color:var(--text-main); font-weight:500;
}
#config-btn:hover:not(:disabled){background:var(--bg-input); border-color:var(--accent); box-shadow:none;}
#favorites-btn{
  border-radius:99px; padding:.5rem 1.2rem;
  border:1px solid var(--border); background:var(--bg-card);
  color:var(--text-main); font-weight:500;
}
#favorites-btn:hover:not(:disabled){background:var(--bg-input); border-color:var(--accent); box-shadow:none;}
#favorites-btn[aria-expanded="true"]{border-color:var(--accent); color:var(--accent);}
#favorites-drawer{
  display:none; position:fixed; top:0; right:0; bottom:0;
  width:var(--favorites-drawer-w); z-index:40;
  background:linear-gradient(180deg, rgba(36, 33, 26, 0.98), rgba(22, 20, 16, 0.98));
  border-left:1px solid var(--border);
  flex-direction:column; padding:1rem 1rem 1.2rem;
  overflow:hidden;
}
body.favorites-open #favorites-drawer{display:flex;}
body.favorites-open header,
body.favorites-open #app-nav,
body.favorites-open main,
body.favorites-open #wait-banner{
  margin-right:var(--favorites-drawer-w);
  width:calc(100% - var(--favorites-drawer-w));
}
.favorites-drawer-head{
  display:flex; align-items:center; gap:.75rem; margin-bottom:.85rem;
}
.favorites-drawer-head h2{margin:0; font-size:1rem; font-weight:600;}
#favorites-close{
  margin-left:auto; border-radius:99px; padding:.35rem .8rem;
  border:1px solid var(--border); background:var(--bg-card); color:var(--text-main);
}
#favorites-list{
  list-style:none; margin:0; padding:0; overflow-y:auto; min-height:0; flex:1;
  display:flex; flex-direction:column; gap:.75rem;
}
.fav-item{
  position:relative; background:var(--bg-input); border:1px solid transparent;
  border-radius:var(--radius-md); padding:.8rem 2.4rem .8rem .9rem;
}
.fav-item.is-picked, .hotspot-item.is-picked{
  border-color:var(--accent);
  background:linear-gradient(145deg, rgba(196, 164, 106, 0.16), rgba(196, 164, 106, 0.05));
  box-shadow:inset 0 0 0 1px rgba(196, 164, 106, 0.35);
}
.hotspot-row{position:relative;}
.ht-star{
  position:absolute; top:.45rem; right:.45rem; z-index:2;
  width:1.8rem; height:1.8rem; padding:0; border:0; border-radius:999px;
  background:transparent; color:var(--text-muted); font-size:1.05rem; line-height:1;
  cursor:pointer;
}
.ht-star[aria-pressed="true"]{color:var(--accent);}

#app-nav{
  width:100%; max-width:1400px;
  display:flex; justify-content:space-between; align-items:center;
  gap:.75rem; flex-wrap:wrap;
  margin:0 0 1rem;
}
#app-nav .platform-tabs[aria-label="候选栏"]{
  width:auto; max-width:none; flex:1 1 32rem;
}
#app-nav .platform-tabs[aria-label="候选栏"] button.seg{
  flex:1 1 0; font-size:.82rem; padding:.42rem .7rem;
}
#app-nav .platform-tabs[aria-label="平台选择"]{
  margin-left:auto; flex:0 0 auto;
}

#wait-banner{
  width:100%; max-width:1400px; position:relative; z-index:2;
  display:flex; flex-direction:column; gap:.55rem;
  margin:0 0 1rem; padding:0; border:none; background:transparent; box-shadow:none;
  pointer-events:none;
}
#wait-banner[hidden]{display:none !important;}
#wait-jobs{display:flex; flex-direction:column; gap:.55rem; pointer-events:none;}
.wait-job{
  display:grid; grid-template-columns:auto minmax(0,1fr) auto auto; gap:.35rem .7rem; align-items:center;
  padding:.85rem 1rem .8rem;
  border-radius:var(--radius-md); border:1px solid var(--accent);
  background:linear-gradient(180deg, #322a1c, #1f1b14);
  box-shadow:0 16px 36px -12px rgba(0,0,0,.7), 0 0 0 4px var(--accent-glow);
}
.wait-job.is-done{border-color:var(--ok); box-shadow:0 0 0 4px rgba(111,158,122,.18);}
.wait-job.is-error{border-color:var(--err); box-shadow:0 0 0 4px rgba(196,122,106,.18);}
.wait-spinner{
  width:1.55rem; height:1.55rem; border-radius:50%; flex:0 0 auto;
  border:3px solid rgba(196,164,106,.22); border-top-color:var(--accent);
  animation:waitSpin .7s linear infinite;
}
.wait-job.is-done .wait-spinner,.wait-job.is-error .wait-spinner{animation:none; border-color:currentColor;}
@keyframes waitSpin{to{transform:rotate(360deg);}}
.wait-title{margin:0; font-size:.95rem; font-weight:700; color:var(--text-main);}
.wait-detail{margin:.12rem 0 0; font-size:.78rem; color:var(--text-muted); line-height:1.4;}
.wait-time{margin:0; font-variant-numeric:tabular-nums; font-weight:700; color:var(--accent); white-space:nowrap;}
.wait-stop{
  pointer-events:auto;
  height:32px; min-height:32px; padding:.2rem .85rem; border-radius:99px;
  font-size:.78rem; font-weight:700; color:var(--err); border-color:rgba(196,122,106,.55);
  background:rgba(196,122,106,.08);
}
.wait-stop:hover:not(:disabled){background:rgba(196,122,106,.18); border-color:var(--err);}
.wait-job.is-done .wait-stop,.wait-job.is-error .wait-stop{display:none;}
.wait-job:not(.is-done):not(.is-error){animation:waitJobPulse 1.8s ease-in-out infinite;}
@keyframes waitJobPulse{
  0%,100%{box-shadow:0 16px 36px -12px rgba(0,0,0,.7), 0 0 0 3px var(--accent-glow);}
  50%{box-shadow:0 16px 36px -12px rgba(0,0,0,.7), 0 0 0 8px var(--accent-glow);}
}
@keyframes waitPulse{
  0%,100%{box-shadow:0 0 0 0 var(--accent-glow);}
  50%{box-shadow:0 0 0 7px var(--accent-glow);}
}
.gh-tile.is-running{border-color:var(--accent); animation:waitPulse 1.15s ease-in-out infinite;}
.gh-tile.is-queued img{opacity:.28; filter:grayscale(.35);}
.gh-tile.is-error{border-color:var(--err);}
.gh-tile .gh-overlay{
  position:absolute; left:0; right:0; bottom:0; z-index:1; margin:0;
  background:rgba(12,11,8,.8); color:var(--accent); font-weight:700;
  text-align:center; padding:.85rem .5rem;
}
.gh-tile.is-running .gh-overlay{color:#1a160f; background:rgba(196,164,106,.92);}
.gh-tile.is-error .gh-overlay{color:#f3eee4; background:rgba(196,122,106,.92);}

main{
  width:100%; max-width:1400px;
  display:grid; grid-template-columns:1fr 2fr; gap:1.25rem;
  flex:1 0 auto; min-height:calc(100dvh - 8.1rem); min-width:0;
  align-items:start;
}
.panel{
  background:linear-gradient(180deg, rgba(36, 33, 26, 0.92), rgba(22, 20, 16, 0.94));
  border-radius:var(--radius-lg); border:1px solid var(--border);
  padding:1.15rem 1.2rem 1.1rem; display:flex; flex-direction:column;
  box-shadow:0 18px 40px -18px rgba(0, 0, 0, 0.72), inset 0 1px 0 rgba(243, 238, 228, 0.04);
  min-width:0; max-width:100%; height:auto; overflow:visible;
  animation:rise var(--t-slow) var(--ease) both;
}
#hotspots-panel{
  height:auto; max-height:none;
  min-height:0; overflow:hidden;
}
#hotspots-panel.sources-open{
  height:auto; max-height:none; overflow:visible;
}
.panel-header{display:flex; justify-content:space-between; align-items:flex-start; gap:.75rem; flex-wrap:wrap; margin-bottom:.75rem;}
.panel-title{font-size:1.05rem; font-weight:700; color:var(--text-main); margin:0; letter-spacing:.01em;}
.panel-sub{font-size:.72rem; color:var(--text-muted); margin:.2rem 0 0; line-height:1.45;}

.row{display:flex; gap:.5rem; align-items:center; flex-wrap:wrap;}
.row > select,.row > input,.row > button{height:40px; min-height:40px; padding-top:0; padding-bottom:0;}
select, input[type=text], input[type=password], textarea{
  border:1px solid var(--border); border-radius:var(--radius-sm);
  padding:.5rem .8rem; font:inherit;
  background:var(--bg-input); color:var(--text-main); min-width:0; max-width:100%;
}
input[type=number], input[type=datetime-local]{
  border:1px solid var(--border); border-radius:var(--radius-sm);
  background:var(--bg-input); color:var(--text-main); height:40px;
  font:inherit; color-scheme:dark; min-width:0;
}
select option{background:var(--bg-input); color:var(--text-main);}
input[type=text], input[type=password], textarea{width:100%; border-radius:var(--radius-md); padding:.8rem 1rem;}
select,input[type=text],input[type=password]{height:40px; padding-top:0; padding-bottom:0;}
select:hover, input:hover, textarea:hover{border-color:var(--accent);}
select:focus, input:focus, textarea:focus{
  border-color:var(--accent); background:rgba(255,255,255,0.02);
  box-shadow:inset 0 0 0 1px var(--accent-glow); outline:none;
}
label{font-size:.85rem; font-weight:600; color:var(--text-muted);}
button{
  font:inherit; border:1px solid var(--border); border-radius:var(--radius-sm);
  padding:.5rem 1rem; background:var(--bg-input); color:var(--text-main);
  cursor:pointer; outline:none;
  transition:background var(--t-fast) var(--ease), border-color var(--t-fast) var(--ease), transform var(--t-fast) var(--ease), box-shadow var(--t-fast) var(--ease), color var(--t-fast) var(--ease), filter var(--t-fast) var(--ease);
}
button:hover:not(:disabled){
  background:var(--bg-raised); border-color:var(--accent);
  box-shadow:0 0 0 3px var(--accent-glow); transform:translateY(-1px);
}
button:disabled{opacity:.5; cursor:not-allowed;}
button,.model-picker{display:inline-flex; align-items:center; justify-content:center; vertical-align:middle;}
button.primary{
  background:linear-gradient(135deg, var(--accent-gradient-1), var(--accent-gradient-2));
  color:#1a160f; border:1px solid var(--accent);
  font-weight:700; padding:.8rem 2.5rem; border-radius:99px; font-size:1rem;
  box-shadow:0 8px 18px var(--accent-glow);
}
button.primary:hover:not(:disabled){
  background:linear-gradient(135deg, #ddc08a, var(--accent-gradient-2));
  transform:translateY(-1px); box-shadow:0 10px 22px var(--accent-glow);
}
button.seg{flex:1 1 auto; min-width:0; white-space:nowrap; border-radius:99px; border-color:transparent;}
button.seg.active{
  background:var(--bg-card); color:var(--text-main);
  box-shadow:0 2px 10px rgba(0,0,0,0.35); border-color:var(--border);
}
.platform-tabs{
  display:flex; background:var(--bg-input); border-radius:99px;
  padding:.25rem; border:1px solid rgba(243, 238, 228, 0.04);
}
.platform-tabs button{flex:0 1 auto;}
.platform-tabs[aria-label="候选栏"]{width:100%; max-width:36rem;}
.platform-tabs[aria-label="候选栏"] button.seg{
  flex:1 1 0; font-size:.82rem; padding:.42rem .55rem; letter-spacing:0;
}
body.lane-github .panel-title{letter-spacing:0; font-weight:700;}
body.lane-github .panel-header .row{width:100%;}
.btn-magic{
  background:linear-gradient(135deg, var(--accent-gradient-2), var(--accent-gradient-1));
  color:#1a160f; border:1px solid var(--accent); font-weight:700;
  display:flex; align-items:center; gap:.5rem;
  border-radius:99px; padding:.55rem 1.35rem;
  box-shadow:0 6px 16px var(--accent-glow);
}
.btn-magic:hover:not(:disabled){filter:brightness(1.08); transform:translateY(-1px);}

.rank-toolbar{display:flex; align-items:center; justify-content:space-between; gap:.75rem; margin:0 0 .65rem;}
#rank-tabs{margin:0; align-self:flex-start;}
#prompt-style-select{width:auto; min-width:8.5rem;}
#hotspot-pane{flex:0 0 auto; min-height:0; height:auto; display:flex; flex-direction:column; min-width:0; overflow:hidden;}
#hotspots-panel.sources-open #hotspot-pane{
  flex:0 0 auto; height:auto; min-height:0; overflow:hidden;
}
#source-health-wrap{
  flex:0 0 auto; margin-top:.6rem; padding-top:.55rem;
  border-top:1px solid var(--border);
}
#source-health-toggle{
  width:100%; justify-content:space-between; text-align:left;
  height:auto; min-height:34px; padding:.4rem .7rem; font-size:.75rem;
}
#source-health-legend{display:none; margin:.45rem 0 0; font-size:.72rem; color:var(--text-muted); line-height:1.45;}
#hotspots-panel.sources-open #source-health-legend{display:block;}
#source-health{
  list-style:none; margin:.5rem 0 0; padding:0 .25rem 0 0;
  display:flex; flex-direction:column; gap:.35rem;
  max-height:none; overflow:visible; min-height:0;
}
#source-health[hidden]{display:none;}
.source-health{
  display:flex; align-items:center; gap:.45rem; min-width:0;
  font-size:.75rem; color:var(--text-muted);
}
.source-health .sh-name{flex:1 1 auto; min-width:0; color:var(--text-main); overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
.source-health .sh-meta{flex:0 1 42%; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
.source-health .sh-dot{width:7px; height:7px; border-radius:50%; flex:0 0 auto;}
.source-health .sh-dot.ok{background:var(--ok);}
.source-health .sh-dot.error{background:var(--err);}
.source-health .sh-dot.stale{background:var(--warn);}
.source-health .sh-dot.never,.source-health .sh-dot.disabled{background:#5a564c;}
.source-health button{height:28px; min-height:28px; padding:0 .6rem; font-size:.72rem;}
#hotspot-list{
  list-style:none; margin:0; padding:0 .45rem 0 0;
  flex:0 0 auto; overflow-y:auto; min-height:0;
  height:var(--hotspot-list-h); max-height:var(--hotspot-list-h);
  display:flex; flex-direction:column; gap:.75rem;
  overscroll-behavior:contain; scrollbar-gutter:stable; scrollbar-width:thin;
}
#hotspot-list li{margin:0; animation:rise var(--t-mid) var(--ease) both;}
#hotspot-list li:nth-child(1){animation-delay:40ms;}
#hotspot-list li:nth-child(2){animation-delay:80ms;}
#hotspot-list li:nth-child(3){animation-delay:120ms;}
#hotspot-list li:nth-child(4){animation-delay:160ms;}
#hotspot-list li:nth-child(5){animation-delay:200ms;}
#hotspot-list li:nth-child(n+6){animation-delay:240ms;}
#hotspot-list::-webkit-scrollbar, .dialog-content::-webkit-scrollbar, .article-scroll::-webkit-scrollbar, #chat-output::-webkit-scrollbar, #image-picker-list::-webkit-scrollbar, #hook-list::-webkit-scrollbar{width:4px;}
#hotspot-list::-webkit-scrollbar-thumb, .dialog-content::-webkit-scrollbar-thumb, .article-scroll::-webkit-scrollbar-thumb, #chat-output::-webkit-scrollbar-thumb, #image-picker-list::-webkit-scrollbar-thumb, #hook-list::-webkit-scrollbar-thumb{background:var(--accent-gradient-2); border-radius:4px;}
.hotspot-item{
  display:block; width:100%; text-align:left;
  background:var(--bg-input); border:1px solid transparent;
  border-radius:var(--radius-md); padding:.8rem 2.4rem .8rem .9rem;
  cursor:pointer; position:relative; word-break:break-word;
  transition:background var(--t-fast) var(--ease), border-color var(--t-fast) var(--ease), transform var(--t-fast) var(--ease), box-shadow var(--t-fast) var(--ease);
}
.hotspot-item:hover:not(:disabled){border-color:rgba(196, 164, 106, 0.35); transform:translateY(-2px);}
.hotspot-item.selected{
  border-color:var(--accent);
  background:linear-gradient(145deg, var(--bg-input), rgba(196, 164, 106, 0.08));
  box-shadow:0 4px 20px var(--accent-glow);
}
.hotspot-item.selected::before{
  content:''; position:absolute; left:-1px; top:20%; height:60%; width:3px;
  background:linear-gradient(to bottom, var(--accent-gradient-1), var(--accent-gradient-2));
  border-radius:0 4px 4px 0;
}
.idx{display:inline; color:var(--accent); font-weight:600; margin-right:.3rem;}
.ht-label{
  display:inline-block; font-size:.68rem; color:var(--accent);
  background:rgba(196, 164, 106, 0.08); border:1px solid rgba(196, 164, 106, 0.18);
  padding:.15rem .45rem; border-radius:4px; font-weight:600; margin:0 0 .4rem;
}
.ht-title{display:block; font-size:.95rem; font-weight:600; line-height:1.4; color:var(--text-main); margin-bottom:.35rem; word-break:break-word; cursor:pointer;}
.ht-summary{
  display:block; font-size:.82rem; color:var(--text-muted); line-height:1.45; margin-bottom:.55rem;
  word-break:break-word; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; overflow:hidden;
}
.ht-zh-unavailable{display:block; color:var(--warn); margin:0 0 .4rem; font-size:.82rem;}
.ht-meta{display:block; font-size:.72rem; color:var(--text-muted); border-top:1px solid rgba(243, 238, 228, 0.05); padding-top:.65rem;}
.hotspot-empty{padding:.8rem .2rem; color:var(--text-muted);}
#hook-list{
  list-style:none; margin:0 0 .75rem; padding:0 .3rem 0 0;
  display:flex; flex-direction:column; gap:.55rem;
  max-height:18rem; overflow-y:auto; overscroll-behavior:contain;
  scrollbar-width:thin; scrollbar-gutter:stable;
}
#hook-list[hidden]{display:none;}
.hook-card{
  background:var(--bg-input); border:1px solid var(--border);
  border-radius:var(--radius-md); padding:.65rem .75rem;
}
.hook-row{display:flex; align-items:flex-start; gap:.55rem;}
.hook-row input{margin:.28rem 0 0; flex:0 0 auto;}
.hook-body{min-width:0; flex:1 1 auto;}
.hook-title-row{display:flex; flex-wrap:wrap; align-items:baseline; gap:.35rem .5rem; margin-bottom:.25rem;}
.hook-phrase{font-weight:600; color:var(--text-main);}
.hook-kind{
  font-size:.68rem; color:var(--accent); font-weight:600;
  background:rgba(196, 164, 106, 0.08); border:1px solid rgba(196, 164, 106, 0.18);
  padding:.1rem .4rem; border-radius:4px;
}
.hook-priority{font-size:.68rem; color:var(--accent); font-weight:600;}
.hook-why{margin:0 0 .3rem; font-size:.78rem; color:var(--text-muted); line-height:1.4;}
.hook-results{margin:.15rem 0 0; padding:0 0 0 1.05rem; display:flex; flex-direction:column; gap:.25rem;}
.hook-results a{color:var(--accent); word-break:break-word;}
.hook-snippet{display:block; font-size:.75rem; color:var(--text-muted); line-height:1.4;}

#article-empty{color:var(--text-muted); font-size:.9rem; padding:.75rem 0; margin:0; text-align:center;}
#article-panel{min-height:0; height:auto; overflow:visible;}
#article-view{flex:0 0 auto; display:flex; flex-direction:column; min-height:0; overflow:visible;}
.article-scroll{
  flex:0 0 auto; min-height:0; overflow:visible;
  border:1px solid var(--border); border-radius:var(--radius-md);
  background:rgba(0,0,0,0.22); padding:1rem;
  display:flex; flex-direction:column; gap:.8rem;
}
.article-scroll[hidden]{display:none;}
.article-field{display:flex; flex-direction:column; gap:.5rem; margin:0; font-size:.85rem; font-weight:600; color:var(--text-muted);}
.article-field input,.article-field textarea{margin:0; font-weight:400;}
#article-body{flex:1 0 auto; min-height:260px; height:auto; overflow:hidden; resize:none; white-space:pre-wrap; word-break:break-word; line-height:1.8;}
textarea[name=style]{resize:vertical; max-height:50vh;}
.article-meta{margin:0; font-size:.8rem;}
#image-picker{
  display:flex; flex-direction:column; gap:.55rem; margin-top:.2rem;
  max-height:20.5rem; overflow:hidden;
  border:1px solid var(--border); border-radius:var(--radius-md);
  background:var(--bg-raised); padding:.7rem .75rem .65rem;
  box-shadow:inset 0 1px 0 rgba(243, 238, 228, 0.04);
}
#image-picker[hidden]{display:none;}
.image-picker-head{display:flex; justify-content:space-between; align-items:flex-start; gap:.6rem;}
.image-picker-head .panel-sub{margin:0; flex:1 1 auto;}
#image-picker-list{
  display:flex; flex-direction:column; gap:.55rem;
  flex:1 1 auto; min-height:0; max-height:16.5rem;
  overflow-y:auto; overscroll-behavior:contain;
  padding-right:.3rem; scrollbar-width:thin;
}
.image-card{
  display:grid; grid-template-columns:64px minmax(0,1fr) auto; gap:.6rem;
  align-items:center; background:rgba(0,0,0,0.22);
  border:1px solid var(--border); border-radius:var(--radius-sm); padding:.5rem;
  animation:rise var(--t-mid) var(--ease) both;
  transition:border-color var(--t-fast) var(--ease), transform var(--t-fast) var(--ease), box-shadow var(--t-fast) var(--ease);
}
.image-card:hover{transform:translateY(-1px); border-color:rgba(196, 164, 106, 0.35);}
.image-card img{
  width:64px; height:86px; object-fit:cover; aspect-ratio:3/4;
  border-radius:6px; background:#111; display:block; cursor:zoom-in;
}
.image-card .image-meta{min-width:0; font-size:.75rem; color:var(--text-muted);}
.image-card .image-url{overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
.image-card .image-actions{display:flex; flex-wrap:wrap; gap:.45rem; align-items:center;}
.image-card .image-actions button{height:28px; min-height:28px; padding:0 .55rem; font-size:.72rem;}
.image-check{
  display:inline-flex; align-items:center; gap:.28rem;
  font-size:.75rem; color:var(--text-muted); font-weight:600;
  cursor:pointer; user-select:none; white-space:nowrap;
}
.image-check input{margin:0; accent-color:var(--accent); width:1rem; height:1rem;}
.image-card.cover{border-color:var(--accent); box-shadow:0 0 0 1px var(--accent-glow);}
.article-actions{
  display:flex; justify-content:space-between; align-items:center; gap:1rem; flex-wrap:wrap;
  margin-top:.75rem; padding-top:.75rem; border-top:1px solid var(--border);
}
.article-actions .model-picker{width:min(260px, 100%);}
.article-actions > .primary,.article-actions .row > button,.article-actions .row > .model-picker{height:40px; min-height:40px; padding-top:0; padding-bottom:0;}
.article-actions input{width:min(240px, 100%);}
.article-actions button{white-space:nowrap;}
.model-picker{
  background:var(--bg-input); border:1px solid var(--border); border-radius:99px;
  padding:.5rem 1rem; color:var(--text-main); font-weight:600; font-size:.85rem;
}
#save-article-btn{
  background:transparent; border:none; color:var(--text-muted);
  font-weight:600; font-size:.9rem; padding:.5rem 1rem;
}
#save-article-btn:hover:not(:disabled){
  color:var(--text-main); background:transparent; border:none; box-shadow:none;
}
#manual-box{
  background:var(--bg-input); border:1px solid var(--border);
  border-radius:var(--radius-md); padding:1rem; margin-top:1rem;
}
.chat-section{
  border-top:1px solid var(--border); margin-top:.75rem; padding-top:.75rem;
  display:flex; flex-direction:column; gap:.75rem; flex:0 0 auto; min-height:0;
}
.chat-section.chat-active{flex:0 0 auto; overflow:visible;}
.chat-row{display:flex; align-items:flex-end; gap:.5rem; min-width:0;}
.chat-row > .model-picker,.chat-row > button{height:40px; min-height:40px; padding-top:0; padding-bottom:0;}
.chat-row .model-picker{flex:0 0 auto;}
#chat-input{
  flex:1 1 auto; min-width:0; min-height:72px; max-height:40vh;
  resize:none; overflow-y:auto; line-height:1.45;
}
#chat-send-btn{flex:0 0 auto; white-space:nowrap;}
#chat-output{
  display:flex; flex:0 0 auto; min-height:0; flex-direction:column; gap:.75rem;
  overflow:visible; overscroll-behavior:contain;
  background:rgba(0,0,0,0.25); border:1px solid var(--border);
  border-radius:var(--radius-md); padding:1rem;
}
#chat-output[hidden]{display:none;}
.chat-msg{display:flex; flex-direction:column; gap:.25rem;}
.chat-msg-user{align-items:flex-end;}
.chat-msg-assistant{align-items:flex-start;}
.chat-role{font-size:.7rem; color:var(--text-muted); font-weight:600;}
.chat-content{
  background:transparent; border-top:1px solid var(--border); border-bottom:1px solid var(--border);
  border-radius:0; padding:.6rem .9rem; font-size:.9rem;
  white-space:pre-wrap; word-break:break-word; max-width:85%;
}
.chat-msg-error .chat-content{color:var(--err);}
.chat-pending{color:var(--text-muted); font-size:.8rem; font-style:italic;}
.muted{color:var(--text-muted); font-size:12px; word-break:break-all;}
#package-path{overflow-wrap:anywhere; word-break:normal; background:rgba(0,0,0,0.3); border:1px solid var(--border); border-radius:6px; padding:4px 6px;}
[role=status]{color:var(--text-muted); font-size:.8rem;}
[role=status]:empty{display:none;}
.status-error{color:var(--err);}
.status-ok{color:var(--ok);}
[role=alert]{color:var(--err); font-size:.8rem;}
body.chat-expanded{min-height:100dvh; overflow-y:auto;}
body.chat-expanded main{flex:1 0 auto;}
body.chat-expanded .panel{height:auto; overflow:visible;}
body.chat-expanded #article-view{flex:1 0 auto;}

#config-dialog{
  background:var(--bg-card); color:var(--text-main);
  border:1px solid var(--border); border-radius:var(--radius-lg); padding:1.5rem;
  width:min(640px, calc(100% - 32px)); max-height:calc(100vh - 32px); overflow:hidden;
  box-shadow:0 25px 50px -12px rgba(0,0,0,0.8);
  animation:rise var(--t-mid) var(--ease);
}
#config-dialog::backdrop{background:rgba(12, 11, 8, 0.62); backdrop-filter:blur(4px); animation:fade var(--t-mid) var(--ease);}
#config-dialog form{display:grid; grid-template-rows:auto minmax(0, 1fr) auto; gap:1rem; max-height:calc(100vh - 66px);}
#config-dialog h2{margin:0; font-size:1.1rem; color:#e0e0e4;}
#config-dialog label{display:flex; flex-direction:column; gap:.4rem; font-size:.85rem; font-weight:600; color:var(--text-muted);}
#config-dialog fieldset{border:0; border-top:1px solid var(--border); padding:1rem 0 0; margin:0; min-width:0;}
#config-dialog legend{font-size:.85rem; font-weight:600; padding:0 6px 0 0; color:#a0a4b0;}
#config-dialog fieldset > .row{align-items:flex-end; flex-wrap:nowrap;}
#config-dialog fieldset > .row > label{min-width:0;}
#config-dialog fieldset > .row > button{flex:0 0 auto;}
.purpose-stack{display:flex; flex-direction:column; gap:1.15rem; margin:1.1rem 0 1.6rem;}
.purpose-card{
  background:var(--bg-input); border:1px solid var(--border);
  border-radius:var(--radius-md); padding:1rem 1.05rem 1.15rem;
  display:flex; flex-direction:column; gap:.85rem;
}
.purpose-card h3{margin:0; font-size:.95rem; color:var(--text-main);}
.purpose-grid{display:grid; grid-template-columns:minmax(0, 1fr) minmax(0, 1.15fr); gap:.8rem 1rem; align-items:end;}
.purpose-actions{display:flex; gap:.65rem; align-items:end; flex-wrap:wrap;}
.purpose-actions button{height:40px; min-width:7rem; white-space:nowrap;}
.model-role-row{
  display:grid; grid-template-columns:minmax(0, 1fr) 7.5rem auto;
  align-items:end; gap:.65rem; margin-top:.7rem;
}
.model-role-row.simple{grid-template-columns:minmax(0, 1fr) auto;}
.model-role-row button{height:40px; min-width:7rem; white-space:nowrap;}
.provider-section{margin-top:.4rem; display:flex; flex-direction:column; gap:.9rem;}
#provider-list,#endpoint-list{list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:.85rem;}
.provider-row,.endpoint-card{background:var(--bg-input); border:1px solid var(--border); border-radius:var(--radius-sm); padding:.95rem 1rem;}
.provider-row{display:flex; flex-wrap:wrap; align-items:center; gap:.75rem 1rem;}
.provider-row.active{border-color:var(--accent);}
.provider-dot{width:.55rem; height:.55rem; border-radius:50%; flex:0 0 auto; background:var(--err);}
.provider-dot.ok{background:var(--ok);}
.provider-row-body{min-width:0; flex:1 1 auto; cursor:pointer;}
.provider-row-title{font-size:.9rem; font-weight:600; word-break:break-all;}
.provider-row-meta{font-size:.72rem; color:var(--text-muted); margin-top:.2rem;}
.provider-tag{font-size:.68rem; border:1px solid var(--border); border-radius:99px; padding:.12rem .45rem; color:var(--text-muted); flex:0 0 auto;}
.provider-expand{width:100%; display:flex; flex-wrap:wrap; gap:.75rem 1rem; align-items:end; padding-top:.35rem;}
.provider-expand label{flex:1 1 14rem; min-width:0;}
#provider-editor{background:var(--bg-raised); border:1px solid var(--border); border-radius:var(--radius-md); padding:1.1rem 1.15rem; display:flex; flex-direction:column; gap:1rem; margin-top:.15rem;}
#provider-editor[hidden]{display:none;}
.account-form[hidden],.account-delete[hidden]{display:none;}
.endpoint-card .endpoint-url{word-break:break-all; font-size:.85rem; margin-bottom:.5rem;}
#hours-custom{width:5.5rem;}
#schedule-at{width:auto; max-width:13rem;}
#config-dialog .row:last-child{justify-content:flex-end;}
#settings-platforms{display:flex;}
#settings-platforms button{flex:1 1 0;}
.settings-panel[hidden]{display:none;}
.dialog-content{display:flex; flex-direction:column; gap:.8rem; min-height:0; overflow-y:auto; overscroll-behavior:contain; padding-right:2px;}
#image-lightbox{
  border:0; padding:0; width:100vw; height:100vh; max-width:none; max-height:none;
  background:rgba(12, 11, 8, 0.9); color:var(--text-main);
  animation:fade var(--t-mid) var(--ease);
}
#image-lightbox::backdrop{background:rgba(12, 11, 8, 0.72);}
.original-dialog{
  border:0; padding:0; width:min(980px, calc(100vw - 32px)); height:min(88vh, 900px);
  max-width:none; max-height:none; background:var(--bg-card); color:var(--text-main);
  border-radius:var(--radius-lg); box-shadow:0 25px 60px rgba(0,0,0,.72);
}
.original-dialog::backdrop{background:rgba(12, 11, 8, .72); backdrop-filter:blur(4px);}
.original-page{height:100%; display:grid; grid-template-rows:auto auto minmax(0, 1fr);}
.original-head{display:flex; width:100%; min-width:0; align-items:center; justify-content:space-between; gap:1rem; padding:1rem 1.4rem; border-bottom:1px solid var(--border);}
.original-head h2{margin:0; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:1.15rem;}
.original-head-actions{display:flex; flex:0 0 auto; flex-wrap:nowrap; align-items:center; gap:.35rem;}
#original-translate{
  height:36px; width:max-content; flex:0 0 auto; padding:0 .65rem;
  white-space:nowrap; border-color:transparent; background:transparent;
  color:var(--accent); font-size:.82rem; font-weight:600;
}
#original-translate:hover:not(:disabled){background:var(--accent-glow); box-shadow:none;}
#original-close{
  width:36px; height:36px; flex:0 0 36px; padding:0; border-radius:50%; font-size:1.25rem;
  color:var(--text-muted); line-height:1;
}
#original-sources{padding:0 1.4rem; flex-wrap:wrap;}
#original-sources a{color:var(--accent); font-size:.8rem; word-break:break-all;}
#original-scroll{overflow:auto; padding:1rem 1.4rem 2rem;}
#original-note{margin:0 0 .8rem; font-size:.78rem; color:var(--text-muted);}
.original-section h3{margin:.25rem 0 .75rem; font-size:.86rem; color:var(--text-muted);}
#original-content,#original-translation{white-space:pre-wrap; line-height:1.75; word-break:break-word;}
#original-translation-wrap{margin-top:1.6rem; padding-top:1.25rem; border-top:1px solid var(--border);}
.lightbox-stage{
  position:relative; display:flex; flex-direction:column; align-items:center; justify-content:center;
  width:100%; height:100%; padding:1.25rem; box-sizing:border-box; gap:.75rem;
}
.lightbox-toolbar{position:absolute; top:1rem; right:1rem; display:flex; gap:.45rem; z-index:1;}
.lightbox-toolbar button{height:32px; min-height:32px; padding:0 .75rem; font-size:.78rem;}
#lightbox-image{
  max-width:min(92vw, 1100px); max-height:min(78vh, 900px);
  object-fit:contain; border-radius:8px; background:#111; cursor:zoom-out;
}
#lightbox-caption{margin:0; font-size:.8rem; color:var(--text-muted); text-align:center; word-break:break-all; max-width:min(92vw, 1100px);}

@media (max-width: 900px){
  body{padding:1rem; height:auto; min-height:100dvh; overflow-y:auto; overflow-x:hidden;}
  main{grid-template-columns:minmax(0, 1fr); height:auto; min-height:calc(100dvh - 6.1rem);}
  #hotspots-panel{height:auto; max-height:none; min-height:0; overflow:visible;}
  #hotspot-pane{height:auto; min-height:0;}
  #hotspot-list{max-height:50vh; overflow-y:auto;}
  #hotspots-panel.sources-open #hotspot-pane{height:auto; max-height:none;}
  #article-view{overflow:visible;}
  .article-scroll{max-height:none;}
  .article-actions{align-items:stretch;}
  .article-actions .model-picker,.article-actions input{width:100%; min-width:0; flex:1 1 100%;}
  .chat-section.chat-active{flex:0 0 auto; overflow:visible;}
  #chat-output{flex:0 0 auto; max-height:none;}
  .model-role-row,.model-role-row.simple{grid-template-columns:minmax(0, 1fr);}
  .model-role-row button{width:100%;}
  .chat-row{display:grid; grid-template-columns:minmax(0, 1fr) auto;}
  .chat-row .model-picker{grid-column:1 / -1; width:100%;}
  #chat-input{width:100%;}
}
body.lane-github .rank-toolbar,
body.lane-github #source-health-wrap,
body.lane-github label[for="hours-select"],
body.lane-github #hours-select,
body.lane-github #hours-custom,
body.lane-github #translate-btn,
body.lane-github #hotspot-list,
body.lane-github #article-panel .panel-header .platform-tabs,
body.lane-github #prompt-style-select,
body.lane-github #find-hooks-btn,
body.lane-github #generate-btn,
body.lane-github #article-empty,
body.lane-github #article-view,
body.lane-github #hook-list,
body.lane-skills .rank-toolbar,
body.lane-skills #source-health-wrap,
body.lane-skills label[for="hours-select"],
body.lane-skills #hours-select,
body.lane-skills #hours-custom,
body.lane-skills #collect-btn,
body.lane-skills #translate-btn,
body.lane-skills #hotspot-list,
body.lane-skills #github-list,
body.lane-skills #github-studio,
body.lane-skills #github-render-controls,
body.lane-skills #prompt-style-select,
body.lane-skills #find-hooks-btn,
body.lane-skills #generate-btn,
body.lane-skills #article-empty,
body.lane-skills #article-view,
body.lane-skills #hook-list{display:none !important;}
#github-list,#github-studio,#skill-search-row,#skill-stage-chips,#skill-list,#skills-studio{display:none;}
body.lane-github #github-list{display:flex; flex-direction:column; gap:.55rem; margin:0; padding:0; list-style:none;}
body.lane-github #github-studio{display:flex; flex-direction:column; gap:1rem; min-height:0;}
body.lane-skills #skill-search-row{display:flex; gap:.5rem; align-items:center; width:100%; margin:.35rem 0 .55rem;}
body.lane-skills #skill-search-row input{
  flex:1 1 auto; width:auto; min-width:0; height:40px;
}
body.lane-skills #skill-search-btn{
  flex:0 0 auto; min-width:4.75rem; height:40px; padding:0 1.15rem;
  white-space:nowrap; line-height:1; display:inline-flex;
  align-items:center; justify-content:center;
}
body.lane-skills #skill-stage-chips{display:flex; flex-wrap:wrap; gap:.4rem; margin:0 0 .55rem; padding:0; list-style:none;}
body.lane-skills #skill-stage-chips li{
  padding:.2rem .65rem; border-radius:99px; border:1px solid var(--border);
  font-size:.72rem; color:var(--text-muted);
}
body.lane-skills #skill-list{display:flex; flex-direction:column; gap:.55rem; margin:0; padding:0; list-style:none;}
body.lane-skills #skills-studio{display:flex; flex-direction:column; gap:1rem; min-height:0; flex:1 1 auto;}
body.lane-skills #skills-gallery{display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:.7rem; min-height:12rem;}
#skills-article{
  flex:0 0 auto; min-height:6rem; padding:.85rem 1rem 1rem;
  border:1px solid var(--border); border-radius:var(--radius-md);
  background:rgba(0,0,0,0.22);
}
#skills-article.is-empty #skills-title,
#skills-article.is-empty #skills-body{color:var(--text-muted);}
#skills-article h3{margin:0 0 .4rem; font-family:var(--display); font-size:1.35rem;}
#skills-body{white-space:pre-wrap; line-height:1.7; color:var(--text-main);}
.gh-row{
  display:grid; grid-template-columns:2rem 2.4rem minmax(0,1fr) auto; gap:.7rem;
  align-items:center; padding:.7rem .8rem; border:1px solid var(--border);
  border-radius:var(--radius-md); background:var(--bg-card);
}
.gh-row img{width:2.4rem; height:2.4rem; border-radius:10px; object-fit:cover; background:#111;}
.gh-row strong{display:block; color:var(--text-main); font-size:.92rem;}
.gh-row .gh-kind{color:var(--text-muted); font-size:.75rem; white-space:nowrap;}
.gh-stars{display:flex; flex-direction:column; align-items:flex-end; gap:.25rem; min-width:4.8rem;}
.gh-bar{width:4.6rem; height:5px; border-radius:99px; background:#2c2923; overflow:hidden;}
.gh-bar > span{display:block; height:100%; background:var(--accent); border-radius:99px;}
#github-render-controls{display:none; align-items:center; gap:.45rem; flex-wrap:wrap;}
body.lane-github #github-render-controls{display:flex;}
.gh-swatch{display:flex; align-items:center; gap:.28rem; font-size:.72rem; color:var(--text-muted);}
.gh-swatch input[type=color]{
  width:1.85rem; height:1.85rem; padding:0; border:1px solid var(--border);
  border-radius:6px; background:transparent; cursor:pointer;
}
.gh-toolbar{display:flex; gap:.65rem; flex-wrap:wrap;}
.gh-gallery{display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:.7rem;}
.gh-tile{
  position:relative; aspect-ratio:3/4; border-radius:16px; overflow:hidden;
  background:#141210; border:2px solid #2a261f; cursor:zoom-in;
}
.gh-tile.selected{border-color:var(--accent); box-shadow:0 0 0 1px var(--accent);}
.gh-tile img{width:100%; height:100%; object-fit:cover; display:block;}
.gh-tile .gh-pending{margin:0; padding:1rem; color:#9a9284; font-size:.78rem;}
.gh-check{
  position:absolute; top:.45rem; right:.45rem; z-index:2;
  width:1.6rem; height:1.6rem; min-height:1.6rem; padding:0; border-radius:99px;
  font-size:.75rem; line-height:1;
}
.gh-cover,.gh-poster{
  width:min(100%, 18rem); border-radius:22px;
  background:#141210; color:#f4efe6; padding:1.4rem 1.25rem 1.2rem;
  box-shadow:0 18px 40px rgba(0,0,0,.28); border:1px solid #2a261f;
  display:flex; flex-direction:column; gap:.7rem; overflow:hidden;
}
.gh-cover{aspect-ratio:3/4;}
.gh-poster{aspect-ratio:9/16;}
.gh-cover .gh-kicker{color:#d4a574; font-size:.78rem; letter-spacing:.16em; text-transform:uppercase;}
.gh-cover h3{margin:0; font-size:2.4rem; line-height:.95; font-weight:700;}
.gh-cover h4{margin:0; color:#d4a574; font-size:1.05rem; font-weight:500;}
.gh-cover-list{display:flex; flex-direction:column; gap:.42rem; margin-top:.4rem;}
.gh-cover-item{
  display:grid; grid-template-columns:1.2rem 1.45rem minmax(0,1fr) auto; gap:.45rem;
  align-items:center; font-size:.78rem;
}
.gh-cover-item img{width:1.45rem; height:1.45rem; border-radius:6px; object-fit:cover;}
.gh-poster .gh-logo{width:3.4rem; height:3.4rem; border-radius:14px; object-fit:cover;}
.gh-poster h3{margin:0; font-size:1.45rem;}
.gh-poster .gh-summary{margin:0; color:#c9c1b4; font-size:.88rem; line-height:1.45;}
.gh-block{background:#1c1916; border-radius:14px; padding:.7rem .8rem;}
.gh-block span{display:block; color:#d4a574; font-size:.68rem; letter-spacing:.08em; margin-bottom:.25rem;}
.gh-block p{margin:0; font-size:.82rem; line-height:1.4; color:#f4efe6;}
.gh-posters{display:flex; gap:.9rem; overflow-x:auto; padding-bottom:.4rem;}
#github-xhs-body{min-height:10rem;}
#xhs-studio[hidden]{display:none !important;}
#xhs-studio{display:flex; flex-direction:column; gap:.7rem;}
.xhs-toolbar{display:flex; gap:.65rem; flex-wrap:wrap;}
.xhs-cards{display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:.7rem;}
.xhs-paper{
  aspect-ratio:9/16; border-radius:18px; overflow:hidden;
  background:
    radial-gradient(120% 70% at 12% 0%, rgba(255,255,255,.55), transparent 46%),
    repeating-linear-gradient(180deg, rgba(92,68,38,.05) 0 1px, transparent 1px 8px),
    linear-gradient(180deg, #f7f1e4 0%, #efe4d2 100%);
  color:#3c342b; padding:.7rem .65rem .8rem;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.55), 0 10px 24px rgba(48,36,22,.12);
  border:1px solid rgba(120,96,64,.16);
  display:flex; flex-direction:column; gap:.45rem;
}
.xhs-head{display:flex; align-items:center; gap:.4rem;}
.xhs-avatar{
  width:1.35rem; height:1.35rem; border-radius:99px; flex:0 0 auto;
  background:#d7c4a8; color:#5a4c3c; font-size:.7rem; font-weight:700;
  display:flex; align-items:center; justify-content:center;
}
.xhs-id{font-size:.68rem; color:#6a5b4a; letter-spacing:.02em;}
.xhs-paper h3{margin:0; font-size:1.02rem; line-height:1.25; font-weight:700; color:#2f291f;}
.xhs-paper img{width:100%; flex:1 1 auto; min-height:0; object-fit:cover; border-radius:12px;}
.xhs-lede,.xhs-copy{margin:0; font-size:.72rem; line-height:1.55; color:#4a4034; overflow:hidden;}
@media (max-width: 900px){
  .xhs-cards{grid-template-columns:repeat(2, minmax(0,1fr));}
}
@media (max-width: 360px){
  .article-actions .model-picker{font-size:.75rem; padding:.45rem .55rem;}
}
@media (prefers-reduced-motion: reduce){
  *, *::before, *::after{animation-duration:0.01ms !important; animation-iteration-count:1 !important; transition-duration:0.01ms !important;}
}
</style>
</head>
<body>
<header>
  <div class="brand">
    <h1 class="logo">AutoPosting</h1>
    <p class="brand-kicker">本地工作台</p>
  </div>
  <span id="service-status">v1.2.2 · 本地服务</span>
  <button type="button" id="config-btn">设置</button>
  <button type="button" id="favorites-btn">收藏</button>
</header>
<aside id="favorites-drawer" hidden>
  <div class="favorites-drawer-head">
    <h2>收藏</h2>
    <button type="button" id="favorites-close">关闭</button>
  </div>
  <ul id="favorites-list" aria-label="收藏列表"></ul>
</aside>
<nav id="app-nav" aria-label="栏目与平台">
  <div class="platform-tabs" role="tablist" aria-label="候选栏">
    <button type="button" class="seg active" data-lane="hotspots" aria-selected="true">热点候选</button>
    <button type="button" class="seg" data-lane="viewpoints" aria-selected="false">观点候选</button>
    <button type="button" class="seg" data-lane="github" aria-selected="false">GitHub 周榜</button>
    <button type="button" class="seg" data-lane="skills" aria-selected="false">Skill查找器</button>
  </div>
  <div class="platform-tabs" role="group" aria-label="平台选择">
    <button type="button" id="seg-wechat" class="seg active" data-platform="wechat" aria-pressed="true">微信</button>
    <button type="button" id="seg-xhs" class="seg" data-platform="xiaohongshu" aria-pressed="false">小红书</button>
  </div>
</nav>
<aside id="wait-banner" hidden role="status" aria-live="assertive">
  <div id="wait-jobs"></div>
</aside>
<main>
  <section class="panel" id="hotspots-panel" aria-labelledby="h-hotspots">
    <div class="panel-header">
      <div>
        <h2 id="h-hotspots" class="panel-title">热点候选</h2>
        <p id="hotspot-sub" class="panel-sub">下面是话题/新闻候选。热度看独立来源数和讨论量；社区帖过阈会升温，一线说法用某某称，不是权威转载</p>
      </div>
      <div class="row">
        <label for="hours-select">时间范围</label>
        <select id="hours-select">
          <option value="4" selected>4 小时</option>
          <option value="6">6 小时</option>
          <option value="24">24 小时</option>
          <option value="72">72 小时</option>
          <option value="168">168 小时</option>
          <option value="720">720 小时</option>
          <option value="custom">自定义</option>
        </select>
        <input id="hours-custom" type="number" min="1" max="720" value="2" hidden aria-label="自定义小时数">
        <button type="button" id="collect-btn">刷新全部</button>
        <span id="github-render-controls">
          <button type="button" id="github-render-btn">生成图片</button>
          <span class="platform-tabs" role="group" aria-label="配色">
            <button type="button" class="seg active" id="gh-theme-dark" data-theme="dark">暗色</button>
            <button type="button" class="seg" id="gh-theme-light" data-theme="light">浅色</button>
          </span>
          <label class="gh-swatch">主色<input id="gh-color-main" type="color" value="#0B0D12"></label>
          <label class="gh-swatch">副色<input id="gh-color-secondary" type="color" value="#141821"></label>
          <label class="gh-swatch">强调色<input id="gh-color-accent" type="color" value="#8B7CFF"></label>
        </span>
        <button type="button" id="translate-btn">翻译标题</button>
      </div>
    </div>
    <div class="rank-toolbar">
      <div id="rank-tabs" class="platform-tabs" role="tablist" aria-label="排序方式">
        <button type="button" class="seg active" data-rank="heat" aria-selected="true">热度优先</button>
        <button type="button" class="seg" data-rank="time" aria-selected="false">时间优先</button>
      </div>
      <button type="button" id="open-original-btn" disabled>打开原文</button>
    </div>
    <div id="hotspot-pane">
      <div id="skill-search-row">
        <input id="skill-query" type="text" maxlength="200" aria-label="Skill 查找关键词">
        <button type="button" id="skill-search-btn">查找</button>
      </div>
      <ul id="skill-stage-chips" aria-label="覆盖阶段"></ul>
      <ul id="hotspot-list"></ul>
      <ul id="github-list"></ul>
      <ul id="skill-list"></ul>
      <p id="hotspot-status" role="status" aria-live="polite"></p>
    </div>
    <div id="source-health-wrap">
      <button type="button" id="source-health-toggle" aria-expanded="false" aria-controls="source-health">订阅源状态</button>
      <p id="source-health-legend" class="source-legend">这些不是新闻。抓取成功=这个订阅上次拉 RSS 没报错；「只刷这个」只重新抓这一路。</p>
      <ul id="source-health" hidden aria-label="来源健康"></ul>
    </div>
  </section>
  <section class="panel" id="article-panel" aria-labelledby="h-article">
    <h2 id="h-article" class="sr-only">文章</h2>
    <div class="panel-header">
      <div class="row">
      <select id="prompt-style-select" aria-label="生成风格" title="生成风格">
        <option value="AI专家" selected>AI专家</option>
        <option value="经验分享">经验分享</option>
      </select>
      <button type="button" id="find-hooks-btn" disabled>找切口</button>
      <button type="button" id="generate-btn" class="btn-magic" disabled>生成文章</button>
      </div>
    </div>
    <p id="article-status" role="status" aria-live="polite"></p>
    <ul id="hook-list" hidden></ul>
    <p id="article-empty">尚未生成文章</p>
    <div id="github-studio">
      <div class="gh-toolbar">
        <button type="button" id="github-select-all" disabled>全选</button>
        <button type="button" id="github-export-btn" disabled>导出选中图片</button>
        <button type="button" id="github-copy-btn" disabled>复制小红书文案</button>
      </div>
      <div id="github-gallery" class="gh-gallery"></div>
      <label class="article-field">小红书标题<input id="github-xhs-title" type="text" readonly value="本周值得关注的github ai项目前10"></label>
      <label class="article-field">小红书正文<textarea id="github-xhs-body" rows="12"></textarea></label>
      <canvas id="github-canvas" hidden></canvas>
    </div>
    <div id="skills-studio">
      <div id="skills-article">
        <h3 id="skills-title">介绍文</h3>
        <div id="skills-body">查找完成后会生成介绍文。按收录 skill 从左到右、从上到下说明。</div>
      </div>
      <div class="gh-toolbar">
        <button type="button" id="skills-render-btn">生成图片</button>
        <button type="button" id="skills-select-all" disabled>全选</button>
        <button type="button" id="skills-export-btn" disabled>导出选中图片</button>
      </div>
      <div id="skills-gallery" class="gh-gallery"></div>
    </div>
    <article id="article-view">
      <div id="article-scroll" class="article-scroll" hidden>
        <label class="article-field">标题<input id="article-title" type="text"></label>
        <div id="image-picker" hidden>
          <div class="image-picker-head">
            <p class="panel-sub">原文配图。点击预览可看大图；勾选封面和正文。默认只勾选封面，正文图需另行勾选。</p>
            <button type="button" id="image-rescan">重新扫描</button>
          </div>
          <div id="image-picker-list"></div>
          <p id="image-picker-status" role="status"></p>
        </div>
        <div id="xhs-studio" hidden>
          <div class="xhs-toolbar">
            <button type="button" id="xhs-export-btn" disabled>导出图片</button>
          </div>
          <div id="xhs-cards" class="xhs-cards"></div>
          <canvas id="xhs-canvas" hidden></canvas>
        </div>
        <label class="article-field">正文<textarea id="article-body" rows="14"></textarea></label>
        <p id="article-sources" class="article-meta muted"></p>
        <p id="draft-id" class="muted"></p>
      </div>
      <div class="article-actions" aria-label="文章操作">
        <div class="row">
          <button type="button" id="save-article-btn" disabled>保存修改</button>
          <select id="article-model" class="model-picker" aria-label="文章模型"></select>
        </div>
        <div class="row">
          <input id="schedule-at" type="datetime-local" aria-label="定时到草稿时间">
          <button type="button" id="schedule-btn" disabled>定时到草稿</button>
          <button type="button" id="publish-btn" disabled class="primary">到草稿</button>
        </div>
      </div>
      <p id="publish-status" role="status" aria-live="polite"></p>
      <div id="manual-box" hidden>
        <p>发布包已生成，仍需在官方创作中心人工提交。</p>
        <p>本地发布包：<code id="package-path"></code></p>
        <button type="button" id="creator-btn">打开官方创作中心</button>
      </div>
    </article>
    <div class="chat-section" aria-label="对话">
      <div class="chat-row">
        <select id="chat-model" class="model-picker" aria-label="对话模型"></select>
        <textarea id="chat-input" rows="3" maxlength="20000" aria-label="对话消息"></textarea>
        <button type="button" id="chat-send-btn">发送</button>
      </div>
      <div id="chat-output" hidden aria-live="polite"></div>
    </div>
  </section>
</main>

<dialog id="config-dialog" aria-labelledby="config-title">
  <form id="config-form" novalidate>
    <h2 id="config-title">设置</h2>
    <div class="dialog-content">
      <div id="settings-pages" class="row platform-tabs" role="tablist" aria-label="设置页面">
        <button type="button" class="seg active" data-settings-page="model" role="tab" aria-selected="true">模型</button>
        <button type="button" class="seg" data-settings-page="style" role="tab" aria-selected="false">写作风格</button>
        <button type="button" class="seg" data-settings-page="accounts" role="tab" aria-selected="false">账号</button>
      </div>
      <fieldset class="settings-page" data-page="model">
        <legend>模型</legend>
        <p class="muted">文章、翻译、对话、榜单、出图各自保存。先选提供方，再从下拉列表选模型。下方已保存的提供方可一键套到全部入口。</p>
        <div class="purpose-stack">
          <section class="purpose-card">
            <h3>文章模型</h3>
            <div class="purpose-grid">
              <label>提供方<select name="article_provider"></select></label>
              <label>模型<select name="model"></select></label>
            </div>
            <div class="purpose-actions">
              <label>Effort<select name="effort">
                <option value="none">none</option><option value="minimal">minimal</option>
                <option value="low">low</option><option value="medium">medium</option>
                <option value="high">high</option><option value="xhigh">xhigh</option>
                <option value="max">max</option><option value="ultra">ultra</option>
              </select></label>
              <button type="button" id="endpoint-use-article">用于文章</button>
            </div>
          </section>
          <section class="purpose-card">
            <h3>翻译模型</h3>
            <div class="purpose-grid">
              <label>提供方<select name="translation_provider"></select></label>
              <label>模型<select name="translation_model"></select></label>
            </div>
            <div class="purpose-actions">
              <button type="button" id="endpoint-use-translation">用于翻译</button>
            </div>
          </section>
          <section class="purpose-card">
            <h3>对话模型</h3>
            <div class="purpose-grid">
              <label>提供方<select name="chat_provider"></select></label>
              <label>模型<select name="chat_model"></select></label>
            </div>
            <div class="purpose-actions">
              <button type="button" id="endpoint-use-chat">用于对话</button>
            </div>
          </section>
          <section class="purpose-card">
            <h3>榜单模型</h3>
            <p class="muted">只改写周榜海报里的简介、能做什么、适合什么场景、如何实现。项目名、星标和封面模板不走模型。</p>
            <div class="purpose-grid">
              <label>提供方<select name="leaderboard_provider"></select></label>
              <label>模型<select name="leaderboard_model"></select></label>
            </div>
            <div class="purpose-actions">
              <button type="button" id="endpoint-use-leaderboard">用于榜单</button>
            </div>
          </section>
          <section class="purpose-card">
            <h3>出图模型</h3>
            <p class="muted">选好后必须点「用于出图」保存。任意已接入模型都可以，包括对话模型。周榜封面 3:4；项目卡与小红书纸卡仍为当前比例；图像模型默认仍 9:16。</p>
            <div class="purpose-grid">
              <label>提供方<select name="image_provider"></select></label>
              <label>模型<select name="image_model"></select></label>
            </div>
            <div class="purpose-actions">
              <button type="button" id="endpoint-use-image">用于出图</button>
            </div>
          </section>
        </div>
        <div class="provider-section">
          <p class="muted">已保存提供方。点开后用下拉列表选模型，可一键配置全部入口。</p>
          <ul id="provider-list"></ul>
          <ul id="endpoint-list" hidden></ul>
          <button type="button" id="provider-add">添加自定义提供方</button>
          <div id="provider-editor" hidden>
            <strong id="provider-editor-title">自定义提供方</strong>
            <label>API Key<input name="api_key" type="password" autocomplete="off"></label>
            <p id="api-key-hint" class="muted">已保存的密钥不会回显，留空表示保持原值。</p>
            <label>接口地址<input name="base_url" type="text" autocomplete="off"></label>
            <div class="purpose-actions">
              <button type="button" id="endpoint-connect">获取可用模型</button>
              <button type="button" id="provider-apply" class="primary">保存提供方</button>
              <button type="button" id="provider-cancel">取消</button>
              <button type="button" id="provider-remove">删除</button>
            </div>
          </div>
        </div>
        <p id="model-endpoint-status" role="status" aria-live="polite"></p>
      </fieldset>
      <fieldset class="settings-page" data-page="style" hidden>
        <legend>文章生成风格</legend>
        <label>风格要求<textarea name="style" rows="12"></textarea></label>
        <label>导入文本文件<input id="style-file" type="file" accept="text/plain,.txt,.md"></label>
        <p class="muted">文件仅在浏览器本地读取，保存后内容会在生成文章前传给模型。</p>
      </fieldset>
      <fieldset class="settings-page" data-page="accounts" hidden>
        <legend>账号配置</legend>
        <div id="settings-platforms" class="row platform-tabs" role="group" aria-label="账号平台">
          <button type="button" class="seg active" data-settings-platform="wechat" aria-pressed="true">微信公众号</button>
          <button type="button" class="seg" data-settings-platform="xiaohongshu" aria-pressed="false">小红书</button>
          <button type="button" class="seg" data-settings-platform="x" aria-pressed="false">X</button>
        </div>
        <div id="settings-wechat" class="settings-panel">
          <p id="wechat-status" class="muted">微信公众号 API：未配置</p>
          <div id="wechat-form" class="account-form">
            <label>App ID<input name="app_id" type="text" autocomplete="off"></label>
            <label>App Secret<input name="app_secret" type="password" autocomplete="off"></label>
            <label>默认封面 Media ID（可选）<input name="thumb_media_id" type="text" autocomplete="off"></label>
            <p class="muted">一般不用填。点「到草稿」时会把已选原文配图上传成封面；没有已选配图时才生成标题大字报；再没有才用这里的备用 ID。</p>
            <label>作者（可选）<input name="author" type="text" autocomplete="off"></label>
          </div>
          <button type="button" id="wechat-delete" class="account-delete" hidden>删除配置</button>
        </div>
        <div id="settings-xiaohongshu" class="settings-panel" hidden>
          <p id="xhs-status" class="muted">小红书：未填写账号名称</p>
          <div id="xhs-form" class="account-form">
            <label>账号名称（可选）<input name="account_name" type="text" autocomplete="off"></label>
            <label>官方创作中心<input name="creator_url" type="text" autocomplete="off"></label>
          </div>
          <button type="button" id="xhs-delete" class="account-delete" hidden>删除配置</button>
        </div>
        <div id="settings-x" class="settings-panel" hidden>
          <p id="x-status" class="muted">X 官方读取令牌：未配置</p>
          <div id="x-form" class="account-form">
            <label>Bearer Token<input name="x_bearer_token" type="password" autocomplete="off"></label>
            <p class="muted">用于读取已启用的 X 账号时间线。不爬网页。S4 讨论号可直接开；S1/S2 仍要先人工确认身份。</p>
          </div>
          <button type="button" id="x-delete" class="account-delete" hidden>删除配置</button>
        </div>
      </fieldset>
      <p id="config-error" role="alert"></p>
    </div>
    <div class="row">
      <button type="submit" id="config-save" class="primary">保存</button>
      <button type="button" id="config-cancel">关闭</button>
    </div>
  </form>
</dialog>

<dialog id="original-dialog" class="original-dialog" aria-labelledby="original-title">
  <div class="original-page">
    <div class="original-head">
      <h2 id="original-title">候选原文</h2>
      <div class="original-head-actions">
        <button type="button" id="original-translate">翻译文章</button>
        <button type="button" id="original-close" aria-label="关闭" title="关闭">×</button>
      </div>
    </div>
    <div id="original-sources" class="row"></div>
    <div id="original-scroll" role="document">
      <p id="original-note"></p>
      <section class="original-section">
        <h3>原文</h3>
        <div id="original-content"></div>
      </section>
      <section id="original-translation-wrap" class="original-section" hidden>
        <h3>中文翻译</h3>
        <div id="original-translation"></div>
      </section>
    </div>
  </div>
</dialog>

<dialog id="image-lightbox" aria-label="图片放大预览">
  <div class="lightbox-stage">
    <div class="lightbox-toolbar">
      <button type="button" id="lightbox-prev">上一张</button>
      <button type="button" id="lightbox-next">下一张</button>
      <button type="button" id="lightbox-close">关闭</button>
    </div>
    <img id="lightbox-image" alt="放大预览">
    <p id="lightbox-caption"></p>
  </div>
</dialog>

<script>
"use strict";
var state = {
  hours: 4,
  rank: "heat",
  lane: "hotspots",
  newsStyle: "AI专家",
  rankings: {heat: [], time: []},
  sources: [],
  platform: "wechat",
  item: null,
  pickedIds: {},
  favoriteIds: {},
  draft: null,
  lightboxIndex: 0,
  creatorUrl: "",
  pendingPublish: false,
  articleDirty: false,
  settingsPlatform: "wechat",
  settingsPage: "model",
  style: "",
  xiaohongshu: {
    accountName: "",
    creatorUrl: "https://creator.xiaohongshu.com/publish/publish",
  },
  llm: {model: "", base_url: "", effort: "none", configured: false},
  translation: {model: "", base_url: "", configured: false, enabled: false},
  chat: {model: "", base_url: "", configured: false},
  leaderboard: {model: "", base_url: "", configured: false, enabled: false},
  image: {model: "", base_url: "", configured: false, enabled: false},
  githubWeekly: {repos: [], xhs_title: "本周值得关注的github ai项目前10", xhs_body: ""},
  githubTheme: "dark",
  skillsPackage: {query: "", title: "", theme: "", stages: [], skills: [], article: {title: "", body: ""}, images: []},
  modelEndpoints: [],
  platforms: {wechat: {configured: false}, xiaohongshu: {account_configured: false}, x: {configured: false}},
  providerDraft: {open: false, mode: "add", endpointId: "", models: []},
  chatMessages: [],
  originalGen: 0,
  originalItemId: "",
  originalTranslatable: false,
  hotspotGen: 0,
};

function $(id) { return document.getElementById(id); }

function el(tag, className, text) {
  var node = document.createElement(tag);
  if (className) { node.className = className; }
  if (text !== undefined) { node.textContent = text; }
  return node;
}

function busy(button, on) {
  if (!button) { return; }
  if (button._busyTimer) { clearInterval(button._busyTimer); button._busyTimer = null; }
  if (button.dataset.originalLabel === undefined) {
    button.dataset.originalLabel = button.textContent;
  }
  button.disabled = on;
  if (!on) {
    button.textContent = button.dataset.originalLabel;
    delete button.dataset.originalLabel;
    return;
  }
  var started = Date.now();
  function tick() {
    var s = Math.max(0, Math.floor((Date.now() - started) / 1000));
    button.textContent = "处理中…" + (s ? " " + s + "s" : "");
  }
  tick();
  button._busyTimer = setInterval(tick, 1000);
}

function status(id, text, kind) {
  var node = $(id);
  node.textContent = text;
  node.className = kind ? "status-" + kind : "";
}

var WAIT_HINTS = {
  collect: {title: "正在抓取订阅源", hint: "通常 10–30 秒，源越多越久"},
  collect_one: {title: "正在刷新这一路订阅", hint: "通常几秒到十几秒"},
  viewpoints: {title: "正在抓取 Reddit 热帖", hint: "通常 10–30 秒"},
  translate: {title: "正在翻译标题", hint: "通常 5–20 秒，看条数和模型"},
  github_fetch: {title: "正在抓取 GitHub 周榜", hint: "通常 5–20 秒；配了榜单模型会再改写简介"},
  github_render: {title: "正在生成周榜图片", hint: "每张大约 8–25 秒；11 张大约 2–5 分钟", unit: "张"},
  generate: {title: "正在生成文章", hint: "通常 15–90 秒，看模型和篇幅"},
  hooks: {title: "正在找切口", hint: "通常 10–40 秒"},
  original: {title: "正在读取原文", hint: "通常几秒"},
  original_tr: {title: "正在翻译原文", hint: "通常 10–40 秒"},
  chat: {title: "助手思考中", hint: "通常 5–30 秒"},
  models: {title: "正在获取可用模型", hint: "通常几秒到十几秒"},
  publish: {title: "正在写入草稿", hint: "通常 5–20 秒", unit: "步"},
  schedule: {title: "正在预约发布", hint: "通常几秒"},
  rescan: {title: "正在扫描配图", hint: "通常几秒到十几秒"},
  export: {title: "正在导出图片", hint: "按张下载，通常几秒"},
  save: {title: "正在保存", hint: "通常一两秒"},
  assign: {title: "正在保存模型配置", hint: "通常一两秒"},
  skill_search: {title: "正在查找 Skill", hint: "通常 20–60 秒；超时会先交已找到的结果"},
  skill_render: {title: "正在生成技能包图片", hint: "封面大字报加项目卡，大约半分钟到几分钟", unit: "张"}
};
var waitJobs = {};
var waitState = {timer: null};

function formatElapsed(ms) {
  var s = Math.max(0, Math.floor(ms / 1000));
  var m = Math.floor(s / 60);
  s = s % 60;
  return m ? (m + " 分 " + s + " 秒") : (s + " 秒");
}

function abortController() {
  if (typeof AbortController === "function") { return new AbortController(); }
  return {signal: undefined, abort: function () {}};
}

function waitRunning(kind) {
  return !!(waitJobs[kind] && waitJobs[kind].status === "running");
}

function waitCancelled(kind) {
  return !!(waitJobs[kind] && waitJobs[kind].cancelled);
}

function waitSignal(kind) {
  var job = waitJobs[kind];
  return job && job.abort ? job.abort.signal : undefined;
}

function isWaitAbort(error, kind) {
  if (waitCancelled(kind)) { return true; }
  return !!(error && (error.name === "AbortError" || error.code === 20));
}

function resolveWaitJob(kind) {
  if (kind && waitJobs[kind]) { return waitJobs[kind]; }
  var running = [];
  Object.keys(waitJobs).forEach(function (key) {
    if (waitJobs[key].status === "running") { running.push(waitJobs[key]); }
  });
  return running.length === 1 ? running[0] : null;
}

function waitStart(kind, opts) {
  opts = opts || {};
  var spec = WAIT_HINTS[kind] || {title: "处理中", hint: "请稍候"};
  if (waitRunning(kind)) { return waitJobs[kind]; }
  waitJobs[kind] = {
    kind: kind,
    status: "running",
    started: Date.now(),
    current: opts.current || 0,
    total: opts.total || 0,
    step: opts.step || "",
    unit: opts.unit || spec.unit || "步",
    title: opts.title || spec.title,
    hint: spec.hint,
    cancelled: false,
    abort: abortController()
  };
  paintWait();
  if (!waitState.timer) { waitState.timer = setInterval(paintWait, 250); }
  return waitJobs[kind];
}

function waitProgress(current, total, step, kind) {
  var job = resolveWaitJob(kind);
  if (!job || job.status !== "running") { return; }
  job.current = current;
  if (total) { job.total = total; }
  job.step = step || "";
  paintWait();
}

function waitDone(message, kind) {
  var job = resolveWaitJob(kind);
  if (!job) { return; }
  job.status = "done";
  job.title = message || "全部完成";
  job.finished = Date.now();
  paintWait();
  scheduleWaitHide(job.kind);
}

function waitFail(message, kind) {
  var job = resolveWaitJob(kind);
  if (!job) { return; }
  job.status = "error";
  job.title = job.cancelled ? "已停止" : "没有完成";
  job.hint = message || "请求失败";
  job.finished = Date.now();
  paintWait();
  scheduleWaitHide(job.kind);
}

function waitStop(kind) {
  var job = waitJobs[kind];
  if (!job || job.status !== "running") { return; }
  job.cancelled = true;
  try { job.abort.abort(); } catch (err) {}
  waitFail("已停止", kind);
}

function scheduleWaitHide(kind) {
  window.setTimeout(function () {
    var job = waitJobs[kind];
    if (!job || job.status === "running") { return; }
    delete waitJobs[kind];
    paintWait();
  }, 2400);
}

function paintWait() {
  var banner = $("wait-banner");
  var dock = $("wait-jobs");
  if (!banner || !dock) { return; }
  var kinds = Object.keys(waitJobs);
  if (!kinds.length) {
    banner.hidden = true;
    if (waitState.timer) { clearInterval(waitState.timer); waitState.timer = null; }
    return;
  }
  banner.hidden = false;
  kinds.forEach(function (kind) {
    var job = waitJobs[kind];
    var card = dock.querySelector('[data-kind="' + kind + '"]');
    if (!card) {
      card = el("article", "wait-job");
      card.setAttribute("data-kind", kind);
      card.innerHTML = '<div class="wait-spinner" aria-hidden="true"></div>'
        + '<div class="wait-copy"><p class="wait-title"></p><p class="wait-detail"></p></div>'
        + '<p class="wait-time"></p>'
        + '<button type="button" class="wait-stop">停止</button>';
      card.querySelector(".wait-stop").addEventListener("click", function () { waitStop(kind); });
      dock.appendChild(card);
    }
    card.className = "wait-job" + (job.status === "done" ? " is-done" : "") + (job.status === "error" ? " is-error" : "");
    card.querySelector(".wait-title").textContent = job.title;
    var detail = job.hint;
    if (job.status === "running" && kind === "skill_search") {
      var progress = (state.skillsPackage && state.skillsPackage.progress) || {};
      if (progress.step_index || progress.label) {
        detail = "第 " + (progress.step_index || 1) + "/" + (progress.step_total || 7) + " 步 · " + (progress.label || "查找中") + " · " + (progress.detail || job.hint);
      } else {
        detail = "查找中";
      }
    } else if (job.status === "running" && job.total) {
      var current = Math.min(job.current, job.total);
      detail = "第 " + current + " / " + job.total + " " + (job.unit || "步") + (job.step ? " · " + job.step : "") + " · " + job.hint;
    } else if (job.status === "done") {
      detail = "共用 " + formatElapsed((job.finished || Date.now()) - job.started);
    }
    card.querySelector(".wait-detail").textContent = detail;
    card.querySelector(".wait-time").textContent = job.status === "done" ? "" : ("已用 " + formatElapsed(Date.now() - job.started));
    card.querySelector(".wait-stop").hidden = job.status !== "running";
  });
  Array.prototype.slice.call(dock.children).forEach(function (card) {
    if (!waitJobs[card.getAttribute("data-kind")]) { card.remove(); }
  });
}

function formatTime(iso) {
  var date = new Date(iso);
  if (isNaN(date.getTime())) { return iso || ""; }
  return date.toLocaleString();
}

function api(path, payload, opts) {
  opts = opts || {};
  var method = (opts.method || "POST").toUpperCase();
  var init = {
    method: method,
    headers: {},
    signal: opts.signal
  };
  if (method !== "GET") {
    init.headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(payload || {});
  }
  return fetch(path, init).then(function (response) {
    return response.json().catch(function () { return {}; }).then(function (data) {
      if (!response.ok || data.ok === false) {
        var error = new Error(data.error_reason || data.error || ("HTTP " + response.status));
        error.apiError = true;
        error.code = data.error_code || data.error || ("HTTP " + response.status);
        error.reason = data.error_reason || data.error || ("HTTP " + response.status);
        throw error;
      }
      return data;
    });
  }).catch(function (error) {
    if (error && error.name === "AbortError") { throw error; }
    if (error instanceof TypeError && !error.apiError) { throw new Error("网络错误"); }
    throw error;
  });
}

function waitApi(kind, path, payload) {
  return api(path, payload, {signal: waitSignal(kind)});
}

function sourceStatusLabel(status) {
  return {
    ok: "抓取成功",
    error: "抓取失败",
    stale: "该刷新了",
    never: "还没抓过",
    disabled: "已停用"
  }[status] || status;
}

function renderSourceHealth(sources) {
  state.sources = sources || [];
  var list = $("source-health");
  if (!list) { return; }
  list.textContent = "";
  var counts = {ok: 0, error: 0, stale: 0, never: 0, disabled: 0};
  state.sources.forEach(function (source) {
    var statusKey = source.status || "never";
    counts[statusKey] = (counts[statusKey] || 0) + 1;
    var row = el("li", "source-health");
    var dot = el("span", "sh-dot " + statusKey);
    row.appendChild(dot);
    row.appendChild(el("span", "sh-name", source.name || source.source_id));
    var detail = sourceStatusLabel(statusKey);
    if (statusKey === "error" && source.last_error) {
      detail = "抓取失败：" + String(source.last_error).slice(0, 36);
    } else if (source.last_fetched_at) {
      detail += " · " + formatTime(source.last_fetched_at);
    }
    var meta = el("span", "sh-meta", detail);
    meta.title = detail;
    row.appendChild(meta);
    if (source.enabled) {
      var button = el("button", "", "只刷这个");
      button.type = "button";
      button.title = "只重新抓取这一路订阅，不是打开新闻";
      button.setAttribute("data-source-id", source.source_id);
      button.addEventListener("click", function () { collect(source.source_id); });
      row.appendChild(button);
    }
    list.appendChild(row);
  });
  var bits = [];
  if (counts.ok) { bits.push(counts.ok + " 路抓取成功"); }
  if (counts.error) { bits.push(counts.error + " 路失败"); }
  if (counts.stale) { bits.push(counts.stale + " 路该刷新"); }
  if (counts.never) { bits.push(counts.never + " 路还没抓过"); }
  if (counts.disabled) { bits.push(counts.disabled + " 路停用"); }
  var toggle = $("source-health-toggle");
  if (toggle) {
    var open = toggle.getAttribute("aria-expanded") === "true";
    toggle.textContent = (bits.length ? bits.join(" · ") : "暂无订阅源") + (open ? " · 收起" : " · 点开看来源");
  }
}

function setRank(rank) {
  state.rank = rank === "time" ? "time" : "heat";
  document.querySelectorAll("[data-rank]").forEach(function (tab) {
    var active = tab.dataset.rank === state.rank;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
  });
  renderHotspots(state.rankings[state.rank] || []);
}

function renderHotspots(items) {
  var list = $("hotspot-list");
  var selectedId = state.item ? state.item.item_id : "";
  var selectedItem = null;
  list.textContent = "";
  if (!items.length) {
    if (selectedId) { clearHotspotSelection(); }
    var empty = el("li", "hotspot-empty");
    empty.appendChild(el("p", "ht-title", "当前时间范围内没有话题或新闻"));
    empty.appendChild(el("p", "ht-summary", "可以拉长上方时间范围，或点「刷新全部」去各订阅源重新抓取。底部「抓取成功 / 只刷这个」只表示订阅健康，不是新闻标题。"));
    list.appendChild(empty);
    scheduleFitHotspotList();
    return;
  }
  items.forEach(function (item, index) {
    var button = el("button", "hotspot-item");
    var selected = item.item_id === selectedId;
    if (selected) { selectedItem = item; }
    button.type = "button";
    button.setAttribute("data-item-id", item.item_id);
    button.setAttribute("aria-pressed", String(selected));
    button.classList.toggle("selected", selected);
    button.classList.toggle("is-picked", !!state.pickedIds[item.item_id]);
    button.appendChild(el("span", "idx", (index + 1) + "."));
    button.appendChild(el("span", "ht-label", "原文"));
    var title = el("span", "ht-title", item.title);
    title.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      togglePicked(item.item_id);
    });
    button.appendChild(title);
    button.appendChild(el("span", "ht-summary", item.summary));
    var originalCjk = /[\u3400-\u9fff]/.test(String(item.title || ""));
    if (!originalCjk) {
      button.appendChild(el("span", "ht-label", "中文（AI翻译，非官方表述）"));
      if (item.title_zh || item.summary_zh) {
        button.appendChild(el("span", "ht-title", item.title_zh));
        button.appendChild(el("span", "ht-summary", item.summary_zh));
      } else {
        var unavailable = state.translation.enabled ? "未翻译，可点上方「翻译标题」" : "未翻译（未配置翻译模型）";
        if (item.translation_error_reason || item.translation_error_code) {
          unavailable += "（" + (item.translation_error_reason || item.translation_error_code);
          if (item.translation_error_reason && item.translation_error_code) {
            unavailable += "；错误码：" + item.translation_error_code;
          }
          unavailable += "）";
        }
        button.appendChild(el("span", "ht-zh-unavailable", unavailable));
      }
    }
    var sourceCount = item.source_count || (item.source_ids || []).length;
    var meta = formatTime(item.observed_at) + " · " + sourceCount + " 个来源";
    if (item.effective_tier) {
      meta += " · " + (item.promoted ? (item.base_tier + "→" + item.effective_tier) : item.effective_tier);
    }
    var heat = item.engagement || {};
    var heatBits = [];
    if (heat.score) { heatBits.push("分 " + heat.score); }
    if (heat.comments) { heatBits.push("评 " + heat.comments); }
    if (heat.likes) { heatBits.push("赞 " + heat.likes); }
    if (heat.reposts) { heatBits.push("转 " + heat.reposts); }
    if (heatBits.length) { meta += " · " + heatBits.join(" "); }
    if (item.discussion) { meta += " · 讨论观察"; }
    button.appendChild(el("span", "ht-meta", meta));
    button.addEventListener("click", function () { selectHotspot(item, button); });
    var li = document.createElement("li");
    li.className = "hotspot-row";
    li.appendChild(button);
    li.appendChild(starButton(item));
    list.appendChild(li);
  });
  if (selectedItem) {
    state.item = selectedItem;
  } else if (selectedId) {
    clearHotspotSelection();
  }
  scheduleFitHotspotList();
}

function scheduleFitHotspotList() {
  window.requestAnimationFrame(function () {
    window.requestAnimationFrame(fitHotspotList);
  });
  window.setTimeout(fitHotspotList, 60);
}

function fitHotspotList() {
  var list = $("hotspot-list");
  if (!list) { return; }
  var items = list.children;
  if (!items.length) {
    list.style.height = "";
    return;
  }
  var count = Math.min(2, items.length);
  var first = items[0];
  var last = items[count - 1];
  var height = last.offsetTop + last.offsetHeight - first.offsetTop;
  var cap = window.matchMedia("(max-width: 900px)").matches
    ? Math.round(window.innerHeight * 0.5)
    : Infinity;
  if (height > 0) {
    var next = Math.ceil(Math.min(height, cap)) + "px";
    list.style.height = next;
    list.style.maxHeight = next;
  }
}

function publishButtonLabel() {
  return state.platform === "wechat" ? "到草稿" : "发布";
}

function scheduleButtonLabel() {
  return state.platform === "wechat" ? "定时到草稿" : "定时发布";
}

function applyPublishLabels() {
  $("publish-btn").dataset.originalLabel = publishButtonLabel();
  $("publish-btn").textContent = publishButtonLabel();
  $("schedule-btn").dataset.originalLabel = scheduleButtonLabel();
  $("schedule-btn").textContent = scheduleButtonLabel();
}

function resetArticle() {
  state.draft = null;
  state.creatorUrl = "";
  state.pendingPublish = false;
  state.articleDirty = false;
  $("article-empty").hidden = false;
  $("article-scroll").hidden = true;
  closeImageLightbox();
  $("image-picker").hidden = true;
  $("image-picker-list").textContent = "";
  $("article-title").value = "";
  $("article-body").value = "";
  $("xhs-studio").hidden = true;
  $("xhs-cards").textContent = "";
  $("xhs-export-btn").disabled = true;
  applyPublishLabels();
  $("publish-btn").disabled = true;
  $("schedule-btn").disabled = true;
  $("manual-box").hidden = true;
  $("save-article-btn").disabled = true;
  status("article-status", "");
  status("publish-status", "");
}

function normalizeBaseUrl(value) {
  return String(value || "").trim().replace(/\/+$/, "");
}

function endpointForState(settings) {
  var baseUrl = normalizeBaseUrl(settings && settings.base_url);
  return state.modelEndpoints.find(function (endpoint) {
    return normalizeBaseUrl(endpoint.base_url) === baseUrl;
  }) || null;
}

function modelChoice(endpointId, model) {
  return endpointId + "\t" + model;
}

function parseModelChoice(value) {
  var separator = String(value || "").indexOf("\t");
  if (separator < 1) { return null; }
  return {
    endpointId: value.slice(0, separator),
    model: value.slice(separator + 1),
  };
}

function endpointLabel(endpoint) {
  return endpoint.base_url + " · " + endpoint.models.length + " 个模型";
}

function renderMainModelPicker(id, settings) {
  var select = $(id);
  var currentEndpoint = endpointForState(settings);
  var currentValue = currentEndpoint && settings.model
    ? modelChoice(currentEndpoint.id, settings.model)
    : "";
  select.textContent = "";
  var hasModels = false;
  state.modelEndpoints.forEach(function (endpoint) {
    (endpoint.models || []).forEach(function (model) {
      hasModels = true;
      var option = el("option", "", model);
      option.value = modelChoice(endpoint.id, model);
      option.selected = option.value === currentValue;
      select.appendChild(option);
    });
  });
  if (!hasModels) {
    var empty = el("option", "", "未配置模型");
    empty.value = "";
    empty.disabled = true;
    empty.selected = true;
    select.appendChild(empty);
  }
  var edit = el("option", "", "编辑模型");
  edit.value = "edit";
  select.appendChild(edit);
}

function renderModelPicker() {
  renderMainModelPicker("article-model", state.llm);
}

function renderChatModelPicker() {
  renderMainModelPicker("chat-model", state.chat);
}

function fillSelect(select, items, selected, emptyLabel) {
  select.textContent = "";
  if (!items.length) {
    var empty = el("option", "", emptyLabel || "未配置");
    empty.value = "";
    empty.disabled = true;
    empty.selected = true;
    select.appendChild(empty);
    return;
  }
  items.forEach(function (item) {
    var option = el("option", "", item.label);
    option.value = item.value;
    option.selected = item.value === selected;
    select.appendChild(option);
  });
}

function providerOptions() {
  return state.modelEndpoints.map(function (endpoint) {
    return {value: endpoint.id, label: providerHost(endpoint)};
  });
}

function modelOptions(endpoint) {
  return ((endpoint && endpoint.models) || []).map(function (model) {
    return {value: model, label: model};
  });
}

function fillPurposePickers() {
  var form = $("config-form");
  if (!form) { return; }
  var pairs = [
    ["article", "article_provider", "model", state.llm],
    ["translation", "translation_provider", "translation_model", state.translation],
    ["chat", "chat_provider", "chat_model", state.chat],
    ["leaderboard", "leaderboard_provider", "leaderboard_model", state.leaderboard],
    ["image", "image_provider", "image_model", state.image],
  ];
  pairs.forEach(function (pair) {
    var providerSelect = form.elements[pair[1]];
    var modelSelect = form.elements[pair[2]];
    var settings = pair[3];
    var current = endpointForState(settings);
    fillSelect(providerSelect, providerOptions(), current ? current.id : "", "先添加提供方");
    fillSelect(
      modelSelect,
      modelOptions(current),
      pair[0] === "translation" ? (state.translation.model || state.llm.model) : (settings.model || ""),
      "先选择提供方"
    );
  });
}

function onPurposeProviderChange(purpose) {
  var form = $("config-form");
  var names = {article: "article_provider", translation: "translation_provider", chat: "chat_provider", leaderboard: "leaderboard_provider", image: "image_provider"};
  var models = {article: "model", translation: "translation_model", chat: "chat_model", leaderboard: "leaderboard_model", image: "image_model"};
  var endpoint = state.modelEndpoints.find(function (item) {
    return item.id === form.elements[names[purpose]].value;
  });
  fillSelect(form.elements[models[purpose]], modelOptions(endpoint), "", "选择模型");
}

function renderSettingsModels(purpose, models, selected) {
  var form = $("config-form");
  var names = {article: "model", translation: "translation_model", chat: "chat_model", leaderboard: "leaderboard_model", image: "image_model"};
  var select = form.elements[names[purpose]];
  fillSelect(
    select,
    (models || []).map(function (model) { return {value: model, label: model}; }),
    selected,
    "先选择提供方"
  );
}

function providerHost(endpoint) {
  try {
    return new URL(endpoint.base_url).host || endpoint.base_url;
  } catch (error) {
    return endpoint.base_url;
  }
}

function endpointPurposeTags(endpoint) {
  var tags = [];
  var article = endpointForState(state.llm);
  var translation = endpointForState(state.translation);
  var chat = endpointForState(state.chat);
  if (article && article.id === endpoint.id) { tags.push("文章"); }
  if (translation && translation.id === endpoint.id) { tags.push("翻译"); }
  if (chat && chat.id === endpoint.id) { tags.push("对话"); }
  var leaderboard = endpointForState(state.leaderboard);
  if (leaderboard && leaderboard.id === endpoint.id) { tags.push("榜单"); }
  var imageEp = endpointForState(state.image);
  if (imageEp && imageEp.id === endpoint.id) { tags.push("出图"); }
  return tags;
}

function closeProviderEditor() {
  state.providerDraft = {open: false, mode: "add", endpointId: "", models: []};
  var form = $("config-form");
  form.dataset.endpointId = "";
  form.base_url.value = "";
  form.api_key.value = "";
  $("provider-editor").hidden = true;
  renderEndpointLists();
}

function openProviderEditor(mode, endpoint) {
  state.providerDraft = {
    open: true,
    mode: mode,
    endpointId: endpoint ? endpoint.id : "",
    models: endpoint ? (endpoint.models || []).slice() : [],
  };
  var form = $("config-form");
  form.dataset.endpointId = state.providerDraft.endpointId;
  form.base_url.value = endpoint ? endpoint.base_url : "";
  form.api_key.value = "";
  $("api-key-hint").textContent = endpoint && endpoint.credential_available
    ? "已保存的密钥不会回显，留空表示保持原值。"
    : "输入 API Key。";
  $("provider-editor-title").textContent = endpoint ? ("编辑 " + providerHost(endpoint)) : "自定义提供方";
  $("provider-remove").hidden = !endpoint;
  $("provider-editor").hidden = false;
  renderEndpointLists();
}

function renderEndpointLists() {
  var list = $("provider-list");
  if (!list) { return; }
  list.textContent = "";
  if (!state.modelEndpoints.length) {
    list.appendChild(el("li", "muted", "还没有保存的接口。点下方添加自定义提供方。"));
    return;
  }
  state.modelEndpoints.forEach(function (endpoint) {
    var expanded = state.providerDraft.endpointId === endpoint.id && state.providerDraft.mode === "pick";
    var row = el("li", "provider-row" + (expanded ? " active" : ""));
    var dot = el("span", "provider-dot" + (endpoint.credential_available ? " ok" : ""));
    dot.title = endpoint.credential_available ? "API Key 已保存" : "缺少 API Key";
    row.appendChild(dot);
    var body = el("div", "provider-row-body");
    body.appendChild(el("div", "provider-row-title", providerHost(endpoint)));
    var tags = endpointPurposeTags(endpoint);
    body.appendChild(el("div", "provider-row-meta", endpoint.models.length + " 个模型" + (tags.length ? " · " + tags.join(" / ") : "")));
    body.addEventListener("click", function () { toggleProviderPick(endpoint); });
    row.appendChild(body);
    row.appendChild(el("span", "provider-tag", "自定义"));
    if (expanded) {
      var expand = el("div", "provider-expand");
      var label = document.createElement("label");
      label.appendChild(document.createTextNode("模型"));
      var select = document.createElement("select");
      select.id = "bulk-model";
      fillSelect(select, modelOptions(endpoint), "", "选择模型");
      label.appendChild(select);
      expand.appendChild(label);
      var applyAll = el("button", "primary", "一键配置全部入口");
      applyAll.type = "button";
      applyAll.addEventListener("click", function (event) {
        event.stopPropagation();
        bulkAssignEndpoint(endpoint.id, select.value);
      });
      var edit = el("button", "", "编辑接口");
      edit.type = "button";
      edit.addEventListener("click", function (event) {
        event.stopPropagation();
        openProviderEditor("edit", endpoint);
      });
      expand.appendChild(applyAll);
      expand.appendChild(edit);
      row.appendChild(expand);
    }
    list.appendChild(row);
  });
}

function toggleProviderPick(endpoint) {
  if (state.providerDraft.mode === "pick" && state.providerDraft.endpointId === endpoint.id) {
    closeProviderEditor();
    return;
  }
  $("provider-editor").hidden = true;
  state.providerDraft = {open: true, mode: "pick", endpointId: endpoint.id, models: endpoint.models || []};
  renderEndpointLists();
}

function connectEndpoint() {
  var form = $("config-form");
  var button = $("endpoint-connect");
  var baseUrl = form.base_url.value.trim();
  var apiKey = form.api_key.value;
  var endpointId = form.dataset.endpointId || "";
  if (!baseUrl && !endpointId) {
    status("config-error", "请先填写接口地址", "error");
    return;
  }
  busy(button, true);
  waitStart("models");
  status("config-error", "正在获取可用模型…");
  var payload = {purpose: "article", base_url: baseUrl, api_key: apiKey, persist: true};
  if (endpointId && !apiKey) { payload.endpoint_id = endpointId; }
  waitApi("models", "/api/models", payload).then(function (data) {
    applyModelResponse(data);
    form.dataset.endpointId = data.endpoint_id || endpointId || "";
    state.providerDraft.endpointId = form.dataset.endpointId;
    state.providerDraft.models = data.models || [];
    $("provider-remove").hidden = false;
    status("config-error", "已保存 " + (data.models || []).length + " 个模型到下拉列表", "ok");
    waitDone("已获取模型列表", "models");
  }).catch(function (error) {
    if (isWaitAbort(error, "models")) { return; }
    status("config-error", showApiError("获取失败：", error), "error");
    waitFail(error.message || "获取失败", "models");
  }).then(function () { busy(button, false); });
}

function applyProvider() {
  var form = $("config-form");
  var button = $("provider-apply");
  var baseUrl = form.base_url.value.trim();
  var apiKey = form.api_key.value;
  var endpointId = form.dataset.endpointId || "";
  if (!baseUrl && !endpointId) {
    status("config-error", "请先填写接口地址", "error");
    return;
  }
  busy(button, true);
  waitStart("save");
  var payload = {purpose: "article", base_url: baseUrl, api_key: apiKey, persist: true};
  if (endpointId && !apiKey) { payload.endpoint_id = endpointId; }
  if (state.providerDraft.models && state.providerDraft.models.length) {
    payload.models = state.providerDraft.models;
  }
  waitApi("save", "/api/models", payload).then(function (data) {
    applyModelResponse(data);
    form.dataset.endpointId = data.endpoint_id || endpointId || "";
    state.providerDraft.endpointId = form.dataset.endpointId;
    $("provider-remove").hidden = false;
    status("config-error", "提供方已保存", "ok");
    waitDone("提供方已保存", "save");
  }).catch(function (error) {
    if (isWaitAbort(error, "save")) { return; }
    status("config-error", showApiError("保存失败：", error), "error");
    waitFail(error.message || "保存失败", "save");
  }).then(function () { busy(button, false); });
}

function assignEndpoint(purpose) {
  var form = $("config-form");
  var providers = {article: "article_provider", translation: "translation_provider", chat: "chat_provider", leaderboard: "leaderboard_provider", image: "image_provider"};
  var names = {article: "model", translation: "translation_model", chat: "chat_model", leaderboard: "leaderboard_model", image: "image_model"};
  var paths = {article: "/api/model", translation: "/api/translation/model", chat: "/api/chat/model", leaderboard: "/api/leaderboard/model", image: "/api/image/model"};
  var buttons = {article: "endpoint-use-article", translation: "endpoint-use-translation", chat: "endpoint-use-chat", leaderboard: "endpoint-use-leaderboard", image: "endpoint-use-image"};
  var labels = {article: "文章", translation: "翻译", chat: "对话", leaderboard: "榜单", image: "出图"};
  var endpointId = form.elements[providers[purpose]].value.trim();
  var model = form.elements[names[purpose]].value.trim();
  if (!endpointId || !model) {
    status("config-error", "请先选择提供方和模型", "error");
    return;
  }
  var payload = {endpoint_id: endpointId, model: model};
  if (purpose === "article") { payload.effort = form.effort.value; }
  var button = $(buttons[purpose]);
  busy(button, true);
  waitStart("assign");
  waitApi("assign", paths[purpose], payload).then(function (data) {
    applyModelResponse(data);
    status("config-error", "已保存" + labels[purpose] + "模型", "ok");
    waitDone("已保存" + labels[purpose] + "模型", "assign");
  }).catch(function (error) {
    if (isWaitAbort(error, "assign")) { return; }
    status("config-error", showApiError("保存失败：", error), "error");
    waitFail(error.message || "保存失败", "assign");
  }).then(function () { busy(button, false); });
}

function bulkAssignEndpoint(endpointId, model) {
  if (!endpointId || !model) {
    status("model-endpoint-status", "请先在下拉列表中选择模型", "error");
    return;
  }
  var effort = $("config-form").effort.value || "none";
  status("model-endpoint-status", "正在配置全部入口…");
  waitStart("assign");
  waitApi("assign", "/api/model", {endpoint_id: endpointId, model: model, effort: effort}).then(function (data) {
    applyModelResponse(data);
    return waitApi("assign", "/api/translation/model", {endpoint_id: endpointId, model: model});
  }).then(function (data) {
    applyModelResponse(data);
    return waitApi("assign", "/api/chat/model", {endpoint_id: endpointId, model: model});
  }).then(function (data) {
    applyModelResponse(data);
    return waitApi("assign", "/api/leaderboard/model", {endpoint_id: endpointId, model: model});
  }).then(function (data) {
    applyModelResponse(data);
    status("model-endpoint-status", "已将该模型配置到文章、翻译、对话和榜单", "ok");
    waitDone("已配置全部入口", "assign");
  }).catch(function (error) {
    if (isWaitAbort(error, "assign")) { return; }
    status("model-endpoint-status", showApiError("配置失败：", error), "error");
    waitFail(error.message || "配置失败", "assign");
  });
}

function deleteEndpoint(endpointId) {
  if (!endpointId) { return; }
  if (!window.confirm("删除该接口及其 API Key？")) { return; }
  api("/api/model-endpoints/delete", {endpoint_id: endpointId}).then(function (data) {
    applyModelResponse(data);
    closeProviderEditor();
    status("model-endpoint-status", "接口已删除", "ok");
  }).catch(function (error) {
    status("model-endpoint-status", showApiError("删除失败：", error), "error");
  });
}

function selectedLLM() {
  return {model: state.llm.model, effort: state.llm.effort || "none"};
}

function applyModelResponse(data) {
  if (data.model_endpoints) { state.modelEndpoints = data.model_endpoints; }
  if (data.llm) { state.llm = data.llm; }
  if (data.translation_llm) { state.translation = data.translation_llm; }
  if (data.chat_llm) { state.chat = data.chat_llm; }
  if (data.leaderboard_llm) { state.leaderboard = data.leaderboard_llm; }
  if (data.image_llm) { state.image = data.image_llm; }
  renderModelPicker();
  renderChatModelPicker();
  fillPurposePickers();
  renderEndpointLists();
}

function activateModel(purpose, endpointId, model) {
  var payload = {endpoint_id: endpointId, model: model};
  var path = purpose === "article" ? "/api/model" : "/api/chat/model";
  if (purpose === "article") { payload.effort = "none"; }
  return api(path, payload).then(function (data) {
    applyModelResponse(data);
    status(purpose === "article" ? "article-status" : "model-endpoint-status", "模型已切换", "ok");
    return data;
  });
}

function changeMainModel(purpose, event) {
  var select = event.target;
  if (select.value === "edit") {
    select.value = "";
    setSettingsPage("model");
    openSettings(false);
    return;
  }
  var choice = parseModelChoice(select.value);
  if (!choice) { return; }
  select.disabled = true;
  activateModel(purpose, choice.endpointId, choice.model).catch(function (error) {
    status(purpose === "article" ? "article-status" : "model-endpoint-status", showApiError("切换失败：", error), "error");
    renderModelPicker();
    renderChatModelPicker();
  }).then(function () { select.disabled = false; });
}

function showApiError(prefix, error) {
  var message = error.reason || error.message;
  if (error.code) { message += "（错误码：" + error.code + "）"; }
  return prefix + message;
}

function selectHotspot(item, button) {
  state.item = item;
  resetArticle();
  clearHooks();
  var nodes = $("hotspot-list").querySelectorAll(".hotspot-item");
  nodes.forEach(function (node) {
    var active = node === button;
    node.setAttribute("aria-pressed", String(active));
    node.classList.toggle("selected", active);
  });
  $("find-hooks-btn").disabled = false;
  $("open-original-btn").disabled = false;
  syncGenerateEnabled();
}

function clearHotspotSelection() {
  state.item = null;
  resetArticle();
  clearHooks();
  closeOriginal();
  $("find-hooks-btn").disabled = true;
  $("open-original-btn").disabled = true;
  syncGenerateEnabled();
}

function pickedIdList() {
  return Object.keys(state.pickedIds || {}).filter(function (id) {
    return state.pickedIds[id];
  }).sort();
}

function syncGenerateEnabled() {
  var button = $("generate-btn");
  if (!button) { return; }
  button.disabled = !(state.item || pickedIdList().length);
}

function togglePicked(itemId) {
  if (!itemId) { return; }
  if (state.pickedIds[itemId]) {
    delete state.pickedIds[itemId];
  } else {
    state.pickedIds[itemId] = true;
  }
  syncPickedHighlights();
  syncGenerateEnabled();
}

function syncPickedHighlights() {
  document.querySelectorAll("#hotspot-list .hotspot-item, #favorites-list .fav-item").forEach(function (node) {
    var id = node.getAttribute("data-item-id");
    node.classList.toggle("is-picked", !!state.pickedIds[id]);
  });
}

function starButton(item) {
  var favorited = !!state.favoriteIds[item.item_id];
  var star = el("button", "ht-star", favorited ? "★" : "☆");
  star.type = "button";
  star.setAttribute("aria-label", "收藏");
  star.setAttribute("aria-pressed", String(favorited));
  star.addEventListener("click", function (event) {
    event.preventDefault();
    event.stopPropagation();
    toggleFavorite(item);
  });
  return star;
}

function toggleFavorite(item) {
  if (!item || !item.item_id) { return; }
  var favorited = !!state.favoriteIds[item.item_id];
  api("/api/favorites", {item_id: item.item_id}, {method: favorited ? "DELETE" : "POST"}).then(function () {
    return loadFavorites();
  }).catch(function (error) {
    status("hotspot-status", showApiError("收藏失败：", error), "error");
  });
}

function loadFavorites() {
  return fetch("/api/favorites").then(function (response) { return response.json(); }).then(function (data) {
    state.favoriteIds = {};
    (data.items || []).forEach(function (item) {
      if (item && item.item_id) { state.favoriteIds[item.item_id] = item; }
    });
    renderFavorites();
    syncStars();
    return data;
  });
}

function renderFavorites() {
  var list = $("favorites-list");
  if (!list) { return; }
  list.textContent = "";
  var items = Object.keys(state.favoriteIds).map(function (id) { return state.favoriteIds[id]; });
  items.sort(function (a, b) {
    return String(b.favorited_at || "").localeCompare(String(a.favorited_at || ""));
  });
  items.forEach(function (item) {
    var li = el("li", "fav-item");
    li.setAttribute("data-item-id", item.item_id);
    li.classList.toggle("is-picked", !!state.pickedIds[item.item_id]);
    var title = el("span", "ht-title", item.title || "");
    title.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      togglePicked(item.item_id);
    });
    li.appendChild(starButton(item));
    li.appendChild(title);
    li.appendChild(el("span", "ht-summary", item.summary || ""));
    list.appendChild(li);
  });
}

function syncStars() {
  document.querySelectorAll("#hotspot-list .hotspot-row").forEach(function (row) {
    var card = row.querySelector(".hotspot-item");
    var star = row.querySelector(".ht-star");
    if (!card || !star) { return; }
    var favorited = !!state.favoriteIds[card.getAttribute("data-item-id")];
    star.textContent = favorited ? "★" : "☆";
    star.setAttribute("aria-pressed", String(favorited));
  });
}

function toggleFavoritesDrawer(open) {
  var next = open === undefined ? !document.body.classList.contains("favorites-open") : !!open;
  document.body.classList.toggle("favorites-open", next);
  var drawer = $("favorites-drawer");
  var button = $("favorites-btn");
  if (drawer) { drawer.hidden = !next; }
  if (button) { button.setAttribute("aria-expanded", String(next)); }
  if (next) { loadFavorites(); }
}

function rankedCount(data) {
  var rankings = (data && data.rankings) || {time: (data && data.candidates) || [], heat: (data && data.candidates) || []};
  return (rankings[state.rank] || []).length;
}

function nextWiderHours(hours) {
  var presets = [4, 6, 24, 72, 168, 720];
  for (var i = 0; i < presets.length; i++) {
    if (presets[i] > hours) { return presets[i]; }
  }
  return 0;
}

function applyHotspots(data, extraStatus) {
  state.rankings = data.rankings || {time: data.candidates || [], heat: data.candidates || []};
  if (data.sources) { renderSourceHealth(data.sources); }
  setRank(state.rank);
  var shown = (state.rankings[state.rank] || []).length;
  var text = shown ? "共 " + shown + " 条候选" : "暂无候选";
  if (extraStatus) { text += extraStatus; }
  status("hotspot-status", text, shown ? "ok" : "");
}

function loadHotspots(translate, signal) {
  var gen = ++state.hotspotGen;
  var url = "/api/hotspots?hours=" + encodeURIComponent(currentHours())
    + "&lane=" + encodeURIComponent(state.lane || "hotspots");
  if (translate) { url += "&translate=1"; }
  return fetch(url, signal ? {signal: signal} : {}).then(function (response) {
    return response.json().catch(function () { return {}; }).then(function (data) {
      if (!response.ok || data.ok === false) {
        throw new Error(data.error_reason || data.error || ("HTTP " + response.status));
      }
      if (gen !== state.hotspotGen) { return null; }
      data.hotspotGen = gen;
      applyHotspots(data);
      return data;
    });
  });
}

function widenIfEmpty(data, previousHours) {
  if (!data) { return Promise.resolve(null); }
  if (rankedCount(data) > 0) { return Promise.resolve(data); }
  var wider = nextWiderHours(previousHours || currentHours());
  if (!wider) { return Promise.resolve(data); }
  var select = $("hours-select");
  if (select) {
    select.value = String(wider);
    $("hours-custom").hidden = true;
  }
  state.hours = wider;
  return loadHotspots().then(function (next) {
    if (!next || next.hotspotGen !== state.hotspotGen) { return next; }
    applyHotspots(next, " · 近 " + (previousHours || 4) + " 小时没有候选，已改看 " + wider + " 小时");
    return next;
  });
}

function translateTitles() {
  var button = $("translate-btn");
  if (!state.translation.enabled) {
    status("hotspot-status", "请先在设置中选择“用于翻译”的模型", "error");
    return;
  }
  if (waitRunning("translate")) { return; }
  if (button) { busy(button, true); }
  waitStart("translate");
  status("hotspot-status", "正在翻译当前列表标题…");
  loadHotspots(true, waitSignal("translate")).then(function (data) {
    if (waitCancelled("translate")) { return; }
    var shown = rankedCount(data || {});
    if (state.lane !== "github") {
      status("hotspot-status", shown ? "共 " + shown + " 条候选 · 已尝试翻译标题" : "暂无候选", shown ? "ok" : "");
    }
    waitDone(shown ? "标题翻译完成" : "没有可翻译的标题", "translate");
  }).catch(function (error) {
    if (isWaitAbort(error, "translate")) { return; }
    status("hotspot-status", "翻译失败：" + error.message, "error");
    waitFail(error.message || "翻译失败", "translate");
  }).then(function () {
    if (button) { busy(button, false); }
  });
}

function collect(sourceId) {
  if ((state.lane || "hotspots") === "github") {
    refreshGithubWeekly();
    return;
  }
  if (waitRunning("collect")) { return; }
  var lane = state.lane || "hotspots";
  var hours = currentHours();
  if (sourceId) {
    waitStart("collect", {title: "正在刷新这一路订阅"});
  } else if (lane === "viewpoints") {
    waitStart("collect", {title: "正在抓取 Reddit 热帖"});
  } else {
    waitStart("collect");
  }
  status("hotspot-status", sourceId ? "正在刷新该源，已有候选会留在上面…" : (lane === "viewpoints" ? "正在从 Reddit 抓取当前热帖，已有候选会留在上面…" : "正在从各订阅源抓取，已有候选会留在上面…"));
  var payload = {hours: hours, force: true, lane: lane};
  if (sourceId) { payload.source_id = sourceId; }
  waitApi("collect", "/api/collect", payload).then(function (data) {
    if (waitCancelled("collect")) { return; }
    var inserted = data.collection && data.collection.inserted ? data.collection.inserted : 0;
    var failed = data.collection && data.collection.failed ? data.collection.failed : 0;
    var extra = "";
    if (inserted) { extra += " · 新入库 " + inserted + " 条"; }
    if (failed) { extra += " · " + failed + " 个源失败"; }
    var doneText = inserted ? ("抓取完成 · 新入库 " + inserted + " 条") : "抓取完成";
    if (state.lane === lane) {
      applyHotspots(data, extra);
      if (!rankedCount(data)) {
        return widenIfEmpty(data, hours).then(function (next) {
          if (next && failed && state.lane === lane) {
            $("hotspot-status").className = "status-error";
          }
          waitDone(doneText, "collect");
        });
      }
      if (failed) { $("hotspot-status").className = "status-error"; }
    }
    waitDone(doneText, "collect");
  }).catch(function (error) {
    if (isWaitAbort(error, "collect")) { return; }
    status("hotspot-status", "抓取失败：" + error.message, "error");
    waitFail(error.message || "抓取失败", "collect");
    if (state.lane === lane) { loadHotspots(); }
  });
}

function normalizeClientAssets(raw) {
  if (raw && raw.schema === "article-assets-v2") { return raw; }
  var list = Array.isArray(raw) ? raw : [];
  var candidates = list.map(function (item) {
    return {
      id: item.id || item.url,
      url: item.url,
      source_id: item.source_id || "",
      source_url: item.source_url || item.url,
      width: item.width,
      height: item.height,
    };
  });
  return {
    schema: "article-assets-v2",
    candidates: candidates,
    cover_id: candidates[0] ? candidates[0].id : "",
    body_ids: candidates.map(function (item) { return item.id; }),
  };
}

function persistImages() {
  if (!state.draft) { return Promise.resolve(); }
  var assets = normalizeClientAssets(state.draft.assets);
  return api("/api/articles/images", {
    draft_id: state.draft.draft_id,
    cover_id: assets.cover_id || "",
    body_ids: assets.body_ids || [],
  }).then(function (data) {
    state.draft = Object.assign({}, state.draft, data);
    $("article-title").value = data.title || $("article-title").value;
    $("article-body").value = data.body || $("article-body").value;
    state.draft.assets = data.assets;
    renderImagePicker(data.assets);
    renderXhsStudio(data);
    status("image-picker-status", "配图选择已保存", "ok");
    return data;
  });
}

function changeImageSelection(mutator) {
  if (!state.draft) { return; }
  state.draft.assets = normalizeClientAssets(state.draft.assets);
  mutator(state.draft.assets);
  renderImagePicker(state.draft.assets);
  persistImages().catch(function (error) {
    status("image-picker-status", showApiError("配图保存失败：", error), "error");
  });
}

function rescanImages() {
  if (!state.draft) { return; }
  if (waitRunning("rescan")) { return; }
  var button = $("image-rescan");
  busy(button, true);
  waitStart("rescan");
  status("image-picker-status", "正在从原文扫描配图…");
  waitApi("rescan", "/api/articles/images/rescan", {draft_id: state.draft.draft_id}).then(function (data) {
    if (waitCancelled("rescan")) { return; }
    state.draft = Object.assign({}, state.draft, data);
    $("article-body").value = data.body || $("article-body").value;
    renderImagePicker(data.assets);
    renderXhsStudio(data);
    var count = (data.assets && data.assets.candidates) ? data.assets.candidates.length : 0;
    status("image-picker-status", count ? "已扫描到 " + count + " 张原图" : "原文里没有可用配图", count ? "ok" : "error");
    waitDone(count ? ("已扫描到 " + count + " 张原图") : "原文里没有可用配图", "rescan");
  }).catch(function (error) {
    if (isWaitAbort(error, "rescan")) { return; }
    status("image-picker-status", showApiError("扫描失败：", error), "error");
    waitFail(error.message || "扫描失败", "rescan");
  }).then(function () { busy(button, false); });
}

function renderImagePicker(raw) {
  var picker = $("image-picker");
  var list = $("image-picker-list");
  var assets = normalizeClientAssets(raw);
  if (state.draft) { state.draft.assets = assets; }
  list.textContent = "";
  if (!state.draft) {
    picker.hidden = true;
    return;
  }
  picker.hidden = false;
  if (!assets.candidates.length) {
    list.appendChild(el("p", "muted", "未从原文找到配图。可点重新扫描。"));
    var sourceLine = "来源：" + (state.draft.source_ids || []).join(", ");
    $("article-sources").textContent = sourceLine + " · 无配图";
    return;
  }
  var coverCount = assets.cover_id ? 1 : 0;
  var sourceLine = "来源：" + ((state.draft && state.draft.source_ids) || []).join(", ");
  $("article-sources").textContent = sourceLine + " · 封面 " + coverCount + " · 正文图 " + assets.body_ids.length + " / " + assets.candidates.length;
  assets.candidates.forEach(function (image, index) {
    var card = el("div", "image-card" + (image.id === assets.cover_id ? " cover" : ""));
    var thumb = document.createElement("img");
    thumb.alt = "点击查看大图";
    thumb.title = "点击查看大图";
    thumb.src = "/api/image-proxy?url=" + encodeURIComponent(image.url);
    thumb.addEventListener("click", function () { openImageLightbox(index); });
    card.appendChild(thumb);
    var meta = el("div", "image-meta");
    meta.appendChild(el("div", "", image.id === assets.cover_id ? "封面候选" : "正文候选"));
    var size = (image.width && image.height) ? (image.width + "×" + image.height) : "尺寸未知";
    meta.appendChild(el("div", "", size + (image.source_id ? " · " + image.source_id : "")));
    meta.appendChild(el("div", "image-url", image.url));
    card.appendChild(meta);
    var actions = el("div", "image-actions");
    var coverLabel = el("label", "image-check");
    coverLabel.innerHTML = '<input type="checkbox" class="cover-check">封面';
    var coverBox = coverLabel.querySelector("input");
    coverBox.checked = image.id === assets.cover_id;
    coverBox.addEventListener("change", function () {
      var on = coverBox.checked;
      changeImageSelection(function (next) {
        next.cover_id = on ? image.id : (next.cover_id === image.id ? "" : next.cover_id);
      });
    });
    var bodyOn = assets.body_ids.indexOf(image.id) >= 0;
    var bodyLabel = el("label", "image-check");
    bodyLabel.innerHTML = '<input type="checkbox" class="body-check">正文';
    var bodyBox = bodyLabel.querySelector("input");
    bodyBox.checked = bodyOn;
    bodyBox.addEventListener("change", function () {
      var on = bodyBox.checked;
      changeImageSelection(function (next) {
        var ids = next.body_ids.slice();
        var pos = ids.indexOf(image.id);
        if (on && pos < 0) { ids.push(image.id); }
        if (!on && pos >= 0) { ids.splice(pos, 1); }
        next.body_ids = ids;
      });
    });
    actions.appendChild(coverLabel);
    actions.appendChild(bodyLabel);
    if (bodyOn) {
      var up = el("button", "", "上移");
      up.type = "button";
      up.disabled = assets.body_ids.indexOf(image.id) === 0;
      up.addEventListener("click", function () {
        changeImageSelection(function (next) {
          var ids = next.body_ids.slice();
          var pos = ids.indexOf(image.id);
          if (pos > 0) { ids.splice(pos - 1, 0, ids.splice(pos, 1)[0]); }
          next.body_ids = ids;
        });
      });
      var down = el("button", "", "下移");
      down.type = "button";
      down.disabled = assets.body_ids.indexOf(image.id) === assets.body_ids.length - 1;
      down.addEventListener("click", function () {
        changeImageSelection(function (next) {
          var ids = next.body_ids.slice();
          var pos = ids.indexOf(image.id);
          if (pos >= 0 && pos < ids.length - 1) { ids.splice(pos + 1, 0, ids.splice(pos, 1)[0]); }
          next.body_ids = ids;
        });
      });
      actions.appendChild(up);
      actions.appendChild(down);
    }
    card.appendChild(actions);
    list.appendChild(card);
  });
}

function proxiedImage(url) {
  if (!url) { return ""; }
  if (url.charAt(0) === "/" && url.charAt(1) !== "/") { return url; }
  if (url.indexOf("/api/generated/") === 0) { return url; }
  return "/api/image-proxy?url=" + encodeURIComponent(url);
}

function currentLightboxImages() {
  var assets = normalizeClientAssets(state.draft && state.draft.assets);
  return assets.candidates || [];
}

function openImageLightbox(index) {
  var images = currentLightboxImages();
  if (!images.length) { return; }
  var total = images.length;
  state.lightboxIndex = ((index % total) + total) % total;
  var image = images[state.lightboxIndex];
  var preview = $("lightbox-image");
  preview.alt = image.credit || "放大预览";
  preview.src = proxiedImage(image.url);
  var size = (image.width && image.height) ? (image.width + "×" + image.height + " · ") : "";
  $("lightbox-caption").textContent = (state.lightboxIndex + 1) + " / " + total + " · " + size + image.url;
  $("lightbox-prev").hidden = total < 2;
  $("lightbox-next").hidden = total < 2;
  var dialog = $("image-lightbox");
  if (dialog && !dialog.open) { dialog.showModal(); }
}

function stepImageLightbox(delta) {
  openImageLightbox(state.lightboxIndex + delta);
}

function closeImageLightbox() {
  var dialog = $("image-lightbox");
  if (dialog && dialog.open) { dialog.close(); }
  var preview = $("lightbox-image");
  if (preview) { preview.removeAttribute("src"); }
}

function fitArticleBody() {
  var body = $("article-body");
  if (!body || body.closest("[hidden]")) { return; }
  body.style.height = "auto";
  var next = Math.max(260, body.scrollHeight + 2);
  body.style.height = next + "px";
}

function renderArticle(data) {
  $("article-empty").hidden = true;
  $("article-scroll").hidden = false;
  $("article-title").value = data.title || "";
  $("article-body").value = data.body || "";

  $("article-sources").textContent = "来源：" + (data.source_ids || []).join(", ");
  renderImagePicker(data.assets);
  renderXhsStudio(data);
  $("draft-id").textContent = "draft_id: " + data.draft_id;
  $("article-status").textContent = "";
  $("save-article-btn").disabled = false;
  state.articleDirty = false;
  fitArticleBody();
}

function renderXhsStudio(data) {
  var studio = $("xhs-studio");
  var cards = (data && data.cards) || [];
  var show = state.platform === "xiaohongshu" && cards.length;
  studio.hidden = !show;
  $("xhs-export-btn").disabled = !show;
  var root = $("xhs-cards");
  root.textContent = "";
  if (!show) { return; }
  cards.forEach(function (card) {
    var node = el("div", "xhs-paper xhs-" + (card.kind || "page"));
    var head = el("div", "xhs-head");
    var handle = card.handle || "@小红书号";
    var avatar = el("div", "xhs-avatar", handle.replace(/^@/, "").slice(0, 1) || "A");
    head.appendChild(avatar);
    head.appendChild(el("span", "xhs-id", handle));
    node.appendChild(head);
    if (card.kind === "cover") {
      node.appendChild(el("h3", "", card.title || ""));
      if (card.image_url) {
        var image = document.createElement("img");
        image.alt = card.title || "封面";
        image.src = proxiedImage(card.image_url);
        node.appendChild(image);
      } else if (card.lede) {
        node.appendChild(el("p", "xhs-lede", card.lede));
      }
    } else {
      node.appendChild(el("p", "xhs-copy", card.text || ""));
    }
    root.appendChild(node);
  });
}

state.hooks = [];
state.chosenHookIds = [];
state.findHooksGen = 0;

function clearHooks() {
  state.hooks = [];
  state.chosenHookIds = [];
  $("hook-list").textContent = "";
  $("hook-list").hidden = true;
}

function selectedHookCards() {
  return state.chosenHookIds.map(function (id) {
    return state.hooks.find(function (hook) { return hook.hook_id === id; });
  }).filter(Boolean);
}

function relabelHookCards() {
  $("hook-list").querySelectorAll(".hook-card").forEach(function (card) {
    var label = card.querySelector(".hook-priority");
    if (!label) { return; }
    var pos = state.chosenHookIds.indexOf(card.dataset.hookId);
    label.textContent = pos === 0 ? "主切口" : (pos > 0 ? "须进开头" : "");
  });
}

function renderHooks(hooks) {
  state.hooks = hooks || [];
  state.chosenHookIds = [];
  var list = $("hook-list");
  list.textContent = "";
  state.hooks.forEach(function (hook) {
    var card = el("li", "hook-card");
    card.dataset.hookId = hook.hook_id;
    var row = el("div", "hook-row");
    var check = document.createElement("input");
    check.type = "checkbox";
    check.addEventListener("change", function () {
      var id = hook.hook_id;
      var pos = state.chosenHookIds.indexOf(id);
      if (check.checked) {
        if (pos < 0) { state.chosenHookIds.push(id); }
      } else if (pos >= 0) {
        state.chosenHookIds.splice(pos, 1);
      }
      relabelHookCards();
    });
    row.appendChild(check);
    var body = el("div", "hook-body");
    var titleRow = el("div", "hook-title-row");
    titleRow.appendChild(el("span", "hook-phrase", hook.phrase || ""));
    titleRow.appendChild(el("span", "hook-kind", hook.kind || ""));
    titleRow.appendChild(el("span", "hook-priority", ""));
    body.appendChild(titleRow);
    if (hook.why) { body.appendChild(el("p", "hook-why", hook.why)); }
    var results = el("ul", "hook-results");
    (hook.results || []).slice(0, 3).forEach(function (result) {
      var item = document.createElement("li");
      var link = document.createElement("a");
      link.href = result.url || "";
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = result.title || result.url || "";
      item.appendChild(link);
      if (result.snippet) { item.appendChild(el("span", "hook-snippet", result.snippet)); }
      results.appendChild(item);
    });
    if (results.childNodes.length) { body.appendChild(results); }
    row.appendChild(body);
    card.appendChild(row);
    list.appendChild(card);
  });
  list.hidden = state.hooks.length === 0;
}

function findHooks() {
  if (!state.item) { return; }
  var itemId = state.item.item_id;
  var gen = ++state.findHooksGen;
  var button = $("find-hooks-btn");
  busy(button, true);
  waitStart("hooks");
  status("article-status", "正在找切口…");
  waitApi("hooks", "/api/hooks/find", {item_id: itemId}).then(function (data) {
    if (waitCancelled("hooks")) { return; }
    if (!state.item || state.item.item_id !== itemId || gen !== state.findHooksGen) { return; }
    renderHooks(data.hooks || []);
    status("article-status", (data.hooks && data.hooks.length) ? "" : (data.message || "未发现可用切口"), (data.hooks && data.hooks.length) ? "" : "error");
    waitDone((data.hooks && data.hooks.length) ? ("找到 " + data.hooks.length + " 个切口") : "未发现可用切口", "hooks");
  }).catch(function (error) {
    if (isWaitAbort(error, "hooks")) { return; }
    if (!state.item || state.item.item_id !== itemId || gen !== state.findHooksGen) { return; }
    status("article-status", showApiError("找切口失败：", error), "error");
    waitFail(error.message || "找切口失败", "hooks");
  }).then(function () {
    if (gen === state.findHooksGen) { busy(button, false); }
  });
}

function closeOriginal() {
  state.originalGen += 1;
  state.originalItemId = "";
  state.originalTranslatable = false;
  if ($("original-dialog").open) { $("original-dialog").close(); }
  busy($("open-original-btn"), false);
  $("open-original-btn").disabled = !state.item;
}

function openOriginal() {
  if (!state.item) { return; }
  var itemId = state.item.item_id;
  var gen = ++state.originalGen;
  var button = $("open-original-btn");
  state.originalItemId = itemId;
  state.originalTranslatable = false;
  $("original-title").textContent = state.item.title_zh || state.item.title || "候选原文";
  $("original-sources").textContent = "";
  $("original-note").textContent = "";
  $("original-content").textContent = "正在读取已收录的原文内容…";
  $("original-translation").textContent = "";
  $("original-translation-wrap").hidden = true;
  $("original-translate").hidden = false;
  $("original-translate").disabled = true;
  $("original-translate").textContent = "翻译文章";
  delete $("original-translate").dataset.originalLabel;
  if (!$("original-dialog").open) { $("original-dialog").showModal(); }
  busy(button, true);
  waitStart("original");
  waitApi("original", "/api/original", {item_id: itemId}).then(function (data) {
    if (waitCancelled("original")) { return; }
    if (!state.item || state.item.item_id !== itemId || gen !== state.originalGen) { return; }
    $("original-title").textContent = data.title || "候选原文";
    $("original-content").textContent = data.content || "该候选没有可显示的正文内容。";
    $("original-note").textContent = data.content_note || "";
    state.originalTranslatable = !!data.translatable;
    $("original-translate").hidden = !state.originalTranslatable;
    $("original-translate").disabled = !state.originalTranslatable;
    (data.sources || []).forEach(function (source) {
      var link = el("a", "", source.source_id || "打开原站");
      link.href = source.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.title = source.url;
      $("original-sources").appendChild(link);
    });
    waitDone("原文已打开", "original");
  }).catch(function (error) {
    if (isWaitAbort(error, "original")) { return; }
    if (gen === state.originalGen) {
      $("original-content").textContent = showApiError("读取原文失败：", error);
      waitFail(error.message || "读取原文失败", "original");
    }
  }).then(function () {
    if (gen === state.originalGen) { busy(button, false); }
  });
}

function translateOriginal() {
  if (!state.originalItemId || !state.originalTranslatable) { return; }
  var itemId = state.originalItemId;
  var gen = state.originalGen;
  var button = $("original-translate");
  var output = $("original-translation");
  $("original-translation-wrap").hidden = false;
  if (!state.translation.enabled) {
    output.textContent = "请先在设置中选择“用于翻译”的模型。";
    return;
  }
  output.textContent = "正在翻译…";
  busy(button, true);
  waitStart("original_tr");
  waitApi("original_tr", "/api/original/translate", {item_id: itemId}).then(function (data) {
    if (waitCancelled("original_tr")) { return; }
    if (gen !== state.originalGen || itemId !== state.originalItemId) { return; }
    output.textContent = data.translation || "翻译结果为空。";
    button.dataset.originalLabel = "已翻译";
    waitDone("原文翻译完成", "original_tr");
  }).catch(function (error) {
    if (isWaitAbort(error, "original_tr")) { return; }
    if (gen === state.originalGen) {
      output.textContent = showApiError("翻译失败：", error);
      waitFail(error.message || "翻译失败", "original_tr");
    }
  }).then(function () {
    if (gen === state.originalGen) { busy(button, false); }
  });
}

function generate() {
  var picked = pickedIdList();
  if (!state.item && !picked.length) { return; }
  var button = $("generate-btn");
  var llm = selectedLLM();
  if (!llm.model) {
    status("article-status", "请先在设置中填写模型", "error");
    return;
  }
  var payload = {
    platform: state.platform,
    model: llm.model,
    effort: llm.effort,
    prompt_style: $("prompt-style-select").value,
  };
  if (picked.length >= 1) {
    payload.item_ids = picked;
  } else {
    payload.item_id = state.item.item_id;
  }
  var chosen = selectedHookCards();
  if (chosen.length > 0) {
    payload.chosen_hooks = chosen;
  }
  if (waitRunning("generate")) { return; }
  busy(button, true);
  waitStart("generate");
  status("article-status", "正在生成文章…");
  waitApi("generate", "/api/articles", payload).then(function (data) {
    if (waitCancelled("generate")) { return; }
    state.draft = data;
    renderArticle(data);
    applyPublishLabels();
    $("publish-btn").disabled = false;
    $("schedule-btn").disabled = false;
    waitDone("文章已生成", "generate");
    status("article-status", "文章已生成", "ok");
  }).catch(function (error) {
    if (isWaitAbort(error, "generate")) { return; }
    status("article-status", showApiError("生成失败：", error), "error");
    waitFail(error.message || "生成失败", "generate");
  }).then(function () {
    busy(button, false);
  });
}

function persistArticle(kind) {
  if (!state.draft) { return Promise.resolve(); }
  return api("/api/articles/edit", {
    draft_id: state.draft.draft_id,
    title: $("article-title").value,
    body: $("article-body").value,
  }, kind ? {signal: waitSignal(kind)} : {}).then(function (data) {
    state.draft = Object.assign({}, state.draft, data);
    renderArticle(state.draft);
    return data;
  });
}

function saveArticle() {
  if (!state.draft) { return; }
  var button = $("save-article-btn");
  busy(button, true);
  waitStart("save");
  persistArticle("save").then(function () {
    if (waitCancelled("save")) { return; }
    $("publish-btn").disabled = false;
    $("schedule-btn").disabled = false;
    status("article-status", "修改已保存，需重新审批", "ok");
    waitDone("修改已保存", "save");
  }).catch(function (error) {
    if (isWaitAbort(error, "save")) { return; }
    status("article-status", showApiError("保存失败：", error), "error");
    waitFail(error.message || "保存失败", "save");
  }).then(function () {
    busy(button, false);
  });
}

function setPlatform(platform) {
  state.platform = platform;
  document.body.classList.toggle("platform-xhs", platform === "xiaohongshu");
  resetArticle();
  var nodes = document.querySelectorAll("button[data-platform]");
  nodes.forEach(function (node) {
    var active = node.dataset.platform === platform;
    node.setAttribute("aria-pressed", String(active));
    node.classList.toggle("active", active);
  });
}

function appendChatMessage(role, text) {
  var output = $("chat-output");
  var wrap = el("div", "chat-msg chat-msg-" + role);
  var labels = {user: "我", assistant: "助手", error: "错误"};
  wrap.appendChild(el("span", "chat-role", labels[role] || role));
  wrap.appendChild(el("div", "chat-content", text));
  output.appendChild(wrap);
  output.scrollTop = output.scrollHeight;
}

function fitChatInput() {
  var input = $("chat-input");
  input.style.height = "auto";
  input.style.height = (input.scrollHeight + 2) + "px";
}

function sendChat() {
  var input = $("chat-input");
  var button = $("chat-send-btn");
  if (button.disabled) { return; }
  var text = input.value.trim();
  if (!text) { return; }
  var output = $("chat-output");
  output.hidden = false;
  document.body.classList.add("chat-expanded");
  output.parentElement.classList.add("chat-active");
  appendChatMessage("user", text);
  input.value = "";
  fitChatInput();
  var messages = state.chatMessages.slice(-48).concat([{role: "user", content: text}]);
  if (!state.chat.configured) {
    appendChatMessage("error", "请先在设置中配置对话模型接口");
    return;
  }
  var pending = el("p", "chat-pending", "思考中…");
  output.appendChild(pending);
  output.scrollTop = output.scrollHeight;
  busy(button, true);
  waitStart("chat");
  waitApi("chat", "/api/chat", {messages: messages}).then(function (data) {
    if (waitCancelled("chat")) { return; }
    var reply = (data.message && data.message.content) || "";
    appendChatMessage("assistant", reply);
    state.chatMessages = messages.concat([{role: "assistant", content: reply}]);
    waitDone("回复已生成", "chat");
  }).catch(function (error) {
    if (isWaitAbort(error, "chat")) { return; }
    appendChatMessage("error", showApiError("对话失败：", error));
    waitFail(error.message || "对话失败", "chat");
  }).then(function () {
    pending.remove();
    busy(button, false);
    input.focus();
  });
}

function setSettingsPlatform(platform) {
  state.settingsPlatform = platform;
  document.querySelectorAll("[data-settings-platform]").forEach(function (tab) {
    var active = tab.dataset.settingsPlatform === platform;
    tab.setAttribute("aria-pressed", String(active));
    tab.classList.toggle("active", active);
  });
  $("settings-wechat").hidden = platform !== "wechat";
  $("settings-xiaohongshu").hidden = platform !== "xiaohongshu";
  $("settings-x").hidden = platform !== "x";
}

function setSettingsPage(page) {
  state.settingsPage = page;
  document.querySelectorAll("[data-settings-page]").forEach(function (tab) {
    var active = tab.dataset.settingsPage === page;
    tab.setAttribute("aria-selected", String(active));
    tab.classList.toggle("active", active);
  });
  document.querySelectorAll("[data-page]").forEach(function (panel) {
    panel.hidden = panel.dataset.page !== page;
  });
}

function renderAccountPanels() {
  var wechatOn = !!(state.platforms.wechat && state.platforms.wechat.configured);
  $("wechat-form").hidden = wechatOn;
  $("wechat-delete").hidden = !wechatOn;
  status("wechat-status", wechatOn ? "微信公众号 API：已配置" : "微信公众号 API：未配置", wechatOn ? "ok" : "");
  var xhsOn = !!(state.platforms.xiaohongshu && state.platforms.xiaohongshu.account_configured);
  $("xhs-form").hidden = xhsOn;
  $("xhs-delete").hidden = !xhsOn;
  status("xhs-status", xhsOn ? "小红书：已配置" : "小红书：未填写账号名称", xhsOn ? "ok" : "");
  var xOn = !!(state.platforms.x && state.platforms.x.configured);
  $("x-form").hidden = xOn;
  $("x-delete").hidden = !xOn;
  status("x-status", xOn ? "X 官方读取令牌：已配置" : "X 官方读取令牌：未配置", xOn ? "ok" : "");
}

function deleteAccount(platform) {
  if (!window.confirm("删除该账号配置？删除后需重新填写。")) { return; }
  api("/api/config/delete", {platform: platform}).then(function (data) {
    if (platform === "wechat") { state.platforms.wechat = {configured: false}; }
    if (platform === "x") { state.platforms.x = {configured: false}; }
    if (platform === "xiaohongshu") {
      state.xiaohongshu.accountName = "";
      state.xiaohongshu.creatorUrl = "https://creator.xiaohongshu.com/publish/publish";
    }
    renderAccountPanels();
    status("config-error", "已删除配置", "ok");
  }).catch(function (error) {
    status("config-error", showApiError("删除失败：", error), "error");
  });
}

function openSettings(pendingPublish) {
  state.pendingPublish = pendingPublish;
  var form = $("config-form");
  form.effort.value = state.llm.effort || "none";
  form.base_url.value = "";
  form.api_key.value = "";
  form.dataset.endpointId = "";
  form.elements.style.value = state.style;
  form.app_id.value = "";
  form.app_secret.value = "";
  form.thumb_media_id.value = "";
  form.author.value = "";
  form.account_name.value = "";
  form.creator_url.value = "";
  form.x_bearer_token.value = "";
  closeProviderEditor();
  fillPurposePickers();
  if (!state.modelEndpoints.length) { openProviderEditor("add", null); }
  renderAccountPanels();
  if (pendingPublish) { setSettingsPlatform("wechat"); }
  setSettingsPage(pendingPublish ? "accounts" : state.settingsPage);
  $("config-error").textContent = "";
  if (!$("config-dialog").open) { $("config-dialog").showModal(); }
}

function currentHours() {
  if ($("hours-select").value === "custom") {
    return parseInt($("hours-custom").value, 10);
  }
  return parseInt($("hours-select").value, 10) || 4;
}

function schedulePublish() {
  var draft = state.draft;
  if (!draft) { return; }
  var when = $("schedule-at").value;
  if (!when) {
    status("publish-status", "请选择定时发布时间", "error");
    return;
  }
  var button = $("schedule-btn");
  busy(button, true);
  waitStart("schedule");
  (state.articleDirty ? persistArticle("schedule") : Promise.resolve()).then(function () {
    return persistImages();
  }).then(function () {
    if (waitCancelled("schedule")) { return; }
    draft = state.draft;
    return waitApi("schedule", "/api/approve", {draft_id: draft.draft_id, reviewer: "web-user"});
  }).then(function () {
    if (waitCancelled("schedule")) { return; }
    return waitApi("schedule", "/api/schedule", {
      draft_id: draft.draft_id,
      platform: state.platform,
      live: true,
      run_at: when,
    });
  }).then(function (result) {
    if (waitCancelled("schedule") || !result) { return; }
    status("publish-status", "已预约 " + (result.run_at || when), "ok");
    waitDone("已预约发布", "schedule");
  }).catch(function (error) {
    if (isWaitAbort(error, "schedule")) { return; }
    if (error.code === "wechat_configuration_required") {
      status("publish-status", "请先配置微信", "error");
      waitFail("请先配置微信", "schedule");
      openSettings(true);
      return;
    }
    status("publish-status", showApiError("定时失败：", error), "error");
    waitFail(error.message || "定时失败", "schedule");
  }).then(function () { busy(button, false); });
}

function publish() {
  var draft = state.draft;
  if (!draft) { return; }
  var button = $("publish-btn");
  var completed = false;
  busy(button, true);
  $("manual-box").hidden = true;
  waitStart("publish", {current: 1, total: 3, step: "保存文章"});
  status("publish-status", "保存文章…");
  (state.articleDirty ? persistArticle("publish") : Promise.resolve()).then(function () {
    return persistImages();
  }).then(function () {
    if (waitCancelled("publish")) { return; }
    draft = state.draft;
    waitProgress(2, 3, "提交审批", "publish");
    status("publish-status", "提交审批…");
    return waitApi("publish", "/api/approve", {draft_id: draft.draft_id, reviewer: "web-user"});
  }).then(function () {
    if (waitCancelled("publish")) { return; }
    waitProgress(3, 3, state.platform === "wechat" ? "写入草稿箱" : "发布", "publish");
    status("publish-status", state.platform === "wechat" ? "已审批，正在写入草稿箱…" : "已审批，正在发布…");
    return waitApi("publish", "/api/publish", {draft_id: draft.draft_id, platform: state.platform, live: true});
  }).then(function (result) {
    if (waitCancelled("publish") || !result) { return; }
    if (result.manual_required) {
      state.creatorUrl = result.creator_url || "";
      $("package-path").textContent = result.package_path || "";
      $("manual-box").hidden = false;
      status("publish-status", "发布包已生成", "ok");
      waitDone("发布包已生成", "publish");
    } else {
      status("publish-status", "已写入公众号草稿箱：" + (result.reference || result.status), "ok");
      waitDone("已写入公众号草稿箱", "publish");
    }
    completed = true;
    button.dataset.originalLabel = result.manual_required ? "已生成发布包" : "已到草稿";
  }).catch(function (error) {
    if (isWaitAbort(error, "publish")) { return; }
    if (error.code === "wechat_configuration_required") {
      status("publish-status", "请先配置微信", "error");
      waitFail("请先配置微信", "publish");
      openSettings(true);
    } else {
      status("publish-status", (state.platform === "wechat" ? "写入草稿失败：" : "发布失败：") + error.message, "error");
      waitFail(error.message || "发布失败", "publish");
    }
  }).then(function () {
    busy(button, false);
    if (completed) { button.disabled = true; }
  });
}

window.addEventListener("resize", function () { fitHotspotList(); });
$("hours-select").addEventListener("change", function (event) {
  var custom = event.target.value === "custom";
  $("hours-custom").hidden = !custom;
  state.hours = currentHours();
  loadHotspots();
});
$("hours-custom").addEventListener("change", function () {
  state.hours = currentHours();
  loadHotspots();
});
$("collect-btn").addEventListener("click", function () { collect(); });
$("translate-btn").addEventListener("click", function () { translateTitles(); });
function setSourcesOpen(open) {
  var list = $("source-health");
  var panel = $("hotspots-panel");
  var toggle = $("source-health-toggle");
  if (list) { list.hidden = !open; }
  if (panel) { panel.classList.toggle("sources-open", !!open); }
  if (toggle) { toggle.setAttribute("aria-expanded", String(!!open)); }
  renderSourceHealth(state.sources);
}

$("source-health-toggle").addEventListener("click", function () {
  setSourcesOpen($("source-health").hidden);
});
document.querySelectorAll("[data-rank]").forEach(function (tab) {
  tab.addEventListener("click", function () { setRank(tab.dataset.rank); });
});
function githubIcon(url) {
  return "/api/image-proxy?url=" + encodeURIComponent(url || "");
}
function renderGithubWeekly(payload) {
  state.githubWeekly = payload || state.githubWeekly;
  var repos = state.githubWeekly.repos || [];
  var list = $("github-list");
  list.textContent = "";
  repos.forEach(function (repo) {
    var row = el("li", "gh-row");
    row.appendChild(el("span", "muted", String(repo.rank)));
    var img = document.createElement("img");
    img.src = githubIcon(repo.icon_url);
    img.alt = repo.name;
    row.appendChild(img);
    var meta = document.createElement("div");
    meta.appendChild(el("strong", "", repo.name));
    meta.appendChild(el("span", "gh-kind", (repo.kind || repo.language || "AI 工具") + (repo.fresh ? " · 本周新建" : " · 本周涨星")));
    row.appendChild(meta);
    var stars = el("div", "gh-stars");
    var bar = el("div", "gh-bar");
    var fill = document.createElement("span");
    fill.style.width = Math.max(8, Math.round((repo.star_share || 0) * 100)) + "%";
    bar.appendChild(fill);
    stars.appendChild(bar);
    stars.appendChild(el("span", "", repo.stars_label || String(repo.stars || 0)));
    row.appendChild(stars);
    list.appendChild(row);
  });
  renderGithubGallery();
  $("github-xhs-title").value = state.githubWeekly.xhs_title || "本周值得关注的github ai项目前10";
  $("github-xhs-body").value = state.githubWeekly.xhs_body || "";
  var images = githubImages();
  $("github-export-btn").disabled = !images.filter(function (image) { return image.selected !== false && image.url; }).length;
  $("github-copy-btn").disabled = !repos.length;
  $("github-select-all").disabled = !images.length;
}
function githubFreshUrl(url) {
  if (!url) { return ""; }
  var stamp = state.githubImageBust;
  if (!stamp) { return url; }
  return url + (url.indexOf("?") >= 0 ? "&" : "?") + "t=" + stamp;
}
function githubImages() {
  return (state.githubWeekly && state.githubWeekly.images) || [];
}
function renderGithubGallery() {
  var gallery = $("github-gallery");
  gallery.textContent = "";
  githubImages().forEach(function (image, index) {
    var extras = "";
    if (image.busy) { extras += " is-running"; }
    else if (image.queued) { extras += " is-queued"; }
    if (image.error) { extras += " is-error"; }
    if (image.selected !== false) { extras += " selected"; }
    var tile = el("div", "gh-tile" + extras);
    tile.dataset.imageId = image.id;
    var check = document.createElement("button");
    check.type = "button";
    check.className = "gh-check";
    check.textContent = image.selected === false ? "" : "✓";
    check.addEventListener("click", function (event) {
      event.stopPropagation();
      toggleGithubImage(image.id);
    });
    tile.appendChild(check);
    if (image.url) {
      var img = document.createElement("img");
      img.alt = image.title || image.id;
      img.src = githubFreshUrl(image.url);
      img.addEventListener("click", function () { openGithubLightbox(index); });
      tile.appendChild(img);
    }
    if (image.busy) {
      tile.appendChild(el("p", "gh-pending gh-overlay", "正在生成…"));
    } else if (image.queued) {
      tile.appendChild(el("p", "gh-pending gh-overlay", "排队中"));
    } else if (image.error) {
      tile.appendChild(el("p", "gh-pending gh-overlay", "失败 · " + image.error));
    } else if (!image.url) {
      tile.appendChild(el("p", "gh-pending", "待出图 · " + (image.title || image.id)));
    }
    gallery.appendChild(tile);
  });
}
function toggleGithubImage(imageId) {
  githubImages().forEach(function (image) {
    if (image.id === imageId) {
      image.selected = image.selected === false;
    }
  });
  renderGithubWeekly(state.githubWeekly);
}
function selectAllGithubImages() {
  var images = githubImages();
  var allOn = images.length && images.every(function (image) { return image.selected !== false; });
  images.forEach(function (image) { image.selected = !allOn; });
  renderGithubWeekly(state.githubWeekly);
}
function openGithubLightbox(index) {
  var images = githubImages().filter(function (image) { return image.url; });
  if (!images.length) { return; }
  state.draft = state.draft || {assets: {candidates: []}};
  state.draft.assets = {
    schema: "article-assets-v2",
    candidates: images.map(function (image) {
      return {id: image.id, url: image.url, source_id: "github-weekly", source_url: image.url};
    }),
    cover_id: "",
    body_ids: [],
  };
  var start = 0;
  images.forEach(function (image, pos) {
    if (githubImages()[index] && image.id === githubImages()[index].id) { start = pos; }
  });
  openImageLightbox(start);
}
function loadGithubWeekly() {
  status("hotspot-status", "正在读取周榜…");
  return fetch("/api/github-weekly").then(function (response) { return response.json(); }).then(function (data) {
    renderGithubWeekly(data);
    var count = (data.repos || []).length;
    status("hotspot-status", count ? "已显示 " + count + " 个仓库，可再点抓取周榜刷新" : "还没有周榜。点「抓取周榜」拉取本周新建的 AI 仓库，不够再用本周涨星补齐。", count ? "ok" : "");
    return data;
  }).catch(function (error) {
    status("hotspot-status", "读取周榜失败：" + error.message, "error");
  });
}
function refreshGithubWeekly() {
  if (waitRunning("github_fetch")) { return; }
  waitStart("github_fetch");
  status("hotspot-status", "正在按星标抓取本周 GitHub AI 项目…");
  waitApi("github_fetch", "/api/github-weekly", {}).then(function (data) {
    if (waitCancelled("github_fetch")) { return; }
    renderGithubWeekly(data);
    var count = (data.repos || []).length;
    var extra = data.model_used ? " · 榜单模型已改写简介" : " · 未配置榜单模型，简介用仓库描述";
    if (state.lane === "github") {
      status("hotspot-status", (count ? "已抓取 " + count + " 个仓库" : "没有抓到仓库") + extra + "。选配色后点「生成图片」。", count ? "ok" : "error");
    }
    waitDone(count ? ("已抓取 " + count + " 个仓库") : "没有抓到仓库", "github_fetch");
  }).catch(function (error) {
    if (isWaitAbort(error, "github_fetch")) { return; }
    status("hotspot-status", "抓取周榜失败：" + error.message, "error");
    waitFail(error.message || "抓取周榜失败", "github_fetch");
  });
}
function githubThemeDefaults(theme) {
  return theme === "light"
    ? {main: "#F3EFE4", secondary: "#FFFCF6", accent: "#5C4FD6"}
    : {main: "#0B0D12", secondary: "#141821", accent: "#8B7CFF"};
}
function setGithubTheme(theme) {
  state.githubTheme = theme === "light" ? "light" : "dark";
  if ($("gh-theme-dark")) { $("gh-theme-dark").classList.toggle("active", state.githubTheme === "dark"); }
  if ($("gh-theme-light")) { $("gh-theme-light").classList.toggle("active", state.githubTheme === "light"); }
  var defaults = githubThemeDefaults(state.githubTheme);
  if ($("gh-color-main")) { $("gh-color-main").value = defaults.main; }
  if ($("gh-color-secondary")) { $("gh-color-secondary").value = defaults.secondary; }
  if ($("gh-color-accent")) { $("gh-color-accent").value = defaults.accent; }
}
function renderGithubWeeklyImages() {
  var button = $("github-render-btn");
  if (!(state.githubWeekly.repos || []).length) {
    status("hotspot-status", "请先点「抓取周榜」，再生成图片", "error");
    return;
  }
  var images = githubImages();
  if (!images.length) {
    status("hotspot-status", "没有可生成的图片任务", "error");
    return;
  }
  if (waitRunning("github_render")) { return; }
  if (button) { busy(button, true); }
  var palette = {
    main: $("gh-color-main").value,
    secondary: $("gh-color-secondary").value,
    accent: $("gh-color-accent").value
  };
  var theme = state.githubTheme || "dark";
  var total = images.length;
  var index = 0;
  var failed = 0;
  state.githubImageBust = Date.now();
  images.forEach(function (image) {
    image.queued = true;
    image.busy = false;
    image.error = "";
  });
  renderGithubGallery();
  waitStart("github_render", {current: 0, total: total, step: "准备开始"});
  status("hotspot-status", "开始生成 1 / " + total + " 张周榜图…");
  function finishRender() {
    images.forEach(function (image) { image.queued = false; image.busy = false; });
    renderGithubGallery();
    if (button) { busy(button, false); }
    $("github-export-btn").disabled = !images.filter(function (image) { return image.selected !== false && image.url; }).length;
  }
  function next() {
    if (waitCancelled("github_render")) {
      finishRender();
      return;
    }
    if (index >= total) {
      var done = total - failed;
      if (failed && !done) {
        waitFail("全部 " + total + " 张都没有生成", "github_render");
        status("hotspot-status", "出图失败：全部 " + total + " 张都没有生成", "error");
      } else {
        waitDone(failed ? ("已生成 " + done + " / " + total + " 张，失败 " + failed + " 张") : ("已全部生成 " + done + " 张"), "github_render");
        status("hotspot-status", failed ? ("已生成 " + done + " 张，失败 " + failed + " 张") : ("已全部生成 " + done + " 张周榜图，勾选后可导出"), failed ? "error" : "ok");
      }
      finishRender();
      return;
    }
    var job = images[index];
    job.queued = false;
    job.busy = true;
    job.error = "";
    waitProgress(index + 1, total, job.title || job.id, "github_render");
    if (state.lane === "github") {
      status("hotspot-status", "正在生成第 " + (index + 1) + " / " + total + " 张 · " + (job.title || job.id));
    }
    renderGithubGallery();
    // 逐张调用 /api/github-weekly/image；全量 /api/github-weekly/render 仍给脚本用
    waitApi("github_render", "/api/github-weekly/image", {id: job.id, theme: theme, palette: palette}).then(function (data) {
      if (waitCancelled("github_render")) {
        job.busy = false;
        finishRender();
        return;
      }
      Object.assign(job, data, {busy: false, queued: false, error: ""});
      index += 1;
      next();
    }).catch(function (error) {
      if (isWaitAbort(error, "github_render")) {
        job.busy = false;
        finishRender();
        return;
      }
      job.busy = false;
      job.queued = false;
      job.error = error.reason || error.message || "失败";
      failed += 1;
      index += 1;
      next();
    });
  }
  next();
}
function copyGithubXhs() {
  var text = ($("github-xhs-title").value || "") + "\\n\\n" + ($("github-xhs-body").value || "");
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function () {
      status("hotspot-status", "小红书文案已复制", "ok");
    }).catch(function () {
      $("github-xhs-body").select();
      status("hotspot-status", "请手动复制文案", "");
    });
  } else {
    $("github-xhs-body").select();
  }
}
function loadGithubImage(url) {
  return new Promise(function (resolve) {
    if (!url) { resolve(null); return; }
    var image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = function () { resolve(image); };
    image.onerror = function () { resolve(null); };
    image.src = githubIcon(url);
  });
}
function roundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
function drawGithubCover(ctx, repos, icons) {
  ctx.fillStyle = "#141210";
  ctx.fillRect(0, 0, 1080, 1920);
  ctx.fillStyle = "#d4a574";
  ctx.font = "600 22px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText("WEEKLY", 72, 110);
  ctx.fillStyle = "#f4efe6";
  ctx.font = "700 96px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText("GitHub", 72, 230);
  ctx.fillStyle = "#d4a574";
  ctx.font = "500 36px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText("本周爆火ai工具", 72, 292);
  repos.forEach(function (repo, index) {
    var y = 360 + index * 148;
    ctx.fillStyle = "#9a9284";
    ctx.font = "600 24px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(String(repo.rank).padStart(2, "0"), 72, y + 38);
    var icon = icons[index];
    if (icon) {
      ctx.save();
      roundedRect(ctx, 128, y, 56, 56, 14);
      ctx.clip();
      ctx.drawImage(icon, 128, y, 56, 56);
      ctx.restore();
    }
    ctx.fillStyle = "#f4efe6";
    ctx.font = "650 30px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(repo.name, 204, y + 28);
    ctx.fillStyle = "#9a9284";
    ctx.font = "500 20px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(repo.kind || "", 204, y + 56);
    ctx.fillStyle = "#2c2923";
    roundedRect(ctx, 760, y + 28, 180, 8, 4);
    ctx.fill();
    ctx.fillStyle = "#c4a46a";
    roundedRect(ctx, 760, y + 28, Math.max(16, 180 * (repo.star_share || 0)), 8, 4);
    ctx.fill();
    ctx.fillStyle = "#f4efe6";
    ctx.font = "600 24px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(repo.stars_label || "", 960, y + 38);
  });
}
function drawGithubPoster(ctx, repo, icon) {
  ctx.fillStyle = "#141210";
  ctx.fillRect(0, 0, 1080, 1920);
  ctx.fillStyle = "#d4a574";
  ctx.font = "600 22px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText("NO." + String(repo.rank).padStart(2, "0"), 72, 110);
  if (icon) {
    ctx.save();
    roundedRect(ctx, 72, 150, 120, 120, 28);
    ctx.clip();
    ctx.drawImage(icon, 72, 150, 120, 120);
    ctx.restore();
  }
  ctx.fillStyle = "#f4efe6";
  ctx.font = "700 64px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText(repo.name, 220, 230);
  ctx.fillStyle = "#9a9284";
  ctx.font = "500 24px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText((repo.kind || "") + "  ·  " + (repo.stars_label || ""), 220, 272);
  wrapText(ctx, repo.summary || repo.description || "", 72, 360, 936, 42, "#c9c1b4", "500 28px ui-sans-serif, system-ui, sans-serif");
  var blocks = [
    ["做什么", repo.does],
    ["适合什么场景", repo.scene],
    ["如何实现", repo.how]
  ];
  blocks.forEach(function (block, index) {
    var y = 620 + index * 380;
    ctx.fillStyle = "#1c1916";
    roundedRect(ctx, 72, y, 936, 340, 28);
    ctx.fill();
    ctx.fillStyle = "#d4a574";
    ctx.font = "600 22px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(block[0], 108, y + 52);
    wrapText(ctx, block[1] || "", 108, y + 108, 864, 44, "#f4efe6", "500 30px ui-sans-serif, system-ui, sans-serif");
  });
}
function wrapText(ctx, text, x, y, maxWidth, lineHeight, color, font) {
  ctx.fillStyle = color;
  ctx.font = font;
  var line = "";
  String(text || "").split("").forEach(function (ch) {
    var next = line + ch;
    if (ctx.measureText(next).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      line = ch;
      y += lineHeight;
    } else {
      line = next;
    }
  });
  if (line) { ctx.fillText(line, x, y); }
}
function downloadCanvas(canvas, filename) {
  var link = document.createElement("a");
  link.href = canvas.toDataURL("image/png");
  link.download = filename;
  link.click();
}
function exportGithubImages() {
  var selected = githubImages().filter(function (image) { return image.selected !== false && image.url; });
  if (!selected.length) { return; }
  if (waitRunning("export")) { return; }
  var button = $("github-export-btn");
  if (button) { busy(button, true); }
  waitStart("export", {current: 0, total: selected.length, unit: "张", step: "准备导出"});
  var chain = Promise.resolve();
  selected.forEach(function (image, index) {
    chain = chain.then(function () {
      if (waitCancelled("export")) { return; }
      waitProgress(index + 1, selected.length, image.title || image.id, "export");
      return fetch(image.url, {signal: waitSignal("export")}).then(function (response) { return response.blob(); }).then(function (blob) {
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = (image.file || (image.id + ".png"));
        window.setTimeout(function () { link.click(); }, index * 220);
      });
    });
  });
  chain.then(function () {
    if (waitCancelled("export")) { return; }
    status("hotspot-status", "已按当前顺序导出 " + selected.length + " 张选中图片", "ok");
    waitDone("已导出 " + selected.length + " 张", "export");
  }).catch(function (error) {
    if (isWaitAbort(error, "export")) { return; }
    status("hotspot-status", "导出失败：" + error.message, "error");
    waitFail(error.message || "导出失败", "export");
  }).then(function () {
    if (button) { busy(button, false); }
  });
}
function skillImages() {
  return (state.skillsPackage && state.skillsPackage.images) || [];
}
function renderSkillPackage(payload) {
  state.skillsPackage = payload || state.skillsPackage || {};
  var pack = state.skillsPackage;
  var stages = (pack.stages || []).filter(function (stage) { return stage && !stage.gap; });
  var skills = (pack.skills || []).filter(function (skill) { return skill && !skill.gap; });
  pack.stages = stages;
  pack.skills = skills;
  var chips = $("skill-stage-chips");
  chips.textContent = "";
  stages.forEach(function (stage) {
    chips.appendChild(el("li", "", stage.name || stage.id));
  });
  var list = $("skill-list");
  list.textContent = "";
  skills.forEach(function (skill) {
    var row = el("li", "gh-row");
    row.appendChild(el("span", "muted", skill.stage_name || skill.stage_id || ""));
    var meta = document.createElement("div");
    meta.appendChild(el("strong", "", skill.name || skill.source_id || ""));
    meta.appendChild(el("span", "gh-kind", (skill.source || "GitHub") + (skill.source_id ? " · " + skill.source_id : "")));
    row.appendChild(meta);
    var stars = el("div", "gh-stars");
    stars.appendChild(el("span", "", String(skill.stars || 0)));
    row.appendChild(stars);
    list.appendChild(row);
  });
  var articleTitle = (pack.article && pack.article.title) || pack.title || "";
  var articleBody = (pack.article && pack.article.body) || "";
  $("skills-title").textContent = articleTitle || "介绍文";
  $("skills-body").textContent = articleBody || "查找完成后会生成介绍文。按收录 skill 从左到右、从上到下说明。";
  $("skills-article").classList.toggle("is-empty", !String(articleBody).trim());
  renderSkillsGallery();
  var images = skillImages();
  $("skills-export-btn").disabled = !images.filter(function (image) { return image.selected !== false && image.url; }).length;
  $("skills-select-all").disabled = !images.length;
  $("skills-render-btn").disabled = !pack.title && !skills.length;
  if (waitRunning("skill_search")) { paintWait(); }
}
function queuedSkillImages(pack) {
  var tiles = [{id: "cover", kind: "cover", title: (pack && pack.title) || "Skill 查找结果", queued: true, selected: true, url: "", file: "cover.png"}];
  ((pack && pack.skills) || []).forEach(function (skill, index) {
    var rank = index + 1;
    var name = skill.name || skill.source_id || ("skill-" + rank);
    tiles.push({
      id: (rank < 10 ? "0" : "") + rank + "-" + name,
      kind: "poster",
      title: name,
      queued: true,
      selected: true,
      url: "",
      file: ""
    });
  });
  return tiles;
}
function renderSkillsGallery() {
  var gallery = $("skills-gallery");
  gallery.textContent = "";
  var pack = state.skillsPackage || {};
  var images = skillImages();
  if (!images.length && (pack.skills || []).length) {
    images = queuedSkillImages(pack);
  }
  if (!images.length) {
    gallery.appendChild(el("p", "gh-pending", "查找完成后会自动出图。封面是主题大字报，项目卡按收录 skill 生成。"));
    return;
  }
  images.forEach(function (image, index) {
    var extras = "";
    if (image.busy) { extras += " is-running"; }
    else if (image.queued) { extras += " is-queued"; }
    if (image.error) { extras += " is-error"; }
    if (image.selected !== false) { extras += " selected"; }
    var tile = el("div", "gh-tile" + extras);
    tile.dataset.imageId = image.id;
    var check = document.createElement("button");
    check.type = "button";
    check.className = "gh-check";
    check.textContent = image.selected === false ? "" : "✓";
    check.addEventListener("click", function (event) {
      event.stopPropagation();
      toggleSkillImage(image.id);
    });
    tile.appendChild(check);
    if (image.url) {
      var img = document.createElement("img");
      img.alt = image.title || image.id;
      img.src = githubFreshUrl(image.url);
      img.addEventListener("click", function () { openSkillsLightbox(index); });
      tile.appendChild(img);
    }
    if (image.busy) {
      tile.appendChild(el("p", "gh-pending gh-overlay", "正在生成…"));
    } else if (image.queued) {
      tile.appendChild(el("p", "gh-pending gh-overlay", "排队中"));
    } else if (image.error) {
      tile.appendChild(el("p", "gh-pending gh-overlay", "失败 · " + image.error));
    } else if (!image.url) {
      tile.appendChild(el("p", "gh-pending", "待出图 · " + (image.title || image.id)));
    }
    gallery.appendChild(tile);
  });
}
function toggleSkillImage(imageId) {
  skillImages().forEach(function (image) {
    if (image.id === imageId) {
      image.selected = image.selected === false;
    }
  });
  renderSkillPackage(state.skillsPackage);
}
function selectAllSkillImages() {
  var images = skillImages();
  var allOn = images.length && images.every(function (image) { return image.selected !== false; });
  images.forEach(function (image) { image.selected = !allOn; });
  renderSkillPackage(state.skillsPackage);
}
function openSkillsLightbox(index) {
  var images = skillImages().filter(function (image) { return image.url; });
  if (!images.length) { return; }
  state.draft = state.draft || {assets: {candidates: []}};
  state.draft.assets = {
    schema: "article-assets-v2",
    candidates: images.map(function (image) {
      return {id: image.id, url: image.url, source_id: "skills", source_url: image.url};
    }),
    cover_id: "",
    body_ids: [],
  };
  var start = 0;
  images.forEach(function (image, pos) {
    if (skillImages()[index] && image.id === skillImages()[index].id) { start = pos; }
  });
  openImageLightbox(start);
}
function loadSkills() {
  status("hotspot-status", "正在读取技能包…");
  return fetch("/api/skills").then(function (response) { return response.json(); }).then(function (data) {
    renderSkillPackage(data);
    var count = (data.skills || []).length;
    status("hotspot-status", count ? "已显示 " + count + " 个 skill，可再输入关键词查找" : "输入关键词或需求，点「查找」。", count ? "ok" : "");
    return data;
  }).catch(function (error) {
    status("hotspot-status", "读取技能包失败：" + error.message, "error");
  });
}
function abortSkillSearch(query) {
  return api("/api/skills/search", {query: query || "", abort: true}).catch(function () { return null; });
}
function skillArticleReady(data) {
  return !!(data && data.article && String(data.article.body || "").trim());
}
function pollSkillSnapshot() {
  if (waitCancelled("skill_search")) {
    return abortSkillSearch(($("skill-query").value || "").trim());
  }
  return fetch("/api/skills", {signal: waitSignal("skill_search")}).then(function (response) { return response.json(); }).then(function (data) {
    renderSkillPackage(data);
    var phase = data.phase || "";
    if (phase === "skills_ready") { renderSkillImages(); }
    if (phase === "error") {
      var error = new Error(data.error_reason || data.error || "查找失败");
      throw error;
    }
    if (skillArticleReady(data)) {
      return data;
    }
    if (phase === "understanding" || phase === "chain" || phase === "decompose" || phase === "keywords" || phase === "search" || phase === "group" || phase === "compose" || phase === "searching" || phase === "skills_ready" || phase === "rendering" || phase === "done" || !phase) {
      return new Promise(function (resolve, reject) {
        window.setTimeout(function () { pollSkillSnapshot().then(resolve, reject); }, 350);
      });
    }
    return data;
  });
}
function searchSkills() {
  var query = ($("skill-query").value || "").trim();
  if (!query) {
    status("hotspot-status", "请先输入关键词或需求", "error");
    return;
  }
  if (waitRunning("skill_search")) { return; }
  var button = $("skill-search-btn");
  if (button) { busy(button, true); }
  waitStart("skill_search");
  status("hotspot-status", "正在按覆盖地图查找 skill…");
  waitApi("skill_search", "/api/skills/search", {query: query}).then(function (data) {
    if (waitCancelled("skill_search")) { return abortSkillSearch(query); }
    renderSkillPackage(data);
    var phase = data.phase || "";
    if (phase === "skills_ready") { renderSkillImages(); }
    if (phase === "searching" || !phase || !skillArticleReady(data)) {
      return pollSkillSnapshot();
    }
    return data;
  }).then(function (data) {
    if (!data || waitCancelled("skill_search")) { return; }
    renderSkillPackage(data);
    var count = (data.skills || []).length;
    var phase = data.phase || "";
    if (phase === "skills_ready") { renderSkillImages(); }
    status("hotspot-status", count ? "已收录 " + count + " 个 skill" : "没有找到合格 skill", count ? "ok" : "error");
    waitDone(count ? ("已收录 " + count + " 个 skill") : "没有找到合格 skill", "skill_search");
  }).catch(function (error) {
    if (isWaitAbort(error, "skill_search")) {
      abortSkillSearch(query);
      return;
    }
    status("hotspot-status", "查找失败：" + (error.reason || error.message), "error");
    waitFail(error.message || "查找失败", "skill_search");
  }).then(function () {
    if (button) { busy(button, false); }
  });
}
function renderSkillImages() {
  var pack = state.skillsPackage || {};
  if (!(pack.skills || []).length && !pack.title) {
    status("hotspot-status", "请先查找 skill，再生成图片", "error");
    return;
  }
  if (waitRunning("skill_render")) { return; }
  var button = $("skills-render-btn");
  if (button) { busy(button, true); }
  if (!(pack.images || []).length) {
    pack.images = queuedSkillImages(pack);
    renderSkillsGallery();
  }
  waitStart("skill_render");
  status("hotspot-status", "正在生成技能包封面和项目卡…");
  var poll = window.setInterval(function () {
    if (waitCancelled("skill_render")) { return; }
    fetch("/api/skills").then(function (response) { return response.json(); }).then(function (data) {
      if (data && (data.images || []).length) { renderSkillPackage(data); }
    }).catch(function () {});
  }, 400);
  waitApi("skill_render", "/api/skills/render", {theme: state.githubTheme || "dark"}).then(function (data) {
    if (waitCancelled("skill_render")) { return; }
    renderSkillPackage(data);
    var images = skillImages().filter(function (image) { return image.url; });
    status("hotspot-status", images.length ? "已生成 " + images.length + " 张，勾选后可导出" : "没有生成图片", images.length ? "ok" : "error");
    waitDone(images.length ? ("已生成 " + images.length + " 张") : "没有生成图片", "skill_render");
  }).catch(function (error) {
    if (isWaitAbort(error, "skill_render")) { return; }
    status("hotspot-status", "出图失败：" + (error.reason || error.message), "error");
    waitFail(error.message || "出图失败", "skill_render");
  }).then(function () {
    window.clearInterval(poll);
    if (button) { busy(button, false); }
  });
}
function exportSkillImages() {
  var selected = skillImages().filter(function (image) { return image.selected !== false && image.url; });
  if (!selected.length) { return; }
  if (waitRunning("export")) { return; }
  var button = $("skills-export-btn");
  if (button) { busy(button, true); }
  waitStart("export", {current: 0, total: selected.length, unit: "张", step: "准备导出"});
  var chain = Promise.resolve();
  selected.forEach(function (image, index) {
    chain = chain.then(function () {
      if (waitCancelled("export")) { return; }
      waitProgress(index + 1, selected.length, image.title || image.id, "export");
      return fetch(image.url, {signal: waitSignal("export")}).then(function (response) { return response.blob(); }).then(function (blob) {
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = (image.file || (image.id + ".png"));
        window.setTimeout(function () { link.click(); }, index * 220);
      });
    });
  });
  chain.then(function () {
    if (waitCancelled("export")) { return; }
    status("hotspot-status", "已按当前顺序导出 " + selected.length + " 张选中图片", "ok");
    waitDone("已导出 " + selected.length + " 张", "export");
  }).catch(function (error) {
    if (isWaitAbort(error, "export")) { return; }
    status("hotspot-status", "导出失败：" + error.message, "error");
    waitFail(error.message || "导出失败", "export");
  }).then(function () {
    if (button) { busy(button, false); }
  });
}
function fillPaper(ctx) {
  var gradient = ctx.createLinearGradient(0, 0, 0, 1920);
  gradient.addColorStop(0, "#f7f1e4");
  gradient.addColorStop(1, "#efe4d2");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 1080, 1920);
  ctx.fillStyle = "rgba(92,68,38,0.05)";
  var y;
  for (y = 48; y < 1920; y += 8) {
    ctx.fillRect(0, y, 1080, 1);
  }
  ctx.fillStyle = "rgba(255,255,255,0.28)";
  ctx.fillRect(0, 0, 1080, 80);
}
function drawXhsCard(ctx, card) {
  if (card.kind === "cover" && !card.image_url) {
    ctx.fillStyle = "#3d2b1f";
    ctx.fillRect(0, 0, 1080, 1920);
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 12;
    ctx.strokeRect(48, 48, 984, 1824);
    wrapText(ctx, card.title || "", 96, 420, 888, 96, "#ffffff", '700 72px "Songti SC", "STSong", serif');
    if (card.lede) {
      wrapText(ctx, card.lede, 96, 1100, 888, 52, "#ffffff", "500 36px ui-sans-serif, system-ui, sans-serif");
    }
    return Promise.resolve();
  }
  fillPaper(ctx);
  var handle = card.handle || "@小红书号";
  ctx.fillStyle = "#d7c4a8";
  ctx.beginPath();
  ctx.arc(96, 88, 28, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#5a4c3c";
  ctx.font = "700 22px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText(handle.replace(/^@/, "").slice(0, 1) || "A", 88, 96);
  ctx.fillStyle = "#6a5b4a";
  ctx.font = "500 28px ui-sans-serif, system-ui, sans-serif";
  ctx.fillText(handle, 140, 98);
  if (card.kind === "cover") {
    ctx.fillStyle = "#2f291f";
    ctx.font = "700 64px ui-sans-serif, system-ui, sans-serif";
    wrapText(ctx, card.title || "", 72, 220, 936, 78, "#2f291f", "700 64px ui-sans-serif, system-ui, sans-serif");
    if (card.lede) {
      wrapText(ctx, card.lede, 72, 520, 936, 52, "#4a4034", "500 36px ui-sans-serif, system-ui, sans-serif");
    }
    return Promise.resolve();
  }
  wrapText(ctx, card.text || "", 72, 200, 936, 52, "#3c342b", "500 36px ui-sans-serif, system-ui, sans-serif");
  return Promise.resolve();
}
function exportXhsImages() {
  var cards = (state.draft && state.draft.cards) || [];
  if (!cards.length) { return; }
  var canvas = $("xhs-canvas");
  canvas.width = 1080;
  canvas.height = 1920;
  var ctx = canvas.getContext("2d");
  var button = $("xhs-export-btn");
  if (button) { busy(button, true); }
  waitStart("export", {current: 0, total: cards.length, unit: "张", step: "准备导出"});
  var cover = cards[0] && cards[0].image_url ? loadGithubImage(cards[0].image_url) : Promise.resolve(null);
  cover.then(function (coverImage) {
    var chain = Promise.resolve();
    cards.forEach(function (card, index) {
      chain = chain.then(function () {
        if (waitCancelled("export")) { return; }
        waitProgress(index + 1, cards.length, card.kind || ("第 " + (index + 1) + " 张"), "export");
        return new Promise(function (resolve) {
          window.setTimeout(function () {
            drawXhsCard(ctx, card);
            if (card.kind === "cover" && coverImage) {
              var width = 936;
              var height = 1100;
              ctx.save();
              roundedRect(ctx, 72, 520, width, height, 28);
              ctx.clip();
              ctx.drawImage(coverImage, 72, 520, width, height);
              ctx.restore();
            }
            downloadCanvas(canvas, "xhs-" + String(index + 1).padStart(2, "0") + ".png");
            resolve();
          }, 220);
        });
      });
    });
    return chain;
  }).then(function () {
    if (waitCancelled("export")) { return; }
    status("article-status", "已导出 " + cards.length + " 张小红书图片", "ok");
    waitDone("已导出 " + cards.length + " 张", "export");
  }).catch(function (error) {
    if (isWaitAbort(error, "export")) { return; }
    status("article-status", "导出失败：" + error.message, "error");
    waitFail(error.message || "导出失败", "export");
  }).then(function () {
    if (button) { busy(button, false); }
  });
}
function setLane(lane) {
  if (lane !== "hotspots" && lane !== "viewpoints" && lane !== "github" && lane !== "skills") { return; }
  var select = $("prompt-style-select");
  if (state.lane === "hotspots" && select && select.value !== "经验分享") {
    state.newsStyle = select.value;
  }
  state.lane = lane;
  document.body.classList.toggle("lane-github", lane === "github");
  document.body.classList.toggle("lane-skills", lane === "skills");
  document.querySelectorAll("[data-lane]").forEach(function (tab) {
    var on = tab.dataset.lane === lane;
    tab.classList.toggle("active", on);
    tab.setAttribute("aria-selected", String(on));
  });
  $("collect-btn").textContent = lane === "github" ? "抓取周榜" : "刷新全部";
  delete $("collect-btn").dataset.originalLabel;
  $("h-hotspots").textContent = lane === "github" ? "GitHub AI 项目周榜" : (lane === "viewpoints" ? "观点候选" : (lane === "skills" ? "Skill查找器" : "热点候选"));
  $("hotspot-sub").textContent = lane === "github"
    ? "优先本周新建的 AI 仓库，不够再用本周涨星补齐。先抓取周榜，再选浅色/暗色和三色盘后点生成图片。"
    : (lane === "viewpoints"
    ? "下面是 Reddit 上正在热的 AI 使用/经验帖。热度看分数和评论数；这是社区说法，不是官方新闻。"
    : (lane === "skills"
    ? "输入关键词或需求，按覆盖地图全网找 skill，打包成总览文和周榜式图片。封面是主题大字报。"
    : "下面是话题/新闻候选。热度看独立来源数和讨论量；社区帖过阈会升温，一线说法用某某称，不是权威转载"));
  $("source-health-wrap").hidden = lane !== "hotspots";
  if (select) {
    select.value = lane === "viewpoints" ? "经验分享" : (state.newsStyle || "AI专家");
  }
  if (lane === "github") {
    clearHotspotSelection();
    loadGithubWeekly();
    return;
  }
  if (lane === "skills") {
    clearHotspotSelection();
    loadSkills();
    return;
  }
  clearHotspotSelection();
  loadHotspots().then(function (data) {
    return widenIfEmpty(data || {}, currentHours());
  });
}
document.querySelectorAll("[data-lane]").forEach(function (tab) {
  tab.addEventListener("click", function () { setLane(tab.dataset.lane); });
});
$("seg-wechat").addEventListener("click", function () { setPlatform("wechat"); });
$("seg-xhs").addEventListener("click", function () { setPlatform("xiaohongshu"); });
$("find-hooks-btn").addEventListener("click", findHooks);
$("open-original-btn").addEventListener("click", openOriginal);
$("original-translate").addEventListener("click", translateOriginal);
$("original-close").addEventListener("click", closeOriginal);
$("original-dialog").addEventListener("cancel", closeOriginal);
$("generate-btn").addEventListener("click", generate);
$("save-article-btn").addEventListener("click", saveArticle);
$("image-rescan").addEventListener("click", rescanImages);
$("lightbox-close").addEventListener("click", closeImageLightbox);
$("lightbox-prev").addEventListener("click", function () { stepImageLightbox(-1); });
$("lightbox-next").addEventListener("click", function () { stepImageLightbox(1); });
$("lightbox-image").addEventListener("click", closeImageLightbox);
$("image-lightbox").addEventListener("click", function (event) {
  if (event.target === $("image-lightbox") || (event.target.classList && event.target.classList.contains("lightbox-stage"))) {
    closeImageLightbox();
  }
});
$("image-lightbox").addEventListener("cancel", function () { closeImageLightbox(); });
document.addEventListener("keydown", function (event) {
  if (!$("image-lightbox").open) { return; }
  if (event.key === "ArrowLeft") { event.preventDefault(); stepImageLightbox(-1); }
  if (event.key === "ArrowRight") { event.preventDefault(); stepImageLightbox(1); }
});
["article-title", "article-body"].forEach(function (id) {
  $(id).addEventListener("input", function () {
    if (id === "article-body") { fitArticleBody(); }
    if (!state.draft) { return; }
    state.articleDirty = true;
    $("publish-btn").disabled = false;
    $("schedule-btn").disabled = false;
    status("article-status", "有未保存的修改");
  });
});
$("article-model").addEventListener("change", function (event) { changeMainModel("article", event); });
$("chat-model").addEventListener("change", function (event) { changeMainModel("chat", event); });
$("chat-send-btn").addEventListener("click", sendChat);
$("chat-input").addEventListener("input", fitChatInput);
$("chat-input").addEventListener("keydown", function (event) {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    sendChat();
  }
});
$("publish-btn").addEventListener("click", publish);
$("schedule-btn").addEventListener("click", schedulePublish);
$("creator-btn").addEventListener("click", function () {
  if (state.creatorUrl) { window.open(state.creatorUrl, "_blank", "noopener"); }
});
$("config-btn").addEventListener("click", function () {
  openSettings(false);
});
$("favorites-btn").addEventListener("click", function () { toggleFavoritesDrawer(); });
$("favorites-close").addEventListener("click", function () { toggleFavoritesDrawer(false); });
$("endpoint-connect").addEventListener("click", connectEndpoint);
$("endpoint-use-article").addEventListener("click", function () { assignEndpoint("article"); });
$("endpoint-use-translation").addEventListener("click", function () { assignEndpoint("translation"); });
$("endpoint-use-chat").addEventListener("click", function () { assignEndpoint("chat"); });
$("endpoint-use-leaderboard").addEventListener("click", function () { assignEndpoint("leaderboard"); });
$("endpoint-use-image").addEventListener("click", function () { assignEndpoint("image"); });
$("provider-add").addEventListener("click", function () { openProviderEditor("add", null); });
$("provider-apply").addEventListener("click", applyProvider);
$("provider-cancel").addEventListener("click", closeProviderEditor);
$("provider-remove").addEventListener("click", function () {
  deleteEndpoint($("config-form").dataset.endpointId || "");
});
$("config-form").elements.article_provider.addEventListener("change", function () { onPurposeProviderChange("article"); });
$("config-form").elements.translation_provider.addEventListener("change", function () { onPurposeProviderChange("translation"); });
$("config-form").elements.chat_provider.addEventListener("change", function () { onPurposeProviderChange("chat"); });
$("config-form").elements.leaderboard_provider.addEventListener("change", function () { onPurposeProviderChange("leaderboard"); });
$("config-form").elements.image_provider.addEventListener("change", function () { onPurposeProviderChange("image"); });
$("github-export-btn").addEventListener("click", exportGithubImages);
$("github-select-all").addEventListener("click", selectAllGithubImages);
$("github-render-btn").addEventListener("click", renderGithubWeeklyImages);
$("skill-search-btn").addEventListener("click", searchSkills);
$("skill-query").addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
    event.preventDefault();
    searchSkills();
  }
});
$("skills-render-btn").addEventListener("click", renderSkillImages);
$("skills-select-all").addEventListener("click", selectAllSkillImages);
$("skills-export-btn").addEventListener("click", exportSkillImages);
$("gh-theme-dark").addEventListener("click", function () { setGithubTheme("dark"); });
$("gh-theme-light").addEventListener("click", function () { setGithubTheme("light"); });
$("xhs-export-btn").addEventListener("click", exportXhsImages);
$("github-copy-btn").addEventListener("click", copyGithubXhs);
$("wechat-delete").addEventListener("click", function () { deleteAccount("wechat"); });
$("xhs-delete").addEventListener("click", function () { deleteAccount("xiaohongshu"); });
$("x-delete").addEventListener("click", function () { deleteAccount("x"); });
$("config-cancel").addEventListener("click", function () {
  state.pendingPublish = false;
  $("config-dialog").close();
});
$("config-dialog").addEventListener("cancel", function () { state.pendingPublish = false; });
document.querySelectorAll("[data-settings-platform]").forEach(function (node) {
  node.addEventListener("click", function () {
    setSettingsPlatform(node.dataset.settingsPlatform);
  });
});
document.querySelectorAll("[data-settings-page]").forEach(function (node) {
  node.addEventListener("click", function () { setSettingsPage(node.dataset.settingsPage); });
});
$("style-file").addEventListener("change", function (event) {
  var file = event.target.files && event.target.files[0];
  if (!file) { return; }
  var reader = new FileReader();
  reader.addEventListener("load", function () {
    $("config-form").elements.style.value = String(reader.result || "");
  });
  reader.readAsText(file);
});
$("config-form").addEventListener("submit", function (event) {
  event.preventDefault();
  var form = event.target;
  var button = $("config-save");
  var resumePublish = state.pendingPublish;
  busy(button, true);
  waitStart("save");
  var accountPayload = null;
  if (state.settingsPlatform === "wechat" && (form.app_id.value || form.app_secret.value || form.thumb_media_id.value)) {
    accountPayload = {
      platform: "wechat",
      app_id: form.app_id.value.trim(),
      app_secret: form.app_secret.value,
      thumb_media_id: form.thumb_media_id.value.trim(),
      author: form.author.value.trim(),
    };
  } else if (state.settingsPlatform === "xiaohongshu") {
    accountPayload = {
      platform: "xiaohongshu",
      account_name: form.account_name.value.trim(),
      creator_url: form.creator_url.value.trim(),
    };
  } else if (state.settingsPlatform === "x" && form.x_bearer_token.value) {
    accountPayload = {
      platform: "x",
      bearer_token: form.x_bearer_token.value,
    };
  }
  waitApi("save", "/api/style", {style: form.elements.style.value}).then(function (data) {
    state.style = data.style;
    return accountPayload ? waitApi("save", "/api/config", accountPayload) : data;
  }).then(function () {
    if (state.settingsPlatform === "xiaohongshu" && accountPayload) {
      state.xiaohongshu.accountName = accountPayload.account_name;
      state.xiaohongshu.creatorUrl = accountPayload.creator_url;
    }
    if (state.settingsPlatform === "wechat" && accountPayload) {
      state.platforms.wechat = {configured: true};
    }
    if (state.settingsPlatform === "x" && accountPayload) {
      state.platforms.x = {configured: true};
    }
    form.app_id.value = "";
    form.app_secret.value = "";
    form.thumb_media_id.value = "";
    form.author.value = "";
    form.account_name.value = "";
    form.creator_url.value = "";
    form.x_bearer_token.value = "";
    renderAccountPanels();
    state.pendingPublish = false;
    status("config-error", accountPayload ? "账号已保存" : "写作风格已保存", "ok");
    status("publish-status", "");
    waitDone(accountPayload ? "账号已保存" : "写作风格已保存", "save");
    if (resumePublish) {
      $("config-dialog").close();
      publish();
    }
  }).catch(function (error) {
    if (isWaitAbort(error, "save")) { return; }
    status("config-error", showApiError("保存失败：", error), "error");
    waitFail(error.message || "保存失败", "save");
  }).then(function () {
    busy(button, false);
  });
});

fetch("/api/status").then(function (response) { return response.json(); }).then(function (data) {
  if (data.llm) {
    state.llm = data.llm;
    state.style = data.style || "";
    var form = $("config-form");
    form.effort.value = data.llm.effort || "none";
    form.elements.style.value = state.style;
  }
  state.modelEndpoints = data.model_endpoints || [];
  if (data.chat_llm) {
    state.chat = data.chat_llm;
  }
  if (data.translation_llm) {
    state.translation = data.translation_llm;
  }
  if (data.leaderboard_llm) {
    state.leaderboard = data.leaderboard_llm;
  }
  if (data.image_llm) {
    state.image = data.image_llm;
  }
  renderModelPicker();
  renderChatModelPicker();
  fillPurposePickers();
  renderEndpointLists();
  if (data.platforms) { state.platforms = data.platforms; }
  if (data.platforms && data.platforms.xiaohongshu) {
    state.xiaohongshu.accountName = data.platforms.xiaohongshu.account_name || "";
    state.xiaohongshu.creatorUrl = data.platforms.xiaohongshu.creator_url || state.xiaohongshu.creatorUrl;
  }
  renderAccountPanels();
  if (data.version) { $("service-status").textContent = "v" + data.version + " · 本地服务"; }
  if (data.sources) { renderSourceHealth(data.sources); }
  loadFavorites();
  loadHotspots().then(function (hotspots) {
    return widenIfEmpty(hotspots || {}, currentHours());
  });
}).catch(function () {
  loadFavorites();
  loadHotspots().then(function (hotspots) {
    return widenIfEmpty(hotspots || {}, currentHours());
  });
});
</script>
</body>
</html>
"""


class WebApp:
    def __init__(
        self,
        database: Database,
        sources,
        packages_dir: str | Path,
        fetcher=None,
        wechat_base_url: str | None = None,
        wechat_opener=None,
        llm_service: LLMService | None = None,
        llm_runner=None,
        credential_store=None,
        page_fetcher=None,
        translation_service: LLMService | None = None,
        github_fetcher=None,
        leaderboard_service: LLMService | None = None,
        image_service: LLMService | None = None,
        image_generator=None,
        visual_renderer=None,
    ) -> None:
        self.database = database
        self.packages_dir = Path(packages_dir)
        source_tuple = tuple(load_sources(sources)) if isinstance(sources, (str, Path)) else tuple(sources)
        self.llm_service = llm_service if llm_service is not None else LLMService(database, runner=llm_runner)
        self._article_model_configured = llm_service is not None
        self.article_models = (
            [self.llm_service.settings.model] if self._article_model_configured else []
        )
        # Chat uses its own in-memory settings; the default runner only ever
        # talks to the configured OpenAI-compatible base_url.
        self.chat_service = LLMService(database)
        self.translation_service = translation_service or LLMService(database)
        self._translation_model_configured = translation_service is not None
        self.leaderboard_service = leaderboard_service or LLMService(database)
        self._leaderboard_model_configured = leaderboard_service is not None
        self.image_service = image_service or LLMService(database)
        self._image_model_configured = image_service is not None
        self.image_generator = image_generator
        self.visual_renderer = visual_renderer
        self.github_fetcher = github_fetcher
        self.skill_complete = None
        self.skill_screenshot = None
        self.skill_web_search = None
        self.credential_store = (
            credential_store if credential_store is not None else MacOSKeychainCredentialStore()
        )
        self._restore_model_selections()
        self.hotspots = HotspotService(
            database,
            source_tuple,
            fetcher=fetcher,
            llm_service=(self.translation_service if self._translation_model_configured else None),
        )
        self.workbench = Workbench(
            database,
            llm_service=self.llm_service,
            page_fetcher=default_page_fetcher if page_fetcher is None else page_fetcher,
        )
        self.workflow = ContentWorkflow(database)
        # ponytail: one local lock prevents duplicate platform submissions;
        # use per-account locks only if publish throughput becomes relevant.
        self._publish_lock = threading.Lock()
        self.wechat_config: dict[str, str] | None = None
        self.xiaohongshu_config: dict[str, str] = {
            "creator_url": XIAOHONGSHU_CREATOR_URL,
            "account_name": "",
        }
        self._wechat_base_url = wechat_base_url
        self._wechat_opener = wechat_opener
        self._wechat_poster_renderer: object = None
        self.article_style = ""
        self._original_text_cache: dict[str, dict[str, object]] = {}
        self._hotspot_payloads: dict[str, dict[str, object]] = {}
        self.x_bearer_token = ""
        self.scheduler = PublishScheduler(database, self.publish, interval_seconds=15)
        self._restore_accounts()

    def _restore_model_selections(self) -> None:
        """Restore saved model-purpose selections without network calls."""
        for purpose, service in (
            ("article", self.llm_service),
            ("translation", self.translation_service),
            ("chat", self.chat_service),
            ("leaderboard", self.leaderboard_service),
            ("image", self.image_service),
        ):
            mapping = self.database.get_model_purpose(purpose)
            if mapping is None:
                continue
            endpoint = self.database.get_model_endpoint(str(mapping["endpoint_id"]))
            api_key = (
                self.credential_store.get(str(mapping["endpoint_id"])) if endpoint is not None else None
            )
            if endpoint is None or not api_key:
                continue
            service.configure(
                model=str(mapping["model"]),
                effort=str(mapping["effort"]),
                base_url=str(endpoint["base_url"]),
                api_key=api_key,
            )
            if purpose == "article":
                self._article_model_configured = True
                try:
                    models = json.loads(str(endpoint["models_json"]))
                except json.JSONDecodeError:
                    models = []
                if isinstance(models, list):
                    self.article_models = [model for model in models if isinstance(model, str)]
            elif purpose == "translation":
                self._translation_model_configured = True
            elif purpose == "leaderboard":
                self._leaderboard_model_configured = True
            elif purpose == "image":
                self._image_model_configured = True

    def _account_payload(self, platform: str) -> dict[str, str] | None:
        raw = self.credential_store.get(ACCOUNT_STORE_IDS[platform])
        if not raw:
            return None
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            return None
        return payload if isinstance(payload, dict) else None

    def _store_account(self, platform: str, payload: dict[str, str]) -> None:
        self.credential_store.set(
            ACCOUNT_STORE_IDS[platform], json.dumps(payload, ensure_ascii=False, sort_keys=True)
        )

    def _restore_accounts(self) -> None:
        wechat = self._account_payload("wechat")
        if wechat and wechat.get("app_id") and wechat.get("app_secret"):
            self.wechat_config = {
                "app_id": str(wechat["app_id"]),
                "app_secret": str(wechat["app_secret"]),
                "thumb_media_id": str(wechat.get("thumb_media_id") or ""),
                "author": str(wechat.get("author") or ""),
            }
        xhs = self._account_payload("xiaohongshu")
        if xhs:
            name = str(xhs.get("account_name") or "")
            url = str(xhs.get("creator_url") or XIAOHONGSHU_CREATOR_URL)
            if url.startswith("https://"):
                self.xiaohongshu_config = {"account_name": name, "creator_url": url}
        x_token = self._account_payload("x")
        if x_token and x_token.get("bearer_token"):
            self.x_bearer_token = str(x_token["bearer_token"])
            self.hotspots.x_bearer_token = self.x_bearer_token

    def _model_endpoints(self) -> list[dict[str, object]]:
        endpoints: list[dict[str, object]] = []
        for row in self.database.list_model_endpoints():
            try:
                models = json.loads(str(row["models_json"]))
            except json.JSONDecodeError:
                models = []
            endpoints.append(
                {
                    "id": str(row["endpoint_id"]),
                    "base_url": str(row["base_url"]),
                    "models": [model for model in models if isinstance(model, str)],
                    "credential_available": bool(
                        self.credential_store.get(str(row["endpoint_id"]))
                    ),
                }
            )
        return endpoints

    def _resolve_endpoint_credentials(self, payload: dict, purpose: str) -> tuple[str, str]:
        """Resolve base_url/api_key from an endpoint_id or full credentials."""
        base_url = payload.get("base_url")
        api_key = payload.get("api_key")
        if isinstance(base_url, str) and isinstance(api_key, str) and api_key.strip():
            return base_url.strip().rstrip("/"), api_key
        endpoint_id = payload.get("endpoint_id")
        if isinstance(endpoint_id, str) and endpoint_id.strip():
            endpoint = self.database.get_model_endpoint(endpoint_id.strip())
            if endpoint is None:
                raise ValueError("endpoint not found")
            api_key = self.credential_store.get(endpoint_id.strip())
            if not api_key:
                raise ValueError("credential unavailable for endpoint")
            return str(endpoint["base_url"]), api_key
        if not isinstance(base_url, str) or not isinstance(api_key, str):
            raise ValueError("base_url and api_key are required")
        normalized_url = base_url.strip().rstrip("/")
        services = {
            "article": self.llm_service,
            "translation": self.translation_service,
            "chat": self.chat_service,
            "leaderboard": self.leaderboard_service,
            "image": self.image_service,
        }
        current = services[purpose].settings
        if api_key == "":
            api_key = self.credential_store.get(model_endpoint_id(normalized_url)) or ""
        if api_key == "" and current.base_url == normalized_url:
            api_key = current.api_key
        return normalized_url, api_key

    def _activate_endpoint(self, purpose: str, settings) -> None:
        """Persist endpoint metadata, its key, and the active purpose mapping."""
        endpoint_id = model_endpoint_id(settings.base_url)
        self.database.upsert_model_endpoint(endpoint_id, settings.base_url)
        self.credential_store.set(endpoint_id, settings.api_key)
        self.database.set_model_purpose(purpose, endpoint_id, settings.model, settings.effort)

    @property
    def wechat_publisher(self) -> WeChatPublisher | None:
        config = self.wechat_config
        if config is None:
            return None
        return WeChatPublisher(
            config["app_id"],
            config["app_secret"],
            config.get("thumb_media_id", ""),
            config.get("author", ""),
            base_url=self._wechat_base_url or DEFAULT_WECHAT_BASE_URL,
            opener=self._wechat_opener,
            image_fetcher=self.workbench.image_fetcher or download_image,
            poster_renderer=self._wechat_poster_renderer,
        )

    def status(self) -> dict[str, object]:
        settings = self.llm_service.settings
        chat_settings = self.chat_service.settings
        translation_settings = self.translation_service.settings
        leaderboard_settings = self.leaderboard_service.settings
        image_settings = self.image_service.settings
        return {
            "ok": True,
            "service": "autoposting",
            "version": APP_VERSION,
            "style": self.article_style,
            "llm": {
                **self.llm_service.settings_payload(settings),
                "enabled": self._article_model_configured,
                "models": list(self.article_models),
            },
            "chat_llm": (
                self.chat_service.settings_payload(chat_settings)
                if chat_settings.base_url
                else {"model": "", "base_url": "", "configured": False}
            ),
            "translation_llm": (
                {
                    **self.translation_service.settings_payload(translation_settings),
                    "enabled": True,
                }
                if self._translation_model_configured
                else {"model": "", "base_url": "", "configured": False, "enabled": False}
            ),
            "leaderboard_llm": (
                {
                    **self.leaderboard_service.settings_payload(leaderboard_settings),
                    "enabled": True,
                }
                if self._leaderboard_model_configured
                else {"model": "", "base_url": "", "configured": False, "enabled": False}
            ),
            "image_llm": (
                {
                    **self.image_service.settings_payload(image_settings),
                    "enabled": True,
                }
                if self._image_model_configured
                else {"model": "", "base_url": "", "configured": False, "enabled": False}
            ),
            "model_endpoints": self._model_endpoints(),
            "sources": self.hotspots.source_health(),
            "platforms": {
                "wechat": {"configured": self.wechat_config is not None},
                "xiaohongshu": {
                    "configured": True,
                    "account_configured": bool(self.xiaohongshu_config.get("account_name")),
                    "account_name": self.xiaohongshu_config["account_name"],
                    "creator_url": self.xiaohongshu_config["creator_url"],
                    "manual_required": True,
                },
                "x": {"configured": bool(self.x_bearer_token)},
            },
        }

    def collect(
        self,
        hours: int,
        force: bool = True,
        source_id: str | None = None,
        lane: str = "hotspots",
    ) -> dict[str, object]:
        payload = self.hotspots.collect(
            hours, force=force, source_id=source_id, lane=lane
        )
        self._remember_hotspot_payloads(payload)
        return {
            "ok": True,
            "count": len(payload["candidates"]),
            **payload,
        }

    def hotspots_window(
        self, hours: int, translate: bool = False, lane: str = "hotspots"
    ) -> dict[str, object]:
        payload = self.hotspots.list_window(hours, translate=translate, lane=lane)
        self._remember_hotspot_payloads(payload)
        return {
            "ok": True,
            "count": len(payload["candidates"]),
            **payload,
        }

    def _remember_hotspot_payloads(self, payload: dict[str, object]) -> None:
        buckets: list[object] = [payload.get("candidates") or []]
        rankings = payload.get("rankings")
        if isinstance(rankings, dict):
            buckets.extend(rankings.values())
        for items in buckets:
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, dict) and item.get("item_id"):
                    self._hotspot_payloads[str(item["item_id"])] = dict(item)

    def _favorite_payload_from_item(self, item: dict[str, object]) -> dict[str, object]:
        item_id = str(item["item_id"])
        sources = self.database.get_item_sources(item_id)
        summary = _summary(str(item.get("content_text") or item.get("title") or ""))
        return {
            "item_id": item_id,
            "title": str(item.get("title") or ""),
            "summary": summary,
            "content_text": str(item.get("content_text") or ""),
            "source_ids": [str(pair["source_id"]) for pair in sources],
            "source_urls": [str(pair.get("source_url") or "") for pair in sources],
            "observed_at": str(item.get("published_at") or item.get("fetched_at") or ""),
        }

    def list_favorites(self) -> dict[str, object]:
        return {"ok": True, "items": self.database.list_hotspot_favorites()}

    def add_favorite(self, item_id: str) -> dict[str, object]:
        item_id = str(item_id or "").strip()
        if not item_id:
            raise ValueError("item_id required")
        payload = self._hotspot_payloads.get(item_id)
        if payload is None:
            payload = self._favorite_payload_from_item(self.database.get_item(item_id))
        title = str(payload.get("title") or "")
        summary = str(payload.get("summary") or payload.get("content_text") or "")
        saved = self.database.add_hotspot_favorite(item_id, title, summary, dict(payload))
        return {"ok": True, "item": saved}

    def delete_favorite(self, item_id: str) -> dict[str, object]:
        item_id = str(item_id or "").strip()
        if not item_id:
            raise ValueError("item_id required")
        if not self.database.remove_hotspot_favorite(item_id):
            raise KeyError(item_id)
        return {"ok": True, "item_id": item_id}

    def find_hooks(self, item_id: str) -> dict[str, object]:
        return self.workbench.find_hooks(item_id)

    def original(self, item_id: str) -> dict[str, object]:
        cached = self._original_text_cache.get(item_id)
        if cached is not None:
            return {"ok": True, **cached}
        item = self.database.get_item(item_id)
        sources: list[dict[str, str]] = []
        seen: set[str] = set()
        pairs = self.database.get_item_sources(item_id)
        candidates = [
            (str(pair.get("source_id") or "原站"), str(pair.get("source_url") or ""))
            for pair in pairs
        ]
        candidates.append(("原站", str(item.get("canonical_url") or "")))
        for source_id, url in candidates:
            parsed = urlsplit(url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc or url in seen:
                continue
            seen.add(url)
            sources.append({"source_id": source_id, "url": url})
        stored = str(item.get("content_text") or "")
        content = stored
        content_source = "feed"
        is_reddit = "reddit.com" in str(item.get("canonical_url") or "").lower()
        if is_reddit:
            result = {
                "item_id": item_id,
                "title": str(item.get("title") or ""),
                "content": content,
                "content_source": "feed",
                "content_note": "正文和热评来自 Reddit 收录，未抓板块页面",
                "translatable": _looks_english(content or str(item.get("title") or "")),
                "sources": sources,
            }
            return {"ok": True, **result}
        if sources and self.workbench.page_fetcher is not None:
            try:
                fetched = article_page_text(self.workbench.page_fetcher(sources[0]["url"]))
            except (OSError, TimeoutError, ValueError, UnicodeError):
                fetched = ""
            if fetched and (not stored or len(fetched) > max(240, len(stored) + 80)):
                content = fetched
                content_source = "page"
        result = {
            "item_id": item_id,
            "title": str(item.get("title") or ""),
            "content": content,
            "content_source": content_source,
            "content_note": (
                "已从原站提取正文" if content_source == "page" else "原站正文不可用，显示 RSS 已收录内容"
            ),
            "translatable": _looks_english(content or str(item.get("title") or "")),
            "sources": sources,
        }
        if content_source == "page":
            self._original_text_cache[item_id] = result
        return {"ok": True, **result}

    def translate_original(self, item_id: str) -> dict[str, object]:
        if not self._translation_model_configured:
            raise ValueError("translation_model_not_configured")
        original = self.original(item_id)
        if not original["translatable"]:
            raise ValueError("original_is_already_chinese")
        translated = self.translation_service.translate_batch(
            [
                {
                    "item_id": item_id,
                    "title": (
                        str(original["title"])
                        if not _has_cjk(str(original["title"]))
                        else "English article"
                    ),
                    "summary": str(original["content"]),
                }
            ]
        )[item_id]
        if translated["status"] != "translated":
            raise LLMError(
                str(translated.get("error_code") or "translation_failed"),
                str(translated.get("error_reason") or "文章翻译失败"),
            )
        return {
            "ok": True,
            "item_id": item_id,
            "translation": translated["summary_zh"],
            "model": self.translation_service.settings.model,
        }

    def articles(
        self,
        item_id: str,
        platform: str,
        model: str | None = None,
        provider: str | None = None,
        effort: str | None = None,
        chosen_hooks: object = None,
        prompt_style: str = DEFAULT_ARTICLE_PROMPT_STYLE,
        item_ids: list[str] | None = None,
    ) -> dict[str, object]:
        if not self._article_model_configured:
            raise ValueError("article_model_not_configured")
        return {
            "ok": True,
            **self.workbench.generate_article(
                item_id,
                platform,
                model,
                provider,
                effort,
                self.article_style,
                chosen_hooks,
                prompt_style,
                self.xiaohongshu_config.get("account_name") or "",
                item_ids,
            ),
        }

    def approve(self, draft_id: str, reviewer: str) -> dict[str, object]:
        self.workflow.approve_draft(draft_id, reviewer)
        return {"ok": True, "draft_id": draft_id, "status": self.database.get_draft(draft_id)["status"]}

    def edit_article(self, draft_id: str, title: str, body: str) -> dict[str, object]:
        draft = self.workflow.edit_draft(draft_id, title, body)
        return self._draft_view(draft)

    def _draft_view(self, draft: dict[str, object]) -> dict[str, object]:
        assets = normalize_assets(draft["assets_json"])
        payload: dict[str, object] = {
            "ok": True,
            "draft_id": str(draft["draft_id"]),
            "event_id": str(draft["event_id"]),
            "platform": str(draft["platform"]),
            "status": str(draft["status"]),
            "title": str(draft["title"]),
            "body": str(draft["body"]),
            "source_ids": json.loads(str(draft["source_ids_json"])),
            "assets": assets,
        }
        if str(draft["platform"]) == "xiaohongshu":
            payload.update(
                xhs_fields(
                    str(draft["title"]),
                    str(draft["body"]),
                    assets,
                    self.xiaohongshu_config.get("account_name") or "",
                )
            )
        return payload

    def update_article_images(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("image selection must be a JSON object")
        draft_id = payload.get("draft_id")
        if not isinstance(draft_id, str) or not draft_id:
            raise ValueError("draft_id required")
        cover_id = payload.get("cover_id", "")
        if cover_id is None:
            cover_id = ""
        if not isinstance(cover_id, str):
            raise ValueError("cover_id must be a string")
        body_ids = payload.get("body_ids", [])
        if not isinstance(body_ids, list) or any(not isinstance(item, str) for item in body_ids):
            raise ValueError("body_ids must be a list of strings")
        draft = self.workflow.update_draft_images(draft_id, cover_id, body_ids)
        return self._draft_view(draft)

    def rescan_article_images(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict) or not isinstance(payload.get("draft_id"), str):
            raise ValueError("draft_id required")
        bundle = self.workbench.rescan_images(payload["draft_id"])
        draft = self.workflow.replace_draft_image_bundle(payload["draft_id"], bundle)
        return self._draft_view(draft)

    def proxy_image(self, url: str) -> tuple[bytes, str]:
        if not isinstance(url, str) or not url.startswith(("http://", "https://")):
            raise ValueError("image_url_invalid")
        if len(url) > 2000:
            raise ValueError("image_url_invalid")
        fetcher = self.workbench.image_fetcher or download_image
        payload = fetcher(url)
        if not isinstance(payload, (bytes, bytearray)) or not payload:
            raise ValueError("image_unavailable")
        data = bytes(payload)
        return data, guess_image_content_type(data)

    def set_model(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("model settings must be a JSON object")
        base_url, api_key = self._resolve_endpoint_credentials(payload, "article")
        settings = self.llm_service.configure_verified(
            model=payload.get("model"),
            effort=payload.get("effort", "none"),
            base_url=base_url,
            api_key=api_key,
        )
        self._article_model_configured = True
        if settings.model not in self.article_models:
            self.article_models.append(settings.model)
        self._activate_endpoint("article", settings)
        return {
            "ok": True,
            "llm": self.llm_service.settings_payload(settings),
            "model_endpoints": self._model_endpoints(),
        }

    def models(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("model discovery settings must be a JSON object")
        purpose = payload.get("purpose", "article")
        if purpose not in ("article", "translation", "chat", "leaderboard", "image"):
            raise ValueError("purpose must be article, translation, chat, leaderboard, or image")
        persist = payload.get("persist", True)
        if not isinstance(persist, bool):
            raise ValueError("persist must be boolean")
        saved_models = payload.get("models")
        if saved_models is not None:
            if not isinstance(saved_models, list) or any(
                not isinstance(item, str) or not item.strip() for item in saved_models
            ):
                raise ValueError("models must be a list of strings")
            saved_models = [item.strip() for item in saved_models]
        base_url, api_key = self._resolve_endpoint_credentials(payload, purpose)
        discovered = self.llm_service.discover_models(base_url, api_key)
        endpoint_id = model_endpoint_id(base_url)
        if persist:
            self.database.upsert_model_endpoint(
                endpoint_id, base_url, discovered if saved_models is None else saved_models
            )
            if api_key:
                self.credential_store.set(endpoint_id, api_key)
        return {
            "ok": True,
            "endpoint_id": endpoint_id,
            "models": list(discovered),
            "model_endpoints": self._model_endpoints(),
        }

    def set_chat_model(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("chat model settings must be a JSON object")
        base_url, api_key = self._resolve_endpoint_credentials(payload, "chat")
        settings = self.chat_service.configure_verified(
            model=payload.get("model"),
            effort="none",
            base_url=base_url,
            api_key=api_key,
        )
        self._activate_endpoint("chat", settings)
        return {
            "ok": True,
            "chat_llm": self.chat_service.settings_payload(settings),
            "model_endpoints": self._model_endpoints(),
        }

    def set_translation_model(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("translation model settings must be a JSON object")
        base_url, api_key = self._resolve_endpoint_credentials(payload, "translation")
        settings = self.translation_service.configure_verified(
            model=payload.get("model"),
            effort="none",
            base_url=base_url,
            api_key=api_key,
        )
        self._translation_model_configured = True
        self.hotspots.llm_service = self.translation_service
        self._activate_endpoint("translation", settings)
        return {
            "ok": True,
            "translation_llm": {
                **self.translation_service.settings_payload(settings),
                "enabled": True,
            },
            "model_endpoints": self._model_endpoints(),
        }

    def set_leaderboard_model(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("leaderboard model settings must be a JSON object")
        base_url, api_key = self._resolve_endpoint_credentials(payload, "leaderboard")
        settings = self.leaderboard_service.configure_verified(
            model=payload.get("model"),
            effort="none",
            base_url=base_url,
            api_key=api_key,
        )
        self._leaderboard_model_configured = True
        self._activate_endpoint("leaderboard", settings)
        return {
            "ok": True,
            "leaderboard_llm": {
                **self.leaderboard_service.settings_payload(settings),
                "enabled": True,
            },
            "model_endpoints": self._model_endpoints(),
        }

    def set_image_model(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("image model settings must be a JSON object")
        base_url, api_key = self._resolve_endpoint_credentials(payload, "image")
        if self.image_generator is not None:
            settings = self.image_service.configure(
                model=str(payload.get("model") or "image"),
                effort="none",
                base_url=base_url,
                api_key=api_key,
            )
        else:
            settings = self.image_service.configure_verified_image(
                model=payload.get("model"),
                base_url=base_url,
                api_key=api_key,
            )
        self._image_model_configured = True
        self._activate_endpoint("image", settings)
        return {
            "ok": True,
            "image_llm": {
                **self.image_service.settings_payload(settings),
                "enabled": True,
            },
            "model_endpoints": self._model_endpoints(),
        }

    def github_weekly(self) -> dict[str, object]:
        snapshot = self.database.get_github_weekly()
        if snapshot is None:
            return {
                "ok": True,
                "week_start": week_window_start(),
                "fetched_at": "",
                "repos": [],
                "xhs_title": XHS_TITLE,
                "xhs_body": "",
                "model_used": "",
                "images": [],
                "visual": {},
                "count": 0,
            }
        return {"ok": True, "count": len(snapshot["repos"]), **snapshot}

    def github_weekly_refresh(self) -> dict[str, object]:
        repos = fetch_weekly_ai_repos(getter=self.github_fetcher)
        model_used = ""
        if self._leaderboard_model_configured:
            try:
                repos = self.leaderboard_service.enrich_github_repos(repos)
                model_used = self.leaderboard_service.settings.model
            except LLMError:
                model_used = ""
        title, body = build_xhs_copy(repos)
        images = build_weekly_image_jobs(repos)
        saved = self.database.save_github_weekly(
            week_window_start(), repos, title, body, model_used, images
        )
        return {"ok": True, "count": len(repos), **saved}

    def github_weekly_render(self, payload: object) -> dict[str, object]:
        snapshot = self.database.get_github_weekly()
        if snapshot is None or not snapshot.get("repos"):
            raise ValueError("github_weekly_empty")
        body = payload if isinstance(payload, dict) else {}
        theme = "light" if str(body.get("theme") or "").strip().lower() == "light" else "dark"
        palette = parse_palette(body.get("palette"))
        repos = list(snapshot["repos"])
        jobs = list(snapshot.get("images") or []) or build_weekly_image_jobs(repos)
        generate = self.image_service.generate_image if self._image_model_configured else None
        if self.visual_renderer is None:
            images = render_weekly_visual(
                repos,
                jobs,
                self.packages_dir / "github-weekly",
                theme=theme,
                palette=palette,
                generate_image=generate,
            )
        else:
            images = self.visual_renderer(
                repos,
                jobs,
                self.packages_dir / "github-weekly",
                theme=theme,
                palette=palette,
            )
        visual = {"theme": theme, "palette": palette}
        saved = self.database.save_github_weekly(
            str(snapshot["week_start"]),
            repos,
            str(snapshot["xhs_title"]),
            str(snapshot["xhs_body"]),
            str(snapshot.get("model_used") or ""),
            images,
            visual=visual,
        )
        return {"ok": True, "count": len(repos), **saved}

    def _skill_llm(self):
        if self.skill_complete is not None:
            return self.skill_complete
        if not self._article_model_configured:
            return None

        def complete(prompt: str) -> str:
            return self.llm_service._run(prompt, self.llm_service.settings)

        return complete

    def _merge_latest_skill_fields(self, snapshot: dict[str, object]) -> dict[str, object]:
        latest = self.database.get_skill_finder() or {}
        incoming = snapshot.get("article") if isinstance(snapshot.get("article"), dict) else {}
        latest_article = latest.get("article") if isinstance(latest.get("article"), dict) else {}
        if str(latest_article.get("body") or "").strip() and not str(incoming.get("body") or "").strip():
            snapshot["article"] = dict(latest_article)
            title = str(latest_article.get("title") or "").strip()
            if title:
                snapshot["title"] = title
        latest_images = latest.get("images")
        if isinstance(latest_images, list) and latest_images and not snapshot.get("images"):
            snapshot["images"] = list(latest_images)
        if isinstance(latest.get("visual"), dict) and not snapshot.get("visual"):
            snapshot["visual"] = dict(latest["visual"])
        latest_phase = str(latest.get("phase") or "")
        if latest_phase in {"rendering", "done"} and snapshot.get("phase") not in {"error", "done"}:
            snapshot["phase"] = latest_phase
        return snapshot

    def _restore_skill_article_from_package(self, snapshot: dict[str, object]) -> dict[str, object]:
        article = snapshot.get("article") if isinstance(snapshot.get("article"), dict) else {}
        if str(article.get("body") or "").strip():
            return snapshot
        package_path = Path(str(snapshot.get("package_path") or ""))
        restored: dict[str, str] | None = None
        index_path = package_path / "index.json"
        if index_path.is_file():
            try:
                packed = json.loads(index_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                packed = {}
            packed_article = packed.get("article") if isinstance(packed, dict) else None
            if isinstance(packed_article, dict) and str(packed_article.get("body") or "").strip():
                restored = {
                    "title": str(packed_article.get("title") or snapshot.get("title") or "").strip(),
                    "body": str(packed_article.get("body") or "").strip(),
                }
        if restored is None:
            article_md = package_path / "article.md"
            if article_md.is_file():
                try:
                    text = article_md.read_text(encoding="utf-8").strip()
                except OSError:
                    text = ""
                if text:
                    title = str(snapshot.get("title") or "")
                    body = text
                    if text.startswith("# "):
                        first, _, rest = text.partition("\n")
                        title = first[2:].strip() or title
                        body = rest.strip()
                    restored = {"title": title, "body": body}
        if restored is None:
            return snapshot
        snapshot["article"] = restored
        if restored.get("title"):
            snapshot["title"] = restored["title"]
        self.database.save_skill_finder(snapshot)
        return snapshot

    def skills_snapshot(self) -> dict[str, object]:
        snapshot = self.database.get_skill_finder()
        if snapshot is None:
            return {
                "ok": True,
                "query": "",
                "title": "",
                "theme": "",
                "stages": [],
                "skills": [],
                "article": {"title": "", "body": ""},
                "package_path": "",
                "images": [],
                "phase": "",
                "count": 0,
            }
        snapshot = self._restore_skill_article_from_package(dict(snapshot))
        skills = snapshot.get("skills") if isinstance(snapshot.get("skills"), list) else []
        body = {"ok": True, "count": len(skills), **snapshot}
        body.setdefault("phase", "")
        return body

    def skills_search(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("query must be 1-200 characters")
        if payload.get("abort"):
            cancel = getattr(self, "_skill_cancel", None)
            if isinstance(cancel, threading.Event):
                cancel.set()
            snapshot = self.database.get_skill_finder() or {}
            snapshot = dict(snapshot)
            if snapshot.get("phase") in {"searching", "rendering"}:
                snapshot["phase"] = "error"
                snapshot["error_reason"] = "已停止"
                snapshot = self.database.save_skill_finder(snapshot)
            skills = snapshot.get("skills") if isinstance(snapshot.get("skills"), list) else []
            return {"ok": True, "count": len(skills), **snapshot}
        if not isinstance(payload.get("query"), str):
            raise ValueError("query must be 1-200 characters")
        query = payload["query"].strip()
        if not query or len(query) > 200:
            raise ValueError("query must be 1-200 characters")
        complete = self._skill_llm()
        if complete is None:
            raise LLMError("skill_search_failed", "模型未配置", cause_code="llm_not_configured")
        previous = self.database.get_skill_finder()
        cancel = threading.Event()
        self._skill_cancel = cancel
        seed = {
            "query": query,
            "title": query,
            "theme": query,
            "stages": [],
            "skills": [],
            "article": {"title": "", "body": ""},
            "images": [],
            "package_path": "",
            "phase": "searching",
        }
        saved = self.database.save_skill_finder(seed)
        persist_lock = getattr(self, "_skill_persist_lock", None)
        if persist_lock is None:
            persist_lock = threading.Lock()
            self._skill_persist_lock = persist_lock

        def persist(kind: str, data: dict[str, object]) -> None:
            if cancel.is_set() and kind != "error":
                return
            body = dict(data)
            with persist_lock:
                self._merge_latest_skill_fields(body)
                if kind == "error":
                    body["phase"] = "error"
                elif body.get("phase") not in {"rendering", "done"}:
                    if kind in {"skills_ready", "article"}:
                        body["phase"] = "skills_ready"
                    elif str(body.get("phase") or "") in {
                        "understanding",
                        "chain",
                        "decompose",
                        "keywords",
                        "search",
                        "group",
                        "compose",
                    }:
                        pass
                    else:
                        body["phase"] = "searching"
                self.database.save_skill_finder(body)

        def run() -> None:
            try:
                result = find_skills(
                    query,
                    complete=complete,
                    github_get=self.github_fetcher,
                    web_search=self.skill_web_search,
                    output_root=self.packages_dir.parent / "skills",
                    on_event=persist,
                    previous=previous,
                    cancel=cancel.is_set,
                )
                result = dict(result)
                with persist_lock:
                    self._merge_latest_skill_fields(result)
                    if cancel.is_set():
                        result["phase"] = "error"
                        result["error_reason"] = "已停止"
                    elif result.get("phase") not in {"skills_ready", "done", "error", "rendering"}:
                        result["phase"] = "skills_ready"
                    self.database.save_skill_finder(result)
            except LLMError as exc:
                failed = dict(self.database.get_skill_finder() or saved)
                failed["phase"] = "error"
                failed["error"] = exc.code
                failed["error_reason"] = exc.reason
                with persist_lock:
                    self.database.save_skill_finder(failed)
            except Exception as exc:
                failed = dict(self.database.get_skill_finder() or saved)
                failed["phase"] = "error"
                failed["error"] = type(exc).__name__
                failed["error_reason"] = str(exc)
                with persist_lock:
                    self.database.save_skill_finder(failed)

        thread = threading.Thread(target=run, daemon=True)
        self._skill_thread = thread
        thread.start()
        return self.skills_snapshot()

    def skills_render(self, payload: object) -> dict[str, object]:
        snapshot = self.database.get_skill_finder()
        if snapshot is None:
            raise ValueError("skill_package_empty")
        body = payload if isinstance(payload, dict) else {}
        theme = "light" if str(body.get("theme") or "").strip().lower() == "light" else "dark"
        palette = parse_palette(body.get("palette")) if body.get("palette") is not None else None
        package_path = Path(str(snapshot.get("package_path") or self.packages_dir.parent / "skills" / "latest"))
        images_dir = package_path / "images"
        http_dir = self.packages_dir / "skills"
        generate = self.image_service.generate_image if self._image_model_configured else None
        snapshot = dict(snapshot)
        persist_lock = getattr(self, "_skill_persist_lock", None)
        if persist_lock is None:
            persist_lock = threading.Lock()
            self._skill_persist_lock = persist_lock
        snapshot["phase"] = "rendering"
        with persist_lock:
            self._merge_latest_skill_fields(snapshot)
            snapshot["phase"] = "rendering"
            self.database.save_skill_finder(snapshot)

        def publish_images(images: list[dict[str, object]]) -> None:
            http_dir.mkdir(parents=True, exist_ok=True)
            for image in images:
                filename = str(image.get("file") or f"{image.get('id')}.png")
                source = images_dir / filename
                if source.is_file():
                    target = http_dir / filename
                    target.write_bytes(source.read_bytes())
                image["url"] = f"/api/generated/skills/{filename}"
            snapshot["images"] = list(images)
            snapshot["phase"] = "rendering"
            with persist_lock:
                self._merge_latest_skill_fields(snapshot)
                snapshot["images"] = list(images)
                snapshot["phase"] = "rendering"
                self.database.save_skill_finder(snapshot)

        def on_image(image: dict[str, object]) -> None:
            current = list(snapshot.get("images") or [])
            replaced = False
            for index, row in enumerate(current):
                if str(row.get("id") or "") == str(image.get("id") or ""):
                    current[index] = image
                    replaced = True
                    break
            if not replaced:
                current.append(image)
            publish_images(current)

        images = render_skill_package(
            snapshot,
            images_dir,
            theme=theme,
            palette=palette,
            screenshot_fn=self.skill_screenshot,
            visual_renderer=self.visual_renderer,
            generate_image=generate,
            on_image=on_image,
        )
        http_dir.mkdir(parents=True, exist_ok=True)
        for image in images:
            filename = str(image.get("file") or f"{image.get('id')}.png")
            source = images_dir / filename
            if source.is_file():
                target = http_dir / filename
                target.write_bytes(source.read_bytes())
            image["url"] = f"/api/generated/skills/{filename}"
        snapshot["images"] = images
        snapshot["visual"] = {"theme": theme, "palette": palette or {}}
        snapshot["phase"] = "done"
        with persist_lock:
            self._merge_latest_skill_fields(snapshot)
            snapshot["images"] = images
            snapshot["visual"] = {"theme": theme, "palette": palette or {}}
            snapshot["phase"] = "done"
            saved = self.database.save_skill_finder(snapshot)
        skills = saved.get("skills") if isinstance(saved.get("skills"), list) else []
        return {"ok": True, "count": len(skills), **saved}

    def github_weekly_image(self, image_id: str, payload: object = None) -> dict[str, object]:
        snapshot = self.database.get_github_weekly()
        if snapshot is None:
            raise ValueError("github_weekly_empty")
        images = list(snapshot.get("images") or [])
        match = next((item for item in images if str(item.get("id")) == image_id), None)
        if match is None:
            raise KeyError(image_id)
        body = payload if isinstance(payload, dict) else {}
        visual = snapshot.get("visual") if isinstance(snapshot.get("visual"), dict) else {}
        if body.get("theme") is not None or body.get("palette") is not None:
            theme = (
                "light"
                if str(body.get("theme") or visual.get("theme") or "").strip().lower() == "light"
                else "dark"
            )
            palette = parse_palette(
                body.get("palette") if body.get("palette") is not None else visual.get("palette")
            )
            visual = {"theme": theme, "palette": palette}
        else:
            theme = "light" if str(visual.get("theme") or "").strip().lower() == "light" else "dark"
            palette = parse_palette(visual.get("palette"))
        generate = self.image_service.generate_image if self._image_model_configured else None
        if self.visual_renderer is None:
            rendered = render_weekly_visual(
                list(snapshot["repos"]),
                [match],
                self.packages_dir / "github-weekly",
                theme=theme,
                palette=palette,
                generate_image=generate,
            )
        else:
            rendered = self.visual_renderer(
                list(snapshot["repos"]),
                [match],
                self.packages_dir / "github-weekly",
                theme=theme,
                palette=palette,
            )
        if not rendered:
            raise ValueError("image_generation_failed")
        updated = []
        for item in images:
            if str(item.get("id")) == image_id:
                updated.append(rendered[0])
            else:
                updated.append(item)
        saved = self.database.save_github_weekly(
            str(snapshot["week_start"]),
            list(snapshot["repos"]),
            str(snapshot["xhs_title"]),
            str(snapshot["xhs_body"]),
            str(snapshot.get("model_used") or ""),
            updated,
            visual=visual if isinstance(visual, dict) else {},
        )
        return {"ok": True, **rendered[0], "count": len(saved["repos"])}

    def generated_image(self, name: str, collection: str = "github-weekly") -> tuple[bytes, str]:
        safe = Path(name).name
        if safe != name or not safe.endswith(".png"):
            raise ValueError("image_url_invalid")
        folder = "skills" if collection == "skills" else "github-weekly"
        path = (self.packages_dir / folder / safe).resolve()
        root = (self.packages_dir / folder).resolve()
        if root not in path.parents and path != root / safe:
            raise ValueError("image_url_invalid")
        if not path.is_file() and folder == "skills":
            snapshot = self.database.get_skill_finder()
            package = Path(str((snapshot or {}).get("package_path") or ""))
            fallback = (package / "images" / safe).resolve()
            if package.as_posix() and fallback.is_file():
                path = fallback
        if not path.is_file():
            raise KeyError(name)
        return path.read_bytes(), "image/png"

    def delete_model_endpoint(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict) or not isinstance(payload.get("endpoint_id"), str) or not payload["endpoint_id"].strip():
            raise ValueError("endpoint_id required")
        endpoint_id = payload["endpoint_id"].strip()
        if self.database.get_model_endpoint(endpoint_id) is None:
            raise KeyError(endpoint_id)
        for purpose, service in (
            ("article", self.llm_service),
            ("translation", self.translation_service),
            ("chat", self.chat_service),
            ("leaderboard", self.leaderboard_service),
            ("image", self.image_service),
        ):
            mapping = self.database.get_model_purpose(purpose)
            if mapping is not None and str(mapping["endpoint_id"]) == endpoint_id:
                service.configure(
                    model=LLM_MODEL,
                    provider=LLM_PROVIDER,
                    effort=LLM_EFFORT,
                    base_url="",
                    api_key="",
                )
                if purpose == "article":
                    self._article_model_configured = False
                    self.article_models = []
                elif purpose == "translation":
                    self._translation_model_configured = False
                    self.hotspots.llm_service = None
                elif purpose == "leaderboard":
                    self._leaderboard_model_configured = False
                elif purpose == "image":
                    self._image_model_configured = False
        self.credential_store.delete(endpoint_id)
        self.database.delete_model_endpoint(endpoint_id)
        return {
            "ok": True,
            "llm": self.llm_service.settings_payload(self.llm_service.settings),
            "chat_llm": (
                self.chat_service.settings_payload(self.chat_service.settings)
                if self.chat_service.settings.base_url
                else {"model": "", "base_url": "", "configured": False}
            ),
            "translation_llm": (
                {
                    **self.translation_service.settings_payload(
                        self.translation_service.settings
                    ),
                    "enabled": True,
                }
                if self._translation_model_configured
                else {"model": "", "base_url": "", "configured": False, "enabled": False}
            ),
            "leaderboard_llm": (
                {
                    **self.leaderboard_service.settings_payload(
                        self.leaderboard_service.settings
                    ),
                    "enabled": True,
                }
                if self._leaderboard_model_configured
                else {"model": "", "base_url": "", "configured": False, "enabled": False}
            ),
            "model_endpoints": self._model_endpoints(),
        }

    def chat(self, messages: object, model: str | None = None) -> dict[str, object]:
        content = self.chat_service.chat(validate_chat_messages(messages), model=model)
        return {"ok": True, "message": {"role": "assistant", "content": content}}

    def set_style(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict) or not isinstance(payload.get("style"), str):
            raise ValueError("style must be a string")
        style = payload["style"].strip()
        if len(style) > 50_000:
            raise ValueError("style must be at most 50000 characters")
        self.article_style = style
        return {"ok": True, "style": style}

    def set_config(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("config must be a JSON object")
        platform = payload.get("platform")
        if platform == "wechat":
            required = ("app_id", "app_secret")
            missing = [
                field
                for field in required
                if not isinstance(payload.get(field), str) or not payload[field]
            ]
            if missing:
                raise ValueError(f"wechat config missing: {', '.join(missing)}")
            thumb_media_id = payload.get("thumb_media_id", "")
            if thumb_media_id is None:
                thumb_media_id = ""
            if not isinstance(thumb_media_id, str):
                raise ValueError("thumb_media_id must be a string")
            self.wechat_config = {
                "app_id": payload["app_id"],
                "app_secret": payload["app_secret"],
                "thumb_media_id": thumb_media_id,
                "author": str(payload.get("author", "")),
            }
            self._store_account("wechat", self.wechat_config)
            return {
                "ok": True,
                "platform": "wechat",
                "configured": True,
            }
        if platform == "xiaohongshu":
            account_name = payload.get("account_name", "")
            if not isinstance(account_name, str) or len(account_name) > 100:
                raise ValueError("xiaohongshu account_name must be at most 100 characters")
            creator_url = payload.get("creator_url", XIAOHONGSHU_CREATOR_URL)
            if not isinstance(creator_url, str) or not creator_url.startswith("https://"):
                raise ValueError("xiaohongshu creator_url must be an HTTPS URL")
            self.xiaohongshu_config = {
                "creator_url": creator_url,
                "account_name": account_name.strip(),
            }
            self._store_account("xiaohongshu", self.xiaohongshu_config)
            return {"ok": True, "platform": "xiaohongshu", "configured": True}
        if platform == "x":
            token = payload.get("bearer_token", "")
            if not isinstance(token, str) or not token.strip():
                raise ValueError("x bearer_token required")
            self.x_bearer_token = token.strip()
            self.hotspots.x_bearer_token = self.x_bearer_token
            self._store_account("x", {"bearer_token": self.x_bearer_token})
            return {"ok": True, "platform": "x", "configured": True}
        raise ValueError(f"unsupported platform: {platform}")

    def delete_config(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("config must be a JSON object")
        platform = payload.get("platform")
        if platform not in ACCOUNT_STORE_IDS:
            raise ValueError(f"unsupported platform: {platform}")
        self.credential_store.delete(ACCOUNT_STORE_IDS[platform])
        if platform == "wechat":
            self.wechat_config = None
        elif platform == "xiaohongshu":
            self.xiaohongshu_config = {
                "creator_url": XIAOHONGSHU_CREATOR_URL,
                "account_name": "",
            }
        else:
            self.x_bearer_token = ""
            self.hotspots.x_bearer_token = ""
        return {"ok": True, "platform": platform, "configured": False}

    def publish(self, draft_id: str, platform: str, live: bool = False) -> dict[str, object]:
        with self._publish_lock:
            return self._publish_locked(draft_id, platform, live)

    def _publish_locked(
        self, draft_id: str, platform: str, live: bool = False
    ) -> dict[str, object]:
        draft = self.database.get_draft(draft_id)
        if str(draft["platform"]) != platform:
            raise ValueError("platform_mismatch")
        if not self.database.is_current_draft(draft_id):
            raise ValueError("draft_superseded")
        if draft["status"] != "APPROVED":
            raise ValueError("draft_not_approved")
        if self.database.get_event(str(draft["event_id"]))["status"] != "APPROVED":
            raise ValueError("event_not_approved")
        if platform == "xiaohongshu":
            result = PublicationService(self.database, self.packages_dir, dry_run=True).publish(draft_id)
            return {
                "ok": True,
                "manual_required": True,
                "creator_url": self.xiaohongshu_config["creator_url"],
                "package_path": str(result.package_path),
                "archive_path": str(result.archive_path),
                "status": result.status,
            }
        if not live:
            result = PublicationService(self.database, self.packages_dir, dry_run=True).publish(draft_id)
            return {
                "ok": True,
                "status": result.status,
                "package_path": str(result.package_path),
                "archive_path": str(result.archive_path),
            }
        publisher = self.wechat_publisher
        if publisher is None:
            raise WechatConfigurationRequired("wechat_configuration_required")
        archive_path = PublicationService(
            self.database, self.packages_dir, dry_run=True
        ).archive_draft(draft_id)
        attempt_id = self.database.publication_attempt_id(
            draft_id, str(draft["content_hash"]), False
        )
        existing = self.database.get_publication_attempt(attempt_id)
        if existing and existing["status"] in {"SUBMITTED", "DRAFT_SAVED"}:
            return {
                "ok": True,
                "status": existing["status"],
                "reference": str(existing["response_reference"]),
                "archive_path": str(archive_path),
            }
        outcome = publisher.publish(draft)
        self.database.record_publication_attempt(
            attempt_id,
            draft_id,
            "wechat",
            False,
            str(outcome["status"]),
            None,
            0,
            response_reference=str(outcome["reference"]),
        )
        return {
            "ok": True,
            "status": outcome["status"],
            "reference": outcome["reference"],
            "archive_path": str(archive_path),
        }

    def schedule_publish(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict):
            raise ValueError("schedule payload must be a JSON object")
        draft_id = payload.get("draft_id")
        platform = payload.get("platform")
        run_at = payload.get("run_at")
        live = payload.get("live", False)
        if not isinstance(draft_id, str) or not draft_id:
            raise ValueError("draft_id required")
        if not isinstance(platform, str) or not platform:
            raise ValueError("platform required")
        if not isinstance(live, bool):
            raise ValueError("live must be boolean")
        if not isinstance(run_at, str):
            raise ValueError("run_at required")
        draft = self.database.get_draft(draft_id)
        if str(draft["platform"]) != platform:
            raise ValueError("platform_mismatch")
        if not self.database.is_current_draft(draft_id):
            raise ValueError("draft_superseded")
        if draft["status"] != "APPROVED":
            raise ValueError("draft_not_approved")
        normalized = parse_run_at(run_at)
        job = self.database.create_scheduled_job(draft_id, platform, live, normalized)
        return {
            "ok": True,
            "job_id": job["job_id"],
            "draft_id": draft_id,
            "platform": platform,
            "live": live,
            "run_at": job["run_at"],
            "status": job["status"],
        }

    def list_schedule(self) -> dict[str, object]:
        jobs = []
        for job in self.database.list_scheduled_jobs():
            jobs.append(
                {
                    "job_id": job["job_id"],
                    "draft_id": job["draft_id"],
                    "platform": job["platform"],
                    "live": bool(job["live"]),
                    "run_at": job["run_at"],
                    "status": job["status"],
                    "error_message": job["error_message"],
                }
            )
        return {"ok": True, "jobs": jobs}

    def cancel_schedule(self, payload: object) -> dict[str, object]:
        if not isinstance(payload, dict) or not isinstance(payload.get("job_id"), str):
            raise ValueError("job_id required")
        job = self.database.cancel_scheduled_job(payload["job_id"])
        return {"ok": True, "job_id": job["job_id"], "status": job["status"]}


def _make_handler(app: WebApp) -> type[BaseHTTPRequestHandler]:
    class ApiHandler(BaseHTTPRequestHandler):
        def _send_json(self, code: int, payload: object) -> None:
            body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _read_json_body(self) -> object:
            length = int(self.headers.get("Content-Length") or 0)
            max_bytes = (
                MAX_CHAT_JSON_BODY_BYTES if self.path == "/api/chat" else MAX_JSON_BODY_BYTES
            )
            if length < 0 or length > max_bytes:
                raise ValueError("request_body_too_large")
            raw = self.rfile.read(length) if length else b""
            if not raw:
                return {}
            try:
                return json.loads(raw.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise ValueError("invalid_json") from exc

        @staticmethod
        def _require_string(payload: object, field: str) -> str:
            if not isinstance(payload, dict) or not isinstance(payload.get(field), str):
                raise ValueError(f"{field} required")
            return payload[field]

        def do_GET(self) -> None:
            try:
                if urlsplit(self.path).path == "/":
                    body = INDEX_HTML.encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                if self.path == "/api/status":
                    self._send_json(200, app.status())
                    return
                if self.path == "/api/github-weekly":
                    self._send_json(200, app.github_weekly())
                    return
                if self.path == "/api/skills":
                    self._send_json(200, app.skills_snapshot())
                    return
                if self.path == "/api/favorites":
                    self._send_json(200, app.list_favorites())
                    return
                parsed = urlsplit(self.path)
                if parsed.path == "/api/hotspots":
                    raw_hours = (parse_qs(parsed.query).get("hours") or ["4"])[0]
                    try:
                        hours = int(raw_hours)
                    except ValueError as exc:
                        raise ValueError("hours must be an integer") from exc
                    if hours < HOTSPOT_HOUR_MIN or hours > HOTSPOT_HOUR_MAX:
                        raise ValueError(
                            f"hours must be between {HOTSPOT_HOUR_MIN} and {HOTSPOT_HOUR_MAX}"
                        )
                    translate_flag = (parse_qs(parsed.query).get("translate") or ["0"])[0]
                    translate = translate_flag.lower() in {"1", "true", "yes"}
                    lane = (parse_qs(parsed.query).get("lane") or ["hotspots"])[0]
                    if lane not in {"hotspots", "viewpoints"}:
                        raise ValueError("lane must be hotspots or viewpoints")
                    self._send_json(
                        200, app.hotspots_window(hours, translate=translate, lane=lane)
                    )
                    return
                if parsed.path == "/api/schedule":
                    self._send_json(200, app.list_schedule())
                    return
                if parsed.path.startswith("/api/generated/github-weekly/"):
                    name = parsed.path.rsplit("/", 1)[-1]
                    data, content_type = app.generated_image(name)
                    self.send_response(200)
                    self.send_header("Content-Type", content_type)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if parsed.path.startswith("/api/generated/skills/"):
                    name = parsed.path.rsplit("/", 1)[-1]
                    data, content_type = app.generated_image(name, "skills")
                    self.send_response(200)
                    self.send_header("Content-Type", content_type)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if parsed.path == "/api/image-proxy":
                    url = (parse_qs(parsed.query).get("url") or [""])[0]
                    data, content_type = app.proxy_image(url)
                    self.send_response(200)
                    self.send_header("Content-Type", content_type)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "private, max-age=300")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                raise KeyError(self.path)
            except KeyError as exc:
                self._send_json(404, {"ok": False, "error": f"not_found:{exc}", "error_type": "KeyError"})
            except ValueError as exc:
                self._send_json(400, {"ok": False, "error": str(exc), "error_type": "ValueError"})
            except Exception as exc:
                self._send_json(500, {"ok": False, "error": str(exc), "error_type": type(exc).__name__})

        def do_POST(self) -> None:
            try:
                if self.headers.get_content_type() != "application/json":
                    raise ValueError("content_type_must_be_application_json")
                origin = self.headers.get("Origin")
                if origin:
                    try:
                        parsed_origin = urlsplit(origin)
                        origin_port = parsed_origin.port or (443 if parsed_origin.scheme == "https" else 80)
                    except ValueError:
                        parsed_origin = None
                        origin_port = None
                    if (
                        parsed_origin is None
                        or parsed_origin.scheme != "http"
                        or parsed_origin.hostname not in ALLOWED_HOSTS
                        or origin_port != self.server.server_port
                    ):
                        self._send_json(
                            403,
                            {
                                "ok": False,
                                "error": "cross_origin_request_rejected",
                                "error_type": "PermissionError",
                            },
                        )
                        return
                payload = self._read_json_body()
                if self.path == "/api/collect":
                    hours = payload.get("hours", 4) if isinstance(payload, dict) else 4
                    if isinstance(hours, bool) or not isinstance(hours, int):
                        raise ValueError("hours must be an integer")
                    if hours < HOTSPOT_HOUR_MIN or hours > HOTSPOT_HOUR_MAX:
                        raise ValueError(
                            f"hours must be between {HOTSPOT_HOUR_MIN} and {HOTSPOT_HOUR_MAX}"
                        )
                    force = payload.get("force", True) if isinstance(payload, dict) else True
                    if not isinstance(force, bool):
                        raise ValueError("force must be boolean")
                    source_id = payload.get("source_id") if isinstance(payload, dict) else None
                    if source_id is not None and (
                        not isinstance(source_id, str) or not source_id.strip()
                    ):
                        raise ValueError("source_id must be a non-empty string")
                    lane = payload.get("lane", "hotspots") if isinstance(payload, dict) else "hotspots"
                    if lane not in {"hotspots", "viewpoints"}:
                        raise ValueError("lane must be hotspots or viewpoints")
                    result = app.collect(
                        hours,
                        force=force,
                        source_id=source_id.strip() if source_id else None,
                        lane=lane,
                    )
                elif self.path == "/api/hooks/find":
                    result = app.find_hooks(self._require_string(payload, "item_id"))
                elif self.path == "/api/original":
                    result = app.original(self._require_string(payload, "item_id"))
                elif self.path == "/api/original/translate":
                    result = app.translate_original(self._require_string(payload, "item_id"))
                elif self.path == "/api/favorites":
                    result = app.add_favorite(self._require_string(payload, "item_id"))
                elif self.path == "/api/articles":
                    item_ids = payload.get("item_ids") if isinstance(payload, dict) else None
                    if item_ids is not None:
                        if not isinstance(item_ids, list) or any(
                            not isinstance(value, str) for value in item_ids
                        ):
                            raise ValueError("item_ids must be a list of strings")
                    item_id = payload.get("item_id") if isinstance(payload, dict) else None
                    if isinstance(item_ids, list) and [
                        value.strip() for value in item_ids if value.strip()
                    ]:
                        if not isinstance(item_id, str) or not item_id.strip():
                            item_id = sorted(
                                {value.strip() for value in item_ids if value.strip()}
                            )[0]
                    else:
                        item_ids = None
                        item_id = self._require_string(payload, "item_id")
                    result = app.articles(
                        item_id,
                        self._require_string(payload, "platform"),
                        payload.get("model") if isinstance(payload, dict) else None,
                        payload.get("provider") if isinstance(payload, dict) else None,
                        payload.get("effort") if isinstance(payload, dict) else None,
                        payload.get("chosen_hooks") if isinstance(payload, dict) else None,
                        payload.get("prompt_style", DEFAULT_ARTICLE_PROMPT_STYLE)
                        if isinstance(payload, dict)
                        else DEFAULT_ARTICLE_PROMPT_STYLE,
                        item_ids,
                    )
                elif self.path == "/api/config":
                    result = app.set_config(payload)
                elif self.path == "/api/config/delete":
                    result = app.delete_config(payload)
                elif self.path == "/api/model":
                    result = app.set_model(payload)
                elif self.path == "/api/models":
                    result = app.models(payload)
                elif self.path == "/api/chat/model":
                    result = app.set_chat_model(payload)
                elif self.path == "/api/github-weekly":
                    result = app.github_weekly_refresh()
                elif self.path == "/api/github-weekly/render":
                    result = app.github_weekly_render(payload)
                elif self.path == "/api/github-weekly/image":
                    result = app.github_weekly_image(self._require_string(payload, "id"), payload)
                elif self.path == "/api/skills/search":
                    result = app.skills_search(payload)
                elif self.path == "/api/skills/render":
                    result = app.skills_render(payload)
                elif self.path == "/api/image/model":
                    result = app.set_image_model(payload)
                elif self.path == "/api/leaderboard/model":
                    result = app.set_leaderboard_model(payload)
                elif self.path == "/api/translation/model":
                    result = app.set_translation_model(payload)
                elif self.path == "/api/model-endpoints/delete":
                    result = app.delete_model_endpoint(payload)
                elif self.path == "/api/chat":
                    result = app.chat(
                        payload.get("messages") if isinstance(payload, dict) else None,
                        payload.get("model") if isinstance(payload, dict) else None,
                    )
                elif self.path == "/api/style":
                    result = app.set_style(payload)
                elif self.path == "/api/articles/images":
                    result = app.update_article_images(payload)
                elif self.path == "/api/articles/images/rescan":
                    result = app.rescan_article_images(payload)
                elif self.path == "/api/articles/edit":
                    result = app.edit_article(
                        self._require_string(payload, "draft_id"),
                        self._require_string(payload, "title"),
                        self._require_string(payload, "body"),
                    )
                elif self.path == "/api/approve":
                    result = app.approve(
                        self._require_string(payload, "draft_id"),
                        self._require_string(payload, "reviewer"),
                    )
                elif self.path == "/api/publish":
                    if not isinstance(payload, dict):
                        raise ValueError("publish payload must be a JSON object")
                    live = payload.get("live", False)
                    if not isinstance(live, bool):
                        raise ValueError("live must be boolean")
                    result = app.publish(
                        self._require_string(payload, "draft_id"),
                        self._require_string(payload, "platform"),
                        live=live,
                    )
                elif self.path == "/api/schedule":
                    result = app.schedule_publish(payload)
                elif self.path == "/api/schedule/cancel":
                    result = app.cancel_schedule(payload)
                else:
                    raise KeyError(self.path)
                self._send_json(200, result)
            except KeyError as exc:
                self._send_json(404, {"ok": False, "error": f"not_found:{exc}", "error_type": "KeyError"})
            except (ValueError, PublicationError) as exc:
                self._send_json(400, {"ok": False, "error": str(exc), "error_type": type(exc).__name__})
            except LLMError as exc:
                self._send_json(
                    502,
                    {
                        "ok": False,
                        "error": exc.code,
                        "error_code": exc.cause_code or exc.code,
                        "error_reason": exc.reason,
                        "error_type": "LLMError",
                    },
                )
            except Exception as exc:
                self._send_json(500, {"ok": False, "error": str(exc), "error_type": type(exc).__name__})

        def do_DELETE(self) -> None:
            try:
                if self.headers.get_content_type() != "application/json":
                    raise ValueError("content_type_must_be_application_json")
                origin = self.headers.get("Origin")
                if origin:
                    try:
                        parsed_origin = urlsplit(origin)
                        origin_port = parsed_origin.port or (443 if parsed_origin.scheme == "https" else 80)
                    except ValueError:
                        parsed_origin = None
                        origin_port = None
                    if (
                        parsed_origin is None
                        or parsed_origin.scheme != "http"
                        or parsed_origin.hostname not in ALLOWED_HOSTS
                        or origin_port != self.server.server_port
                    ):
                        self._send_json(
                            403,
                            {
                                "ok": False,
                                "error": "cross_origin_request_rejected",
                                "error_type": "PermissionError",
                            },
                        )
                        return
                payload = self._read_json_body()
                if self.path == "/api/favorites":
                    result = app.delete_favorite(self._require_string(payload, "item_id"))
                else:
                    raise KeyError(self.path)
                self._send_json(200, result)
            except KeyError as exc:
                self._send_json(404, {"ok": False, "error": f"not_found:{exc}", "error_type": "KeyError"})
            except ValueError as exc:
                self._send_json(400, {"ok": False, "error": str(exc), "error_type": "ValueError"})
            except Exception as exc:
                self._send_json(500, {"ok": False, "error": str(exc), "error_type": type(exc).__name__})

        def log_message(self, format: str, *args: object) -> None:
            pass

    return ApiHandler


def create_server(app: WebApp, host: str = "127.0.0.1", port: int = 8080) -> ThreadingHTTPServer:
    if host not in ALLOWED_HOSTS:
        raise ValueError("web server host must be 127.0.0.1 or localhost")
    server = ThreadingHTTPServer((host, port), _make_handler(app))
    server.daemon_threads = True
    return server


def run_web(app: WebApp, host: str = "127.0.0.1", port: int = 8080) -> None:
    server = create_server(app, host, port)
    app.scheduler.start()
    try:
        server.serve_forever()
    finally:
        app.scheduler.stop()
        server.server_close()
