"""Skill-finder 大字报 cover: walnut frame, Songti, 1080×1440."""

from __future__ import annotations

import html
import tempfile
from pathlib import Path
from typing import Callable, Iterable

COVER_WIDTH = 1080
COVER_HEIGHT = 1440
ScreenshotFn = Callable[..., Path]


def skill_cover_html(
    title: str,
    theme: str = "",
    count: int = 0,
    stages: Iterable[str] | None = None,
) -> str:
    heading = html.escape((title or "").strip() or "Skill 查找结果")
    theme_text = html.escape((theme or "").strip() or "技能包")
    stage_list = [html.escape(str(item).strip()) for item in (stages or []) if str(item).strip()]
    stage_markup = "".join(f"<li>{item}</li>" for item in stage_list) or "<li>覆盖地图</li>"
    size = _title_size((title or "").strip() or "Skill 查找结果")
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{heading}</title>
<style>
html,body{{margin:0;width:{COVER_WIDTH}px;height:{COVER_HEIGHT}px;background:#3d2b1f;color:#fff}}
body{{display:flex;align-items:center;justify-content:center;font-family:"Songti SC","STSong","SimSun","Noto Serif SC",serif}}
.frame{{box-sizing:border-box;width:960px;height:1320px;border:10px solid #fff;display:flex;flex-direction:column;justify-content:space-between;padding:72px 64px}}
.kicker{{margin:0;letter-spacing:.28em;font-size:22px;font-weight:700}}
h1{{margin:48px 0 0;font-size:{size}px;line-height:1.15;letter-spacing:.12em;text-align:center;font-weight:700;word-break:break-word}}
.sub{{margin:28px 0 0;text-align:center;font-size:32px;letter-spacing:.08em}}
ul{{margin:0;padding:0;list-style:none;display:grid;grid-template-columns:1fr 1fr;gap:12px 28px;font-size:28px;letter-spacing:.06em}}
</style>
</head>
<body>
<div class="frame">
  <p class="kicker">SKILL 查找器</p>
  <div>
    <h1>{heading}</h1>
    <p class="sub">{theme_text} · {int(count)} 个技能</p>
  </div>
  <ul>{stage_markup}</ul>
</div>
</body>
</html>
"""


def render_skill_cover(
    title: str,
    theme: str = "",
    count: int = 0,
    stages: Iterable[str] | None = None,
    *,
    screenshot_fn: ScreenshotFn | None = None,
    tmp_dir: Path | None = None,
) -> bytes:
    from .visual.screenshot import screenshot_html

    shot = screenshot_fn or screenshot_html
    markup = skill_cover_html(title, theme, count, stages)
    if tmp_dir is None:
        with tempfile.TemporaryDirectory(prefix="autoposting-skill-cover-") as raw:
            return _write_and_shot(Path(raw), markup, shot)
    return _write_and_shot(Path(tmp_dir), markup, shot)


def _title_size(title: str) -> int:
    count = max(len(title), 1)
    if count <= 8:
        return 96
    if count <= 16:
        return 72
    if count <= 24:
        return 58
    return 46


def _write_and_shot(folder: Path, markup: str, shot: ScreenshotFn) -> bytes:
    folder.mkdir(parents=True, exist_ok=True)
    html_path = folder / "skill-cover.html"
    png_path = folder / "skill-cover.png"
    html_path.write_text(markup, encoding="utf-8")
    shot(html_path, png_path, width=COVER_WIDTH, height=COVER_HEIGHT)
    payload = png_path.read_bytes()
    if not payload:
        raise RuntimeError("skill_cover_empty")
    return payload
