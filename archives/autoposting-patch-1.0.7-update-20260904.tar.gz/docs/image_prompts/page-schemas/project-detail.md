# Page Schema · project-detail

回答：项目详情页由哪些组件组成、怎么排列？

## 用途

周榜中某一个仓库的详情卡片。

## 绑定内容

`ProjectContent`（`content-schemas/project.schema.json`）

## 结构

```
BrandHeader                 brand + issue
↓
Masthead
  左：RankBadge + CategoryTag
      HeroTitle (name + tagline)
      QuoteCard「一句话看懂」
  右：ProjectLogo（与左侧文字块同高）
↓
HeroVisual / StoryBoard     功能示意图：优先仓库 README 原图+说明，蛇形阅读；无图再模型补图
↓
FeatureList（每条先 SVG 图标再文字） | MetricPanel（Stars / 本周 / 类型）
↓
AudienceCard | URLCard
↓
Footer                      footer + pageNumber
```

## 布局规则

- 画布 9:16。功能示意图占据中部大部分面积。
- Logo 在右上，对齐主标题模块；无产品 logo 时用 3D 圆角图标代替。
- 「一句话看懂」在副标题下方，不在主视觉下面。
- 主视觉优先用模型生成的功能示意图；没有图时画 SVG 流程示意，不再留空光斑。

## 预留页面（未实现）

news-detail、tool-detail、comparison、data-insight、weekly-summary。新增时复制本文件结构，绑定新的 Content Schema，不要改 Design System。
