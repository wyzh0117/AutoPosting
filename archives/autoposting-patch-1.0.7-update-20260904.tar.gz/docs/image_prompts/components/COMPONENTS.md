# Component Library

回答：页面可以由哪些标准化视觉积木组成？

组件实现：`src/autoposting/visual/components.py`。样式引用 Design Token，不写某一期的项目数据。

| 组件 | 用途 | 必填 | 可选 | 结构 | 视觉规则 | 变体 / 溢出 |
|---|---|---|---|---|---|---|
| BrandHeader | 品牌条 | `brand` | `trailing`（期数） | 色块 + 词标 \| 右侧徽章 | 大写词标、12px 间距 | 无 |
| HeroTitle | 主标题 | `title` | `subtitle` | h1 + 副标题 | 最多两行，副标题单行省略 | ranking 76px / project 56px |
| IssueBadge | 期数胶囊 | `text` | | 描边 pill | 拉丁大写 | 文本过长省略 |
| CategoryTag | 分类 | `label` | | 描边 pill | 不强制英文大写 | 单行 |
| RankingItem | 榜单行 | `rank,name,description,metric` | `logo,progress` | 排名+Logo+文案+指标 | 内部紧凑，外缘圆角卡片 | 名称/介绍单行省略 |
| RankingBadge | 名次 | `rank` | | 两位数字 | 前三名高对比，其后降权 | `01` 格式 |
| ProjectLogo | 标识 | `name` | `src` | 56×56 圆角容器 | 无图则首字母 | `contain` |
| Metric | 数字 | `value` 或 `display` | `label` | 数字 + 标签 | 铜金色，compact-k | 右对齐 |
| ProgressBar | 相对热度 | `progress` 0–1 | | track + fill | 最小可视 8% | 不超出卡片 |
| QuoteCard | 一句话看懂 | `message` | `label` | 标签 + 段落 | 最多 3 行 | 超出 clamp |
| FeatureList | 能力列表 | `items[]` | | 圆点 + 文本 | 最多 5 条 | 多余删除 |
| FeatureItem | 单条能力 | `text` | | FeatureList 子项 | 与图标同视觉重量 | |
| AudienceCard | 适合人群 | `people[]` | | 标题 + 分隔文本 | 最多 4 个 | 过长换行 |
| URLCard | 项目地址 | `url` | `display` | 标题 + 单行 URL | 铜金、省略号 | 超 36 字裁切 |
| Footer | 来源/口号 | `text` | `pageNumber` | 左文案 \| 右页码 | 低对比 | |
| PageNumber | 页码 | `text` | | pill | `02 / 11` | |
| WorkflowDiagram | 流程 | `steps[]` | | 横排芯片 | 最多 5 步 | 换行 |
| HeroVisual / StoryBoard | 产品功能示意图（不是 repo logo） | | `src,story[]` | 蛇形图文格 | 优先原版截图+说明；无图再模型或 SVG | 占中部大部分 |
| MetricPanel | 核心指标 | `metrics[]` | `kind` | 数字 + 标签 | 替代工作流，解释为何上榜 | |
| ProjectLogo | 仓库/产品标识 | `name` | `src,kind` | 圆角容器 | 有图 contain；无图 3D 圆角 SVG | 详情页右上与标题块同高 |
| RankingList | 榜单容器 | `items[]` | | RankingItem × N | flex 均分剩余高度 | 最多 10 条 |
| TopicTags | 底部标签 | `tags[]` | | pill 横排 | 最多 6 个 | 不换行，溢出隐藏 |
| DataCard / DashboardCard / SourceLabel | 预留 | | | 复用 Panel | 第一阶段未单独实现 | 可按 Panel 扩展 |

新增组件：在本表补一行 → `components.py` 增加纯函数 → 页面 schema 引用 → CSS 只使用 token。
