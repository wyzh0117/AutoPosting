from __future__ import annotations

import base64
from pathlib import Path
from typing import Any, Callable

from autoposting.github_weekly import week_window_start

from .adapter import project_from_repo, ranking_from_repos
from .media import fetch_bytes, fetch_data_uri
from .pipeline import render_page
from .story import (
    embed_story_images,
    extract_story_beats,
    generate_missing_images,
    load_readme,
    text_beats,
)
from .tokens import resolve_tokens

GenerateImage = Callable[[str], bytes]


def render_weekly_visual(
    repos: list[dict[str, Any]],
    jobs: list[dict[str, Any]],
    out_dir: Path,
    theme: str = "dark",
    palette: dict[str, str] | None = None,
    screenshot: bool = True,
    generate_image: GenerateImage | None = None,
) -> list[dict[str, Any]]:
    tokens = resolve_tokens(theme, palette)
    target = Path(out_dir)
    target.mkdir(parents=True, exist_ok=True)
    date_range = week_window_start()
    total = max(len(repos), 1)
    rendered: list[dict[str, Any]] = []
    for job in jobs:
        kind = str(job.get("kind") or "")
        stem = str(job.get("id") or kind or "page")
        if kind == "cover":
            payload = ranking_from_repos(repos, issue="本周", date_range=date_range)
            for item in payload.get("items") or []:
                if isinstance(item, dict):
                    embedded = fetch_data_uri(str(item.get("logo") or ""))
                    if embedded:
                        item["logo"] = embedded
        else:
            repo = _match_repo(repos, job)
            if repo is None:
                rendered.append(dict(job))
                continue
            rank = int(repo.get("rank") or job.get("rank") or 1)
            payload = project_from_repo(
                repo,
                issue="本周",
                page_number=f"{rank + 1:02d} / {total + 1:02d}",
            )
            logo = fetch_data_uri(str(payload.get("logo") or ""))
            payload["logo"] = logo
            payload["story"] = _repo_story(repo, generate_image)
            if not payload["story"]:
                diagram = _maybe_diagram(generate_image, repo, target, stem)
                if diagram:
                    payload["heroVisual"] = diagram
        result = render_page(
            payload,
            out_dir=target,
            screenshot=screenshot,
            tokens=tokens,
            file_stem=stem,
        )
        row = dict(job)
        if result.get("png"):
            filename = f"{stem}.png"
            row["file"] = filename
            row["url"] = f"/api/generated/github-weekly/{filename}"
        row["selected"] = True
        rendered.append(row)
    return rendered


def _repo_story(repo: dict[str, Any], generate_image: GenerateImage | None) -> list[dict[str, str]]:
    owner = str(repo.get("owner") or "")
    name = str(repo.get("name") or "")
    readme = load_readme(owner, name, fetch_bytes)
    beats = extract_story_beats(readme, owner=owner, repo=name)
    if not beats:
        fallback = [str(item) for item in (repo.get("does") or "").split("、") if str(item).strip()]
        fallback += [str(item) for item in (repo.get("features") or [])]
        fallback += [str(repo.get("summary") or repo.get("description") or name)]
        beats = text_beats(readme, fallback)
    beats = embed_story_images(beats)
    if not any(beat.get("image") for beat in beats):
        beats = generate_missing_images(beats, generate_image, name=name)
    return beats


def _maybe_diagram(
    generate_image: GenerateImage | None,
    repo: dict[str, Any],
    out_dir: Path,
    stem: str,
) -> str:
    if generate_image is None:
        return ""
    name = str(repo.get("name") or "project")
    summary = str(repo.get("summary") or repo.get("description") or "")
    does = str(repo.get("does") or "")
    prompt = (
        f"9:16 product function diagram for open-source tool '{name}'. "
        f"It does: {summary or does}. Clean editorial infographic, rounded 3D UI blocks, "
        f"no dense Chinese body text, dark or matching dashboard style, workflow schematic."
    )
    try:
        payload = generate_image(prompt)
    except Exception:
        return ""
    if not payload:
        return ""
    filename = f"{stem}-diagram.png"
    (out_dir / filename).write_bytes(payload)
    encoded = base64.b64encode(payload).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def _match_repo(repos: list[dict[str, Any]], job: dict[str, Any]) -> dict[str, Any] | None:
    rank = int(job.get("rank") or 0)
    title = str(job.get("title") or "")
    for repo in repos:
        if rank and int(repo.get("rank") or 0) == rank:
            return repo
    for repo in repos:
        if title and str(repo.get("name") or "") == title:
            return repo
    return None
