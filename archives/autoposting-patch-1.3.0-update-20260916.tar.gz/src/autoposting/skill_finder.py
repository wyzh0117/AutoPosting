"""Coverage-first skill search: decompose, fetch, gate, package, write overview."""

from __future__ import annotations

import hashlib
import json
import logging
import re
import threading
import time
import urllib.error
import urllib.request
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Iterable
from urllib.parse import urlencode, urlsplit

from .github_weekly import SEARCH_URL, default_github_get, infer_kind
from .llm import HTTP_USER_AGENT, LLMError, _has_cjk, parse_model_json

_LOG = logging.getLogger(__name__)

# Skill-domain capability categories, tried BEFORE the GitHub-weekly KIND_RULES
# so a skill is classified by what it does rather than by where it was found.
# The old code wrote ``kind = source``, which made every poster print "GitHub"
# and made every KIND_* lookup miss, so all five text boards came out identical.
SKILL_KIND_RULES: tuple[tuple[str, str], ...] = (
    # Compound intents first: a "video thumbnail" skill is an image tool.
    ("封面", "图像"), ("缩略图", "图像"), ("thumbnail", "图像"), ("配图", "图像"),
    ("脚本", "写作"), ("分镜", "写作"), ("storyboard", "写作"), ("script", "写作"),
    ("复盘", "数据"), ("数据", "数据"), ("analytics", "数据"),
    ("剪辑", "视频"), ("视频", "视频"), ("video", "视频"), ("剪映", "视频"),
    ("字幕", "视频"), ("subtitle", "视频"),
    ("图像", "图像"), ("图片", "图像"), ("image", "图像"), ("海报", "图像"),
    ("写作", "写作"), ("文案", "写作"), ("writing", "写作"), ("博客", "写作"), ("blog", "写作"),
    ("数据", "数据"), ("表格", "数据"), ("excel", "数据"), ("data", "数据"),
    ("测试", "测试"), ("test", "测试"),
    ("部署", "部署"), ("deploy", "部署"), ("发布", "部署"),
    ("演示", "演示"), ("ppt", "演示"), ("slide", "演示"),
    ("设计", "设计"), ("design", "设计"),
    ("翻译", "翻译"), ("translat", "翻译"),
    ("选题", "检索"), ("热榜", "检索"), ("榜单", "检索"), ("趋势", "检索"), ("trend", "检索"),
    ("检索", "检索"), ("搜索", "检索"), ("search", "检索"),
    ("爬虫", "采集"), ("采集", "采集"), ("crawl", "采集"), ("scrap", "采集"),
    ("音频", "音频"), ("播客", "音频"), ("audio", "音频"), ("voice", "音频"),
)

Getter = Callable[[str], object]
Searcher = Callable[[str], list[dict[str, str]]]
Completer = Callable[[str], str]
OnEvent = Callable[[str, dict[str, object]], None]
CancelCheck = Callable[[], bool]

SKILL_CAP = 16
FRESH_DAYS = 180
MIN_STARS = 10
# One query now costs up to two search calls (GitHub + skills.sh) instead of one,
# and every stage keeps a fair slice of what is left, so the budget doubles with
# the source count. FETCH_DEADLINE_SECONDS stays the wall-clock guard.
MAX_FETCHES = 160
FETCH_DEADLINE_SECONDS = 240
SKILLS_SH_SOURCE = "skills.sh"
SKILLS_SH_SEARCH_URL = "https://skills.sh/api/search"
# skills.sh reports installs, not stars. Its public /api/search JSON is free and
# unauthenticated (the official docs price no API at all; a third-party
# `mastra-ai/skills-api` exists precisely because of that), ~1-3s and ~16KB per
# response, and it answers Chinese queries. GET /api/skill/<id> returns 401, so
# only the search endpoint is used. A skills.sh entry has no stars, so its
# popularity signal is the install count: 100 installs is the floor where an
# entry has clearly been installed by real users (the same "not a random fork"
# intent as MIN_STARS=10) without cutting the long tail of useful skills.
SKILLS_SH_MIN_INSTALLS = 100
# /api/search returns up to 100 rows. They arrive install-sorted and only a
# handful can clear the gate inside one stage's slice, so keep the head of the
# list: it caps the SKILL.md fetches each query can trigger.
SKILLS_SH_PER_QUERY = 10
# cap_skills ranks by popularity across both sources; treat 100 installs as
# roughly one star so a widely installed skills.sh entry is not automatically
# outranked by any starred repo.
SKILLS_SH_INSTALLS_PER_STAR = 100
GAP_REASON = "这一环没有找到合格 skill"
# Minimum fair slice per stage: both search sources plus one SKILL.md verification.
# The slice is still clamped by the global budget, so it cannot starve tail stages.
MIN_STAGE_FETCHES = 4
_MAX_DEGRADED_REASONS = 8
_MAX_LEDGER = 60
_MAX_REJECTIONS_EXPOSED = 20
PIPELINE_STEPS: tuple[tuple[str, str, str], ...] = (
    ("understanding", "理解需求", "正在把输入收成可执行目标"),
    ("chain", "还原生产链", "正在还原从零到交付的生产链"),
    ("decompose", "分解工作流", "正在把生产链拆成可检索模块"),
    ("keywords", "生成关键词", "正在为每个模块生成检索词"),
    ("search", "查找 Skill", "正在按模块检索 SKILL.md"),
    ("group", "还原分组", "正在按模块归组已收录 skill"),
    ("compose", "组合工作流", "正在组合成端到端工作流"),
)
PIPELINE_BY_STEP = {
    step: (index, label, detail)
    for index, (step, label, detail) in enumerate(PIPELINE_STEPS, start=1)
}
CACHE_TTL_SECONDS = 15 * 60
_MISSING = object()
_cache_lock = threading.Lock()
_github_cache: dict[str, tuple[float, object]] = {}
_LAST_SNAPSHOT: dict[str, dict[str, object]] = {}
GITHUB_PER_PAGE = 5
GITHUB_REPO_RE = re.compile(
    r"github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)",
    re.I,
)
# skills.sh links look like https://skills.sh/<owner>/<repo>/<skill> or
# https://skills.sh/trending; both are preserved instead of being discarded.
SKILLS_SH_LINK_RE = re.compile(
    r"(?:^|//|\.)skills\.sh/([A-Za-z0-9_.-]+)(?:/([A-Za-z0-9_.-]+))?(?:/([A-Za-z0-9_.-]+))?",
    re.I,
)
SKIP_OWNERS = {
    "topics",
    "search",
    "orgs",
    "settings",
    "features",
    "about",
    "pricing",
    "explore",
    "login",
    "apps",
    "sponsors",
}
_SKILL_FILE_MARKERS = ("SKILL.md", ".agents/skills", ".claude/skills", ".cursor/skills")
# Every layout docs/skill_finder/COVERAGE.md promises. `{name}` is the repo / skill
# directory name. fetch_skill_md walks these cheapest-first and only probes nested
# layouts whose top directory the repo root listing actually advertises.
SKILL_PATHS: tuple[str, ...] = (
    "SKILL.md",
    "{name}/SKILL.md",
    ".agents/skills/{name}/SKILL.md",
    ".claude/skills/{name}/SKILL.md",
    "skills/{name}/SKILL.md",
    ".cursor/skills/{name}/SKILL.md",
)
KNOWN_ROOTS = (
    "https://api.github.com/repos/anthropics/skills/contents",
)


def _github_search_terms(terms: str) -> str:
    """GitHub query template — keeps the domain filter and the SKILL.md hint."""
    return f"{terms} SKILL.md site:github.com"


def _skills_sh_search_terms(terms: str) -> str:
    """skills.sh query template — its own in-site search, with no domain filter."""
    return _canonical_query(terms)


SEARCH_TEMPLATES: dict[str, Callable[[str], str]] = {
    "github": _github_search_terms,
    SKILLS_SH_SOURCE: _skills_sh_search_terms,
}


class _RateLimited(RuntimeError):
    """GitHub 403/429/timeout — not evidence that a repo lacks a skill."""


def reset_skill_finder_state() -> None:
    with _cache_lock:
        _github_cache.clear()
        _LAST_SNAPSHOT.clear()


def _canonical_query(value: object) -> str:
    """Normalize only layout whitespace; case can be meaningful in searches."""
    return " ".join(str(value or "").split())


def _cache_get(key: str) -> object:
    with _cache_lock:
        row = _github_cache.get(key)
        if row is None:
            return _MISSING
        stamped, value = row
        if time.monotonic() - stamped > CACHE_TTL_SECONDS:
            _github_cache.pop(key, None)
            return _MISSING
        return deepcopy(value)


def _cache_put(key: str, value: object) -> None:
    with _cache_lock:
        _github_cache[key] = (time.monotonic(), deepcopy(value))


_RATE_LIMIT_MARKERS = (
    "403",
    "429",
    "rate limit",
    "rate-limit",
    "rate_limited",
    "rate limited",
    "ratelimit",
    "too many requests",
    "timeout",
    "timed out",
)
_SENTINEL_FIELDS = {"status", "status_code", "code", "error", "message"}


def _is_rate_limit_payload(value: object) -> bool:
    """Recognize structured upstream failure sentinels without scanning content."""
    if isinstance(value, dict):
        for key, marker in value.items():
            if str(key).lower() not in _SENTINEL_FIELDS:
                continue
            if isinstance(marker, (dict, list, tuple)):
                if _is_rate_limit_payload(marker):
                    return True
                continue
            if isinstance(marker, int) and marker in {403, 429}:
                return True
            text = str(marker or "").lower()
            if any(token in text for token in _RATE_LIMIT_MARKERS):
                return True
        return False
    if isinstance(value, (list, tuple)):
        return any(_is_rate_limit_payload(item) for item in value)
    return False


def _is_rate_limit(exc: BaseException) -> bool:
    current: BaseException | None = exc
    seen: set[int] = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, (TimeoutError, _RateLimited)):
            return True
        code = getattr(current, "code", None)
        if code in {403, 429}:
            return True
        text = str(current).lower()
        if any(
            token in text
            for token in ("403", "429", "timeout", "timed out", "rate limit", "ratelimit")
        ):
            return True
        current = current.__cause__ or current.__context__
    return False


def docs_root() -> Path:
    here = Path(__file__).resolve()
    packaged = here.parents[2] / "docs"
    if packaged.is_dir():
        return packaged
    return Path.cwd() / "docs"


def load_finder_prompt(name: str) -> str:
    path = docs_root() / "skill_finder" / name
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise FileNotFoundError(f"skill_prompt_empty:{name}")
    return text


def _source_of_url(url: str) -> str:
    """Which search source an HTTP call belongs to (used for degrade reasons)."""
    host = (urlsplit(url).hostname or "").lower()
    if host == SKILLS_SH_SOURCE or host.endswith("." + SKILLS_SH_SOURCE):
        return SKILLS_SH_SOURCE
    if host == "api.github.com" or host.endswith("githubusercontent.com"):
        return "github"
    return "http"


def _fair_share(budget: "_FetchBudget", stages_left: int) -> int:
    """An even slice of what is left, so wide maps do not starve tail stages."""
    left = max(0, budget.max_fetches - budget.calls)
    if left <= 0:
        return 0
    stages = max(1, int(stages_left))
    even = left // stages
    # Keep one call in reserve for every later stage, so a generous per-stage
    # floor can never starve the tail of a wide map (12 stages / 24 calls must
    # still give each stage at least one attempt).
    affordable = max(1, left - max(0, stages - 1))
    floor = min(MIN_STAGE_FETCHES, affordable)
    return min(max(floor, even), left)


def _fair_time_share(budget: "_FetchBudget", stages_left: int) -> float:
    """The wall-clock half of the same fair slice: every stage gets real time."""
    left = max(0.0, budget.deadline - time.monotonic())
    return left / max(1, int(stages_left))


def _as_int(value: object) -> int:
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0


def _is_fresh(hit: dict[str, object], now: datetime | None = None) -> bool:
    pushed = _parse_time(str(hit.get("pushed_at") or ""))
    moment = now or datetime.now(timezone.utc)
    return pushed is not None and moment - pushed <= timedelta(days=FRESH_DAYS)


def quality_reason(hit: dict[str, object], now: datetime | None = None) -> tuple[bool, str]:
    """Why a candidate clears (or misses) the COVERAGE.md quality gate.

    The layout clause is shared: a locatable SKILL.md (or an equivalent skill
    description file) is mandatory. The popularity clause is per source — GitHub
    keeps stars/freshness, skills.sh is judged on its install count.
    """
    # Evidence of a locatable skill file: its content, or a URL that itself names
    # one. `skill_path` alone is deliberately NOT evidence — a path we never
    # fetched must not be able to satisfy the gate on its own.
    declared_in_url = any(
        marker in str(hit.get("url") or "") for marker in _SKILL_FILE_MARKERS
    )
    has_file = (
        bool(str(hit.get("skill_md") or "").strip())
        or declared_in_url
        or bool(hit.get("skill_verified"))
    )
    if not has_file:
        return False, "no_skill_md"
    if hit.get("registry"):
        return True, "registry"
    if str(hit.get("source") or "") == SKILLS_SH_SOURCE:
        installs = _as_int(hit.get("installs"))
        if installs >= SKILLS_SH_MIN_INSTALLS:
            return True, f"installs>={SKILLS_SH_MIN_INSTALLS}"
        # A brand-new skills.sh entry can still be fresh on GitHub, and a repo
        # that already earned MIN_STARS is popular by the GitHub rule too.
        if _as_int(hit.get("stars")) >= MIN_STARS:
            return True, f"stars>={MIN_STARS}"
        if _is_fresh(hit, now):
            return True, "fresh"
        return False, f"installs<{SKILLS_SH_MIN_INSTALLS}"
    if _as_int(hit.get("stars")) >= MIN_STARS:
        return True, f"stars>={MIN_STARS}"
    if _is_fresh(hit, now):
        return True, "fresh"
    return False, "stars_and_stale"


def passes_quality(hit: dict[str, object], now: datetime | None = None) -> bool:
    return quality_reason(hit, now=now)[0]


class _StageQuota(RuntimeError):
    """The current stage spent its fair share of the budget — not a failure.

    Kept distinct from the global `skill_search_budget` exhaustion so a wide
    coverage map keeps its tail stages searched instead of starving them.
    """


class _FetchBudget:
    def __init__(
        self,
        getter: Getter,
        searcher: Searcher,
        *,
        max_fetches: int,
        deadline: float,
    ) -> None:
        self._getter = getter
        self._searcher = searcher
        self.max_fetches = max_fetches
        self.deadline = deadline
        self.calls = 0
        self.degraded = False
        self.reasons: list[str] = []
        self.stage_quota_skips = 0
        self.stage_calls: list[dict[str, object]] = []
        self.fetch_calls = 0
        self.search_calls = 0
        self._started = time.monotonic()
        self._quota_limit: int | None = None
        self._quota_deadline: float | None = None
        self._stage_id = ""
        self._stage_name = ""
        self._stage_start_calls = 0

    def mark_degraded(self, reason: str) -> None:
        self.degraded = True
        if reason and reason not in self.reasons and len(self.reasons) < _MAX_DEGRADED_REASONS:
            self.reasons.append(reason)

    def remaining(self) -> bool:
        return self.calls < self.max_fetches and time.monotonic() < self.deadline

    def start_stage(
        self,
        stage_id: str,
        stage_name: str,
        share: int,
        *,
        seconds: float | None = None,
    ) -> None:
        """Reserve one stage's fair slice of whatever budget is left (calls + time)."""
        self._stage_id = stage_id
        self._stage_name = stage_name
        self._stage_start_calls = self.calls
        self._quota_limit = min(self.max_fetches, self.calls + max(0, int(share)))
        self._quota_deadline = (
            self.deadline if seconds is None else min(self.deadline, time.monotonic() + max(0.0, seconds))
        )

    def end_stage(self) -> int:
        used = self.calls - self._stage_start_calls
        self.stage_calls.append(
            {"stage_id": self._stage_id, "name": self._stage_name, "calls": used}
        )
        self._quota_limit = None
        self._quota_deadline = None
        self._stage_id = ""
        self._stage_name = ""
        return used

    def over_quota(self) -> bool:
        if self._quota_limit is not None and self.calls >= self._quota_limit:
            return True
        return self._quota_deadline is not None and time.monotonic() >= self._quota_deadline

    def report(self) -> dict[str, object]:
        return {
            "max_fetches": self.max_fetches,
            "calls": self.calls,
            "fetch_calls": self.fetch_calls,
            "search_calls": self.search_calls,
            "stage_quota_skips": self.stage_quota_skips,
            "elapsed_ms": int(max(0.0, (time.monotonic() - self._started) * 1000)),
            "degraded": self.degraded,
            "degraded_reasons": list(self.reasons),
            "stages": [dict(row) for row in self.stage_calls],
        }

    def get(self, url: str) -> object:
        cached = _cache_get("G:" + url)
        if cached is not _MISSING:
            return cached
        if self.over_quota():
            self.stage_quota_skips += 1
            raise _StageQuota(f"skill_stage_quota:{url}")
        if not self.remaining():
            self.mark_degraded("budget_exhausted")
            raise RuntimeError("skill_search_budget")
        self.calls += 1
        self.fetch_calls += 1
        try:
            result = self._getter(url)
        except Exception as exc:
            self.mark_degraded(f"{_source_of_url(url)}:{type(exc).__name__}")
            raise
        # An empty response is not evidence that this endpoint has no data:
        # transient upstream failures and rate-limit fallbacks are commonly
        # represented as an empty list/object by injected getters.
        if _is_rate_limit_payload(result):
            self.mark_degraded(f"{_source_of_url(url)}:rate_limit")
        elif _has_cacheable_content(result):
            _cache_put("G:" + url, result)
        return result

    def search(self, query: str) -> list[dict[str, str]]:
        normalized = _canonical_query(query)
        cached = _cache_get("S:" + normalized)
        if cached is not _MISSING:
            return list(cached) if isinstance(cached, list) else []
        if self.over_quota():
            self.stage_quota_skips += 1
            return []
        if not self.remaining():
            self.mark_degraded("budget_exhausted")
            return []
        self.calls += 1
        self.search_calls += 1
        try:
            result = self._searcher(normalized)
        except (OSError, TimeoutError, ValueError, RuntimeError) as exc:
            self.mark_degraded(f"web_search:{type(exc).__name__}")
            return []
        if _is_rate_limit_payload(result):
            self.mark_degraded("web_search:rate_limit")
            return []
        if not isinstance(result, list):
            self.mark_degraded("web_search:invalid_payload")
            return []
        if result:
            _cache_put("S:" + normalized, result)
        return result


def _has_cacheable_content(value: object) -> bool:
    if _is_rate_limit_payload(value):
        return False
    if value is None:
        return False
    if isinstance(value, dict):
        items = value.get("items")
        if isinstance(items, list):
            return bool(items)
        message = str(value.get("message") or "").lower()
        if any(token in message for token in ("rate limit", "timeout", "timed out")):
            return False
        return bool(value)
    if isinstance(value, (list, tuple, set, str, bytes)):
        return bool(value)
    return True


def _reusable_snapshot(snapshot: object, query: str) -> dict[str, object] | None:
    if not isinstance(snapshot, dict):
        return None
    if _canonical_query(snapshot.get("query")) != query:
        return None
    if str(snapshot.get("phase") or "") not in {"skills_ready", "done"}:
        return None
    if snapshot.get("error") or snapshot.get("error_reason") or snapshot.get("degraded"):
        return None
    if not isinstance(snapshot.get("skills"), list) or not snapshot["skills"]:
        return None
    return deepcopy(snapshot)


def _last_snapshot_for(query: str) -> dict[str, object] | None:
    with _cache_lock:
        snapshot = _LAST_SNAPSHOT.get(query)
        return deepcopy(snapshot) if snapshot is not None else None


def _save_last_snapshot(query: str, snapshot: dict[str, object]) -> None:
    with _cache_lock:
        _LAST_SNAPSHOT[query] = deepcopy(snapshot)


def find_skills(
    query: str,
    *,
    complete: Completer | None,
    github_get: Getter | None = None,
    web_search: Searcher | None = None,
    now: datetime | None = None,
    output_root: Path | None = None,
    max_fetches: int = MAX_FETCHES,
    fetch_deadline_seconds: float = FETCH_DEADLINE_SECONDS,
    on_event: OnEvent | None = None,
    previous: dict[str, object] | None = None,
    cancel: CancelCheck | None = None,
) -> dict[str, object]:
    text = _canonical_query(query)
    if not text or len(text) > 200:
        raise ValueError("query must be 1-200 characters")
    if complete is None:
        raise LLMError("skill_search_failed", "模型未配置", cause_code="llm_not_configured")
    moment = now or datetime.now(timezone.utc)

    def aborted() -> bool:
        return bool(cancel and cancel())

    def emit(kind: str, payload: dict[str, object]) -> None:
        if on_event is None:
            return
        on_event(kind, dict(payload))

    started_dt = moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)
    started_at = started_dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    clock0 = time.monotonic()
    last_elapsed = -1
    goal = text
    chain: list[dict[str, object]] = []
    stages: list[dict[str, object]] = []
    collected: list[dict[str, object]] = []
    seen: set[str] = set()
    title = text
    theme = text
    prior = _reusable_snapshot(previous, text) if previous is not None else _last_snapshot_for(text)
    root = Path(output_root) if output_root is not None else Path.cwd() / "output" / "skills"
    coverage: dict[str, object] = {"goal": goal, "title": title, "theme": theme, "chain": chain, "stages": stages}

    def elapsed_ms() -> int:
        nonlocal last_elapsed
        ms = int(max(0.0, (time.monotonic() - clock0) * 1000))
        if ms <= last_elapsed:
            ms = last_elapsed + 1
        last_elapsed = ms
        return ms

    def current_progress(step: str, detail: str = "") -> dict[str, object]:
        index, label, default_detail = PIPELINE_BY_STEP[step]
        return {
            "step": step,
            "label": label,
            "detail": detail or default_detail,
            "step_index": index,
            "step_total": 7,
            "started_at": started_at,
            "elapsed_ms": elapsed_ms(),
        }

    def snapshot(
        phase: str,
        article: dict[str, str] | None = None,
        package_path: str = "",
        detail: str = "",
    ) -> dict[str, object]:
        skills = [_public_skill(skill) for skill in cap_skills(collected, stages)]
        filled = _filled_stages(stages, skills)
        visible = _visible_stages(stages, skills)
        use_filled = phase in {"group", "compose", "skills_ready", "error"}
        progress_step = phase if phase in PIPELINE_BY_STEP else ("compose" if phase == "skills_ready" else "search")
        return {
            "query": text,
            "goal": goal,
            "chain": list(chain),
            "title": title,
            "theme": theme,
            # Empty stages stay visible with `gap: true` so the frontend can show
            # where coverage is missing instead of silently dropping a row.
            "stages": visible if use_filled else [
                {
                    "id": stage["id"],
                    "name": stage["name"],
                    "queries": list(stage.get("queries") or []),
                    "required": bool(stage.get("required", True)),
                    "gap": bool(stage.get("gap")),
                }
                for stage in stages
            ],
            "skills": skills,
            "groups": _skill_groups(filled, skills),
            "article": article or {"title": "", "body": ""},
            "images": [],
            "package_path": package_path,
            "phase": phase,
            "progress": current_progress(progress_step, detail),
        }

    def emit_progress(step: str, detail: str = "") -> dict[str, object]:
        body = snapshot(step, detail=detail)
        emit("progress", body)
        return body

    def emit_new_skills(before: int, kind: str = "skill") -> None:
        for skill in collected[before:]:
            public = _public_skill(skill)
            module = str(public.get("stage_name") or "")
            keyword = module
            body = snapshot("search", detail=f"正在检索：{module} · {keyword}" if module else "")
            body["skill"] = public
            emit(kind, body)

    emit_progress("understanding")
    try:
        coverage = decompose_coverage(text, complete)
    except LLMError as exc:
        raise LLMError("skill_search_failed", exc.reason, cause_code=exc.code) from exc
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise LLMError("skill_search_failed", "覆盖地图解析失败", cause_code="llm_invalid_output") from exc
    goal = str(coverage.get("goal") or text)
    chain = list(coverage.get("chain") or [])
    title = str(coverage.get("title") or text)
    theme = str(coverage.get("theme") or text)
    stages = list(coverage["stages"])
    emit_progress("understanding")
    emit_progress("chain")
    emit_progress("decompose")
    emit_progress("keywords")
    budget = _FetchBudget(
        github_get or _default_get,
        web_search or _default_web_search,
        max_fetches=max(1, int(max_fetches)),
        deadline=time.monotonic() + max(1.0, float(fetch_deadline_seconds)),
    )
    getter = budget.get
    searcher = budget.search
    ledger: list[dict[str, object]] = []

    def run_stage(stage: dict[str, object], stages_left: int, *, second_pass: bool) -> None:
        """Search one stage inside its fair slice, recording the consumption."""
        budget.start_stage(
            str(stage["id"]),
            str(stage["name"]),
            _fair_share(budget, stages_left),
            seconds=_fair_time_share(budget, stages_left),
        )
        try:
            _search_stage(
                stage,
                getter,
                searcher,
                collected,
                seen,
                moment,
                second_pass=second_pass,
                on_query=on_query_for(stage),
                on_degrade=budget.mark_degraded,
                ledger=ledger,
            )
        finally:
            stage["fetches"] = int(stage.get("fetches") or 0) + budget.end_stage()

    def on_query_for(stage: dict[str, object]) -> Callable[[str, str], None]:
        module_name = str(stage["name"])
        return lambda _name, terms: emit_progress("search", f"正在检索：{module_name} · {terms}")

    try:
        reused = _reuse_previous(prior, stages, collected, seen, moment)
        if reused:
            emit("stage", snapshot("search"))
            emit_new_skills(0)
        if not aborted():
            before_roots = len(collected)
            _collect_known_roots(getter, collected, seen, moment, ledger=ledger)
            emit_new_skills(before_roots)
        for index, stage in enumerate(stages):
            if aborted():
                break
            module_name = str(stage["name"])
            queries = [str(item) for item in (stage.get("queries") or []) if str(item).strip()] or [module_name]
            emit_progress("search", f"正在检索：{module_name} · {queries[0]}")
            before = len(collected)
            run_stage(stage, len(stages) - index, second_pass=False)
            if _stage_skills(collected, str(stage["id"])):
                emit("stage", snapshot("search"))
            emit_new_skills(before)
        _assign_pending(collected, stages)
        for index, stage in enumerate(stages):
            if aborted():
                break
            if stage.get("required") and not _stage_skills(collected, str(stage["id"])):
                module_name = str(stage["name"])
                retry = f"{module_name} claude skill OR agent skill"
                emit_progress("search", f"正在检索：{module_name} · {retry}")
                before = len(collected)
                run_stage(stage, len(stages) - index, second_pass=True)
                emit_new_skills(before)
            # A stage with no qualified skill is a visible gap (B4), required or not.
            stage["gap"] = not _stage_skills(collected, str(stage["id"]))
        _assign_pending(collected, stages)
    except RuntimeError as exc:
        if not any(
            token in str(exc) for token in ("skill_search_budget", "skill_stage_quota")
        ):
            raise
    skills = [skill for skill in cap_skills(collected, stages) if not skill.get("gap")]
    filled = _filled_stages(stages, skills)
    coverage = dict(coverage)
    coverage["goal"] = goal
    coverage["chain"] = chain
    # The article prompt only ever sees stages that really have a skill.
    coverage["stages"] = filled
    coverage["groups"] = _skill_groups(filled, skills)
    emit_progress("group")
    if aborted():
        payload = snapshot("error")
        payload["phase"] = "error"
        return payload
    emit_progress("compose")
    article = write_article(text, coverage, skills, complete)
    payload = snapshot("skills_ready", article=article)
    payload["degraded"] = bool(budget.degraded)
    payload["degraded_reasons"] = list(budget.reasons)
    payload["budget"] = budget.report()
    payload["rejected"] = _ledger_rows(ledger)
    payload["package_path"] = str(write_package(root, payload, skills))
    emit("article", payload)
    emit("skills_ready", payload)
    if skills and not budget.degraded:
        _save_last_snapshot(text, payload)
    return payload


def decompose_coverage(query: str, complete: Completer) -> dict[str, object]:
    query = _canonical_query(query)
    cache_key = "P:" + query
    cached = _cache_get(cache_key)
    if isinstance(cached, dict):
        # find_skills annotates stages with transient gap fields, so never
        # return the mutable cached plan itself.
        return deepcopy(cached)
    prompt = (
        load_finder_prompt("COVERAGE.md")
        + "\n\n用户需求：\n"
        + query.strip()
        + "\n\n只输出 JSON 对象："
        '{"goal":"...","title":"...","theme":"...","chain":[{"id":"c1","name":"...","role":"..."}],'
        '"stages":[{"id":"...","name":"...","queries":["..."],"required":true}]}'
        "\n阶段必须 6 到 12 个。生产链从左到右、由浅入深。"
    )
    parsed = parse_model_json(complete(prompt))
    if not isinstance(parsed, dict):
        raise LLMError("skill_search_failed", "覆盖地图不是对象", cause_code="llm_invalid_output")
    raw_stages = parsed.get("stages")
    if not isinstance(raw_stages, list):
        raise LLMError("skill_search_failed", "覆盖地图缺少阶段", cause_code="llm_invalid_output")
    stages: list[dict[str, object]] = []
    for index, item in enumerate(raw_stages):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        stage_id = str(item.get("id") or f"stage-{index + 1}").strip() or f"stage-{index + 1}"
        queries = [
            str(entry).strip()
            for entry in (item.get("queries") or [])
            if str(entry).strip()
        ]
        if not queries:
            queries = [name]
        stages.append(
            {
                "id": stage_id,
                "name": name,
                "queries": queries,
                "required": bool(item.get("required", True)),
                "gap": False,
            }
        )
    if len(stages) < 6 or len(stages) > 12:
        raise LLMError("skill_search_failed", "覆盖阶段数量无效", cause_code="llm_invalid_output")
    chain: list[dict[str, object]] = []
    raw_chain = parsed.get("chain")
    if isinstance(raw_chain, list):
        for index, item in enumerate(raw_chain):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            chain.append(
                {
                    "id": str(item.get("id") or f"c{index + 1}").strip() or f"c{index + 1}",
                    "name": name,
                    "role": str(item.get("role") or "").strip(),
                }
            )
    if not chain:
        chain = [
            {"id": f"c{index}", "name": str(stage["name"]), "role": ""}
            for index, stage in enumerate(stages, start=1)
        ]
    result = {
        "goal": str(parsed.get("goal") or query).strip() or query,
        "title": str(parsed.get("title") or query).strip() or query,
        "theme": str(parsed.get("theme") or query).strip() or query,
        "chain": chain,
        "stages": stages,
    }
    _cache_put(cache_key, deepcopy(result))
    return result


def write_article(
    query: str,
    coverage: dict[str, object],
    skills: list[dict[str, object]],
    complete: Completer,
) -> dict[str, str]:
    public_skills = [_public_skill(skill) for skill in skills]
    stage_rows = [
        item
        for item in (coverage.get("stages") or [])
        if isinstance(item, dict)
    ]
    package = {
        "query": query,
        "goal": coverage.get("goal"),
        "chain": coverage.get("chain"),
        "title": coverage.get("title"),
        "theme": coverage.get("theme"),
        "stages": stage_rows,
        "groups": coverage.get("groups") or _skill_groups(stage_rows, public_skills),
        "skills": public_skills,
    }
    prompt = (
        load_finder_prompt("PACKAGE_ARTICLE.md")
        + "\n\n打包结果 JSON：\n"
        + json.dumps(package, ensure_ascii=False)
        + "\n\n只输出 JSON：{\"title\":\"...\",\"body\":\"...\"}"
    )
    try:
        parsed = parse_model_json(complete(prompt))
    except LLMError as exc:
        raise LLMError("skill_search_failed", exc.reason, cause_code=exc.code) from exc
    title = ""
    body = ""
    if isinstance(parsed, dict):
        title = str(parsed.get("title") or coverage.get("title") or query).strip()
        body = str(parsed.get("body") or "").strip()
    missing: list[str] = []
    for skill in skills:
        source_id = str(skill.get("source_id") or "")
        name = str(skill.get("name") or "")
        if source_id and source_id not in body:
            missing.append(f"{name} `{source_id}`".strip())
        elif name and name not in body:
            missing.append(name)
    if missing:
        body = (body + "\n\n收录来源：\n" + "\n".join(missing)).strip()
    if "AIGC" not in body:
        body += "\n\nAIGC"
    return {"title": title or str(coverage.get("title") or query), "body": body}


def _popularity(skill: dict[str, object]) -> int:
    """Comparable popularity across sources: installs for skills.sh, stars for GitHub.

    skills.sh has no stars, so its entries would always lose a star-only sort;
    SKILLS_SH_INSTALLS_PER_STAR is the documented, deliberately crude exchange
    rate that keeps a genuinely installed skill in the capped selection.
    """
    if str(skill.get("source") or "") == SKILLS_SH_SOURCE:
        return max(1, _as_int(skill.get("installs")) // SKILLS_SH_INSTALLS_PER_STAR)
    return _as_int(skill.get("stars"))


def cap_skills(
    skills: list[dict[str, object]],
    stages: list[dict[str, object]],
    limit: int = SKILL_CAP,
) -> list[dict[str, object]]:
    if len(skills) <= limit:
        return list(skills)
    by_stage: dict[str, list[dict[str, object]]] = {}
    for skill in skills:
        by_stage.setdefault(str(skill.get("stage_id") or ""), []).append(skill)
    kept: list[dict[str, object]] = []
    extras: list[dict[str, object]] = []
    for stage in stages:
        group = list(by_stage.get(str(stage["id"]), []))
        if not group:
            continue
        group.sort(key=_popularity, reverse=True)
        kept.append(group[0])
        extras.extend(group[1:])
    extras.sort(key=_popularity, reverse=True)
    room = max(limit - len(kept), 0)
    kept.extend(extras[:room])
    order = {str(stage["id"]): index for index, stage in enumerate(stages)}
    kept.sort(
        key=lambda item: (
            order.get(str(item.get("stage_id") or ""), 99),
            -_popularity(item),
        )
    )
    return kept


def _stage_skill_counts(skills: list[dict[str, object]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for skill in skills:
        if skill.get("gap"):
            continue
        sid = str(skill.get("stage_id") or "")
        if sid:
            counts[sid] = counts.get(sid, 0) + 1
    return counts


def _filled_stages(
    stages: list[dict[str, object]],
    skills: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Stages that really hold a skill — the only ones written into the article."""
    counts = _stage_skill_counts(skills)
    filled: list[dict[str, object]] = []
    for stage in stages:
        if stage.get("gap"):
            continue
        sid = str(stage.get("id") or "")
        if counts.get(sid, 0) < 1:
            continue
        filled.append(
            {
                "id": stage["id"],
                "name": stage["name"],
                "queries": list(stage.get("queries") or []),
                "required": bool(stage.get("required", True)),
            }
        )
    return filled


def _visible_stages(
    stages: list[dict[str, object]],
    skills: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Every stage in coverage order, empty ones marked `gap` instead of dropped."""
    counts = _stage_skill_counts(skills)
    rows: list[dict[str, object]] = []
    for stage in stages:
        sid = str(stage.get("id") or "")
        filled = counts.get(sid, 0) >= 1
        row: dict[str, object] = {
            "id": stage["id"],
            "name": stage["name"],
            "queries": list(stage.get("queries") or []),
            "required": bool(stage.get("required", True)),
            "gap": not filled,
        }
        if not filled:
            row["gap_reason"] = str(stage.get("gap_reason") or GAP_REASON)
        for key in ("fetches", "searched_terms"):
            if key in stage:
                row[key] = stage[key]
        rows.append(row)
    return rows


def _reuse_previous(
    previous: dict[str, object] | None,
    stages: list[dict[str, object]],
    collected: list[dict[str, object]],
    seen: set[str],
    now: datetime,
) -> int:
    if not isinstance(previous, dict):
        return 0
    stage_by_id = {str(stage["id"]): stage for stage in stages}
    stage_by_name = {str(stage.get("name") or ""): stage for stage in stages}
    added = 0
    for skill in previous.get("skills") or []:
        if not isinstance(skill, dict):
            continue
        source_id = str(skill.get("source_id") or skill.get("full_name") or "").strip()
        is_skills_sh = str(skill.get("source") or "") == SKILLS_SH_SOURCE
        if not source_id or ("/" not in source_id and not is_skills_sh):
            continue
        key = source_id.lower()
        name_key = source_id.rsplit("/", 1)[-1].lower()
        if key in seen or name_key in seen:
            continue
        stage = stage_by_id.get(str(skill.get("stage_id") or "")) or stage_by_name.get(
            str(skill.get("stage_name") or "")
        )
        if stage is None:
            continue
        hit = dict(skill)
        hit["source_id"] = source_id
        hit["full_name"] = source_id
        hit["name"] = str(hit.get("name") or source_id.rsplit("/", 1)[-1])
        hit["stage_id"] = str(stage["id"])
        hit["stage_name"] = str(stage.get("name") or "")
        # This skill cleared the gate in a previous run, so its verification is
        # carried over explicitly. Do NOT fabricate a `skill_path` to satisfy the
        # gate: a path we never fetched must not count as evidence.
        hit["skill_verified"] = True
        hit["gap"] = False
        if not passes_quality(hit, now=now):
            continue
        seen.add(key)
        seen.add(name_key)
        collected.append(hit)
        added += 1
    return added


def write_package(
    output_root: Path,
    payload: dict[str, object],
    skills: list[dict[str, object]],
) -> Path:
    digest = hashlib.sha256(str(payload.get("query") or "").encode("utf-8")).hexdigest()[:12]
    folder = Path(output_root) / digest
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "images").mkdir(exist_ok=True)
    skills_dir = folder / "skills"
    skills_dir.mkdir(exist_ok=True)
    for skill in skills:
        name = _safe_name(str(skill.get("source_id") or skill.get("name") or "skill")) + ".md"
        (skills_dir / name).write_text(str(skill.get("skill_md") or ""), encoding="utf-8")
    article = payload.get("article") if isinstance(payload.get("article"), dict) else {}
    (folder / "article.md").write_text(
        f"# {article.get('title') or payload.get('title')}\n\n{article.get('body') or ''}\n",
        encoding="utf-8",
    )
    public = dict(payload)
    public["package_path"] = str(folder)
    (folder / "index.json").write_text(
        json.dumps(public, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return folder


def _clip_bullet(text: str, limit: int) -> str:
    value = " ".join((text or "").split())
    if len(value) <= limit:
        return value
    return value[: limit - 1].rstrip() + "…"


def _cjk_bullets(text: object, limit: int = 4) -> list[str]:
    """Chinese bullets only — an English SKILL.md must not leak onto a poster."""
    from .visual.adapter import to_bullets

    return [piece for piece in to_bullets(text, limit=limit) if _has_cjk(piece)]


def _skill_kind(record: dict[str, object]) -> str:
    # Deliberately excludes the coverage stage: "剪辑" is a pipeline position,
    # not evidence of what the skill does, and including it collapsed every
    # stage of a wide map into one category.
    blob = " ".join(
        [
            str(record.get("name") or ""),
            str(record.get("description") or ""),
            str(record.get("skill_excerpt") or ""),
        ]
    )
    lowered = blob.lower()
    for token, label in SKILL_KIND_RULES:
        if token in lowered:
            return label
    return infer_kind("", _as_str_list(record.get("topics")), blob)


def _skill_boards(record: dict[str, object]) -> dict[str, str]:
    """Fill 一句话看懂 / 做什么 / 如何实现 / 适合哪些人 / 使用场景.

    A skill's own Chinese text always wins. When it has none (most GitHub skills
    ship an English SKILL.md), the fallback is the *category* copy for what the
    skill does, with the coverage stage spliced in so two skills in the same
    category still read differently.
    """
    from .visual.adapter import KIND_AUDIENCE, KIND_HOW

    kind = str(record.get("kind") or "")
    stage = str(record.get("stage_name") or "")
    # The stage is the natural label for "which step is this", but a record with
    # no stage still has a unique name; without a marker every board would fall
    # back to identical category copy.
    where = stage or str(record.get("name") or "")
    excerpt = str(record.get("skill_excerpt") or "")
    description = str(record.get("description") or "")
    own = _cjk_bullets(excerpt) or _cjk_bullets(description)

    summary = _clip_bullet(str(record.get("summary") or ""), 72)
    if not _has_cjk(summary) or len(summary) < 12:
        audience_hint = next(iter(KIND_AUDIENCE.get(kind) or []), "")
        owner = str(audience_hint) or (f"要自己做「{where}」的人" if where else "想把这一步做顺的人")
        when = f"{where}这活要反复做" if where else "这一步要反复做"
        summary = _clip_bullet(
            f"给{owner}，{when}的时候，用 {record.get('name') or '它'} 把这一步先跑通。",
            72,
        )

    from .visual.adapter import KIND_DOES

    does = str(record.get("does") or "")
    if not _cjk_bullets(does):
        if own:
            does = "\n".join(own[:4])
        else:
            rows = [str(item) for item in (KIND_DOES.get(kind) or [])]
            if rows and where:
                rows = [f"接手{where}这一环，{_strip_lead_verb(rows[0])}"] + rows[1:]
            does = "\n".join(rows[:3])

    how = str(record.get("how") or "")
    if not _cjk_bullets(how):
        rows = [str(item) for item in (KIND_HOW.get(kind) or [])]
        if rows and where:
            rows = [f"先把「{where}」这一步要用的材料备齐"] + rows[1:]
        how = "\n".join(rows[:3])

    audience = str(record.get("audience") or "")
    if not _cjk_bullets(audience):
        rows = [str(item) for item in (KIND_AUDIENCE.get(kind) or [])]
        if rows and where:
            rows = [f"{rows[0]}（正在补「{where}」这一环）"]
        audience = "\n".join(rows[:2])

    scene = where
    if scene:
        scene = f"在「{scene}」这一步要反复做的时候"
    return {"summary": summary, "does": does, "how": how, "audience": audience, "scene": scene}


def _skill_url(skill: dict[str, object], source_id: str) -> str:
    explicit = str(skill.get("url") or skill.get("html_url") or "").strip()
    if explicit.startswith(("http://", "https://")):
        return explicit
    if str(skill.get("source") or "") == SKILLS_SH_SOURCE:
        return f"https://{SKILLS_SH_SOURCE}/{source_id}"
    if "/" in source_id:
        return f"https://github.com/{source_id}"
    return f"https://{SKILLS_SH_SOURCE}/"


def _strip_lead_verb(text: str) -> str:
    """Drop a leading 接手 so a spliced label cannot produce 「接手…这一环，接手…」."""
    piece = (text or "").strip().rstrip("。")
    return piece[2:].lstrip("，,") if piece.startswith("接手") else piece


def _amend_board(record: dict[str, object], field: str, marker: str) -> None:
    """Rewrite the first line of one board so it names where this skill belongs."""
    lines = str(record.get(field) or "").splitlines()
    if not lines:
        return
    first = lines[0]
    # Idempotent: drop an earlier splice before adding this marker, so escalating
    # from stage to name never stacks two labels on one line.
    if field == "does":
        if first.startswith("接手") and "这一环，" in first:
            first = first.split("这一环，", 1)[1]
        lines[0] = f"接手{marker}这一环，{_strip_lead_verb(first)}"
    elif field == "how":
        if first.startswith("先把「") and "」这一步要用的材料备齐" in first:
            first = ""
        lines[0] = f"先把「{marker}」这一步要用的材料备齐" + (f"，{first}" if first else "")
    elif field == "audience":
        lines[0] = f"{first.split('（')[0]}（对应 {marker}）"
    elif field == "scene":
        lines[0] = f"在「{marker}」这一步要反复做的时候"
    record[field] = "\n".join(lines)


def _disambiguate_boards(records: list[dict[str, object]]) -> list[dict[str, object]]:
    """Keep every board distinguishable even when source material is identical.

    Two collected skills can genuinely carry the same description, and a batch can
    be rendered from records that share a stage. A board must never print the same
    line on two posters, so a repeated board is amended with the record's stage
    first and, if that is still ambiguous, with its (unique) name. Only the label
    changes: no capability is invented.
    """
    for field in ("does", "how", "audience", "scene"):
        for marker_key in ("stage_name", "name"):
            groups: dict[str, list[dict[str, object]]] = {}
            for record in records:
                value = str(record.get(field) or "").strip()
                if value:
                    groups.setdefault(value, []).append(record)
            duplicates = [group for group in groups.values() if len(group) > 1]
            if not duplicates:
                break
            for group in duplicates:
                for record in group:
                    marker = str(record.get(marker_key) or "").strip()
                    if marker:
                        _amend_board(record, field, marker)
    return records


def skills_as_repos(skills: Iterable[dict[str, object]]) -> list[dict[str, object]]:
    """Turn collected skills into render-ready records for the poster pipeline.

    ``kind`` is the capability category (never the source), and every text board
    is derived from the skill's own material with a category-specific fallback.
    """
    from .github_weekly import fallback_copy, format_stars

    repos: list[dict[str, object]] = []
    for index, skill in enumerate(skills, start=1):
        name = str(skill.get("name") or f"skill-{index}")
        stage = str(skill.get("stage_name") or skill.get("stage") or "")
        description = str(skill.get("description") or skill.get("does") or "")
        excerpt = str(skill.get("skill_excerpt") or "")
        installs = int(skill.get("installs") or skill.get("stars") or 0)
        source_id = str(skill.get("source_id") or name)
        record: dict[str, object] = {
            "rank": index,
            "name": name,
            "full_name": source_id,
            "owner": source_id.split("/", 1)[0],
            # The poster schema requires a URL; a candidate whose source never
            # supplied one must still render instead of aborting the package.
            "url": _skill_url(skill, source_id),
            "stars": installs,
            "stars_label": format_stars(installs),
            "installs": installs,
            "description": description,
            "skill_excerpt": excerpt,
            "stage_name": stage,
            "source": str(skill.get("source") or ""),
            "topics": _as_str_list(skill.get("topics")),
            "icon_url": str(skill.get("icon_url") or ""),
            "summary": "",
            "does": "",
            "how": "",
            "audience": "",
            "scene": "",
            "enriched": False,
        }
        record["kind"] = _skill_kind(record)
        record.update(_skill_boards(record))
        # Category copy only fills a board the skill itself could not supply.
        record.update(fallback_copy(record))
        repos.append(record)
    return _disambiguate_boards(repos)


def _skill_groups(
    stages: list[dict[str, object]],
    skills: list[dict[str, object]],
) -> list[dict[str, object]]:
    by_stage: dict[str, list[str]] = {}
    for skill in skills:
        if skill.get("gap"):
            continue
        sid = str(skill.get("stage_id") or "")
        source_id = str(skill.get("source_id") or skill.get("full_name") or "")
        if not sid or not source_id:
            continue
        bucket = by_stage.setdefault(sid, [])
        if source_id not in bucket:
            bucket.append(source_id)
    groups: list[dict[str, object]] = []
    for stage in stages:
        sid = str(stage.get("id") or "")
        ids = by_stage.get(sid) or []
        if not ids:
            continue
        groups.append({"stage_id": sid, "skill_ids": ids})
    return groups


def _record_rejection(
    ledger: list[dict[str, object]] | None,
    hit: dict[str, object],
    reason: str,
) -> None:
    """Keep why a candidate was dropped, so coverage gaps are explainable (B4)."""
    if ledger is None or len(ledger) >= _MAX_LEDGER:
        return
    ledger.append(
        {
            "source": str(hit.get("source") or ""),
            "source_id": str(hit.get("source_id") or hit.get("full_name") or ""),
            "name": str(hit.get("name") or ""),
            "reason": reason,
        }
    )


def _ledger_rows(ledger: list[dict[str, object]]) -> list[dict[str, object]]:
    return [dict(row) for row in ledger[:_MAX_REJECTIONS_EXPOSED]]


def _search_stage(
    stage: dict[str, object],
    getter: Getter,
    searcher: Searcher,
    collected: list[dict[str, object]],
    seen: set[str],
    now: datetime,
    *,
    second_pass: bool,
    on_query: Callable[[str, str], None] | None = None,
    on_degrade: Callable[[str], None] | None = None,
    ledger: list[dict[str, object]] | None = None,
) -> None:
    stage_id = str(stage["id"])
    name = str(stage["name"])
    searched: list[str] = stage["searched_terms"] if isinstance(stage.get("searched_terms"), list) else []
    stage["searched_terms"] = searched
    raw_queries = [str(item) for item in (stage.get("queries") or []) if str(item).strip()]
    if second_pass:
        queries = [f"{name} claude skill OR agent skill"]
    else:
        queries = raw_queries or [name]
    for terms in queries:
        if on_query is not None:
            on_query(name, terms)
        if terms not in searched:
            searched.append(terms)
        # Every source is queried before any candidate is ingested: one search
        # call each, so a tight stage slice can never squeeze a channel out, and
        # GitHub (first) owns its own template with the domain filter while the
        # skills.sh template searches in-site with no domain filter at all.
        github_items = _github_search(f"SKILL.md {terms}", getter)
        skills_sh_items = _skills_sh_search(
            SEARCH_TEMPLATES[SKILLS_SH_SOURCE](terms), getter, on_degrade=on_degrade
        )
        try:
            web_hits = searcher(SEARCH_TEMPLATES["github"](terms))
        except (OSError, TimeoutError, ValueError, RuntimeError):
            web_hits = []
        for item in github_items:
            _ingest_repo(item, stage, getter, collected, seen, now, registry=False, ledger=ledger)
        for item in skills_sh_items:
            _ingest_repo(
                item,
                stage,
                getter,
                collected,
                seen,
                now,
                registry=False,
                ledger=ledger,
                source=SKILLS_SH_SOURCE,
            )
        for ref in _names_from_web(web_hits):
            source = str(ref.get("source") or "GitHub")
            full_name = str(ref.get("full_name") or "")
            if source not in {"GitHub", SKILLS_SH_SOURCE} or not full_name:
                # Preserved, never silently discarded: recorded as unresolved.
                _record_rejection(ledger, ref, "unresolved_ref")
                continue
            repo = _repo_lookup(full_name, getter)
            if repo is None:
                continue
            if source == SKILLS_SH_SOURCE:
                merged = dict(repo)
                merged.update(
                    {
                        key: value
                        for key, value in ref.items()
                        if key not in {"full_name"} and value not in (None, "")
                    }
                )
                merged["source"] = SKILLS_SH_SOURCE
                _ingest_repo(
                    merged,
                    stage,
                    getter,
                    collected,
                    seen,
                    now,
                    registry=False,
                    ledger=ledger,
                    source=SKILLS_SH_SOURCE,
                )
                continue
            _ingest_repo(repo, stage, getter, collected, seen, now, registry=False, ledger=ledger)
        if _stage_skills(collected, stage_id):
            return


def _collect_known_roots(
    getter: Getter,
    collected: list[dict[str, object]],
    seen: set[str],
    now: datetime,
    *,
    ledger: list[dict[str, object]] | None = None,
) -> None:
    dummy_stage = {"id": "", "name": ""}
    for url in KNOWN_ROOTS:
        try:
            payload = getter(url)
        except (OSError, TimeoutError, ValueError, RuntimeError):
            continue
        if isinstance(payload, dict) and isinstance(payload.get("items"), list):
            for item in payload["items"]:
                if isinstance(item, dict):
                    _ingest_repo(
                        item, dummy_stage, getter, collected, seen, now, registry=True, ledger=ledger
                    )
            continue
        if isinstance(payload, list):
            for entry in payload:
                if not isinstance(entry, dict):
                    continue
                html_url = str(entry.get("html_url") or entry.get("url") or "")
                match = GITHUB_REPO_RE.search(html_url)
                if match is None:
                    continue
                repo = {
                    "full_name": f"{match.group(1)}/{match.group(2)}",
                    "description": str(entry.get("name") or ""),
                    "stargazers_count": 0,
                    "html_url": html_url,
                    "pushed_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "owner": {"login": match.group(1)},
                }
                _ingest_repo(
                    repo, dummy_stage, getter, collected, seen, now, registry=True, ledger=ledger
                )


def _github_search(terms: str, getter: Getter) -> list[dict[str, object]]:
    query = f"{terms} fork:false"
    url = f"{SEARCH_URL}?{urlencode({'q': query, 'sort': 'stars', 'order': 'desc', 'per_page': str(GITHUB_PER_PAGE)})}"
    try:
        payload = getter(url)
    except (OSError, TimeoutError, ValueError, RuntimeError):
        return []
    items = payload.get("items") if isinstance(payload, dict) else None
    if not isinstance(items, list):
        return []
    return [item for item in items if isinstance(item, dict)]


def _github_repo_from_ref(value: object) -> str:
    """Best-effort `owner/repo` from a repo name, URL, or skills.sh `source`."""
    text = str(value or "").strip()
    if not text:
        return ""
    match = GITHUB_REPO_RE.search(text)
    if match is not None:
        return f"{match.group(1)}/{match.group(2).removesuffix('.git')}"
    parts = [part for part in text.strip("/").split("/") if part]
    if len(parts) >= 2 and "." not in parts[0]:
        return f"{parts[0]}/{parts[1].removesuffix('.git')}"
    return ""


def _skills_sh_items(payload: object) -> list[dict[str, object]] | None:
    """Decode a skills.sh /api/search payload defensively.

    None means "not usable" (wrong type, malformed JSON, non-list `skills`); a row
    with a missing/None `installs` decodes to 0 and is judged by the quality gate
    instead of raising.
    """
    if isinstance(payload, (str, bytes, bytearray)):
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, UnicodeDecodeError, TypeError, ValueError):
            return None
    if isinstance(payload, list):
        rows: object = payload
    elif isinstance(payload, dict):
        rows = payload.get("skills")
    else:
        return None
    if not isinstance(rows, list):
        return None
    hits: list[dict[str, object]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        skill_id = str(row.get("id") or "").strip()
        if not skill_id:
            continue
        source_repo = _github_repo_from_ref(row.get("source"))
        hits.append(
            {
                "source": SKILLS_SH_SOURCE,
                "source_id": skill_id,
                "skillId": str(row.get("skillId") or "").strip(),
                "name": str(row.get("name") or row.get("skillId") or skill_id.rsplit("/", 1)[-1]).strip(),
                "installs": _as_int(row.get("installs")),
                "installs_missing": row.get("installs") is None,
                "source_repo": source_repo,
                "full_name": source_repo,
                "url": f"https://{SKILLS_SH_SOURCE}/{skill_id}",
                "description": str(row.get("description") or "")[:400],
            }
        )
    return hits


def _skills_sh_search(
    query: str,
    getter: Getter,
    *,
    on_degrade: Callable[[str], None] | None = None,
) -> list[dict[str, object]]:
    """Search skills.sh through the shared injectable HTTP indirection.

    Free, unauthenticated public JSON endpoint (GET /api/search?q=...); the only
    documented-per-project option, since skills.sh prices no official API and
    /api/skill/<id> answers 401. Failures never raise: they degrade, and GitHub
    results are kept.
    """
    terms = SEARCH_TEMPLATES[SKILLS_SH_SOURCE](query)
    if not terms:
        return []
    url = f"{SKILLS_SH_SEARCH_URL}?{urlencode({'q': terms})}"
    try:
        payload = _try_get(getter, url)
    except (_RateLimited, _StageQuota) as exc:
        _LOG.debug("skills.sh search unavailable (%s): %s", type(exc).__name__, url)
        return []
    except Exception as exc:  # defensive: an adapter bug must not block GitHub
        _LOG.debug("skills.sh search failed: %s", exc)
        return []
    hits = _skills_sh_items(payload)
    if hits is None:
        _LOG.debug("skills.sh payload not usable: %s", url)
        if on_degrade is not None:
            on_degrade(f"{SKILLS_SH_SOURCE}:unparseable")
        return []
    # Only the install-sorted head is worth fetching SKILL.md for.
    return hits[:SKILLS_SH_PER_QUERY]


def _repo_lookup(full_name: str, getter: Getter) -> dict[str, object] | None:
    url = f"https://api.github.com/repos/{full_name}"
    try:
        payload = getter(url)
    except (OSError, TimeoutError, ValueError, RuntimeError):
        return {"full_name": full_name, "html_url": f"https://github.com/{full_name}"}
    if isinstance(payload, dict) and payload.get("full_name"):
        return payload
    return {"full_name": full_name, "html_url": f"https://github.com/{full_name}"}


def _ingest_repo(
    item: dict[str, object],
    stage: dict[str, object],
    getter: Getter,
    collected: list[dict[str, object]],
    seen: set[str],
    now: datetime,
    *,
    registry: bool,
    ledger: list[dict[str, object]] | None = None,
    source: str | None = None,
) -> None:
    """Turn one candidate into a collected hit when it clears the quality gate.

    Source vocabulary is GitHub / registry / skills.sh. GitHub and registry hits
    must name a repo; a skills.sh hit is identified by its own id, so it may still
    ingest (as an unresolved candidate) when no `owner/repo` can be resolved.
    """
    declared = str(source or item.get("source") or "").strip()
    if not declared:
        declared = "registry" if registry else "GitHub"
    full_name = str(item.get("full_name") or "").strip()
    if "/" not in full_name:
        full_name = _github_repo_from_ref(
            item.get("source_repo") or item.get("source_id") or item.get("html_url") or item.get("url")
        )
    source_id = str(item.get("source_id") or "").strip()
    if not full_name and declared != SKILLS_SH_SOURCE:
        return
    if not source_id:
        source_id = full_name
    if not source_id:
        return
    owner = full_name.split("/", 1)[0] if full_name else ""
    if owner and owner.lower() in SKIP_OWNERS:
        return
    repo_key = full_name.lower()
    key = (source_id if declared == SKILLS_SH_SOURCE else (full_name or source_id)).lower()
    if declared == SKILLS_SH_SOURCE:
        name = str(item.get("name") or item.get("skillId") or source_id.rsplit("/", 1)[-1]).strip()
    else:
        name = full_name.split("/", 1)[1] if full_name else str(item.get("name") or source_id)
    name_key = (name or source_id).lower()
    if (repo_key and repo_key in seen) or key in seen or name_key in seen:
        return
    if full_name:
        try:
            skill_md, skill_path = fetch_skill_md(full_name, getter, name)
        except _RateLimited:
            # A rate limit is not evidence that the repo lacks a skill, but it is
            # also not evidence that it HAS one: leave skill_path empty so the
            # quality gate reports `no_skill_md` instead of accepting a candidate
            # whose description was never actually located.
            skill_md, skill_path = "", ""
        except _StageQuota:
            # This stage already spent its share: record it instead of spending
            # more budget (or accepting a skill we could not verify).
            _record_rejection(
                ledger,
                {"source": declared, "source_id": source_id, "name": name},
                "stage_quota",
            )
            return
    else:
        skill_md, skill_path = "", ""
    hit = {
        "name": name,
        "description": str(item.get("description") or ""),
        "does": str(item.get("description") or ""),
        "url": str(item.get("html_url") or item.get("url") or f"https://github.com/{full_name}"),
        "stars": _as_int(item.get("stargazers_count") or item.get("stars")),
        "installs": _as_int(item.get("installs")),
        "pushed_at": str(item.get("pushed_at") or ""),
        "source_id": source_id,
        "full_name": full_name or source_id,
        "repo": full_name,
        "source": declared,
        "skill_md": skill_md,
        "skill_path": skill_path,
        "topics": _as_str_list(item.get("topics")),
        "icon_url": str(item.get("icon_url") or item.get("owner_avatar") or ""),
        "registry": registry,
        "stage_id": str(stage.get("id") or ""),
        "stage_name": str(stage.get("name") or ""),
    }
    ok, reason = quality_reason(hit, now=now)
    if not ok:
        _record_rejection(ledger, hit, reason)
        return
    seen.add(key)
    seen.add(name_key)
    if repo_key and declared != SKILLS_SH_SOURCE:
        # One entry per repo, whatever source found it first (COVERAGE.md dedupe).
        # A skills.sh id is `<owner>/<repo>/<skill>`, so one repo can host many
        # distinct skills and must not be deduped away after the first.
        seen.add(repo_key)
    collected.append(hit)


def _skill_path(template: str, name: str) -> str:
    return template.format(name=name) if "{name}" in template else template


def _repo_root_listing(
    full_name: str,
    getter: Getter,
    state: dict[str, object],
) -> object:
    try:
        return _try_get(getter, f"https://api.github.com/repos/{full_name}/contents")
    except _RateLimited:
        state["rate_limited"] = True
    except _StageQuota as exc:
        state["quota"] = exc
    return None


def _layout_present(listing: object, path: str) -> bool:
    """True when the repo root listing advertises a layout's top directory."""
    top = path.split("/", 1)[0]
    if top == path:
        return True
    names = {
        str(entry.get("name") or "").lower()
        for entry in listing
        if isinstance(entry, dict)
    } if isinstance(listing, list) else set()
    return top.lower() in names


def fetch_skill_md(full_name: str, getter: Getter, skill_name: str = "") -> tuple[str, str]:
    """Locate the skill description file in every layout COVERAGE.md promises.

    ``{name}`` is the **skill** directory name, not the repo basename: a skills.sh
    monorepo such as ``genmedia-labs/skills`` keeps its skills in sibling
    directories (``video-edit/SKILL.md``), so substituting the repo name would
    404 every probe and reject the source's most popular entries.

    Cost control: the root layout is a single raw fetch in the common case, and
    nested layouts are only probed for directories the repo's own root listing
    advertises (one cached contents call), so the shared fetch budget survives.
    """
    name = (skill_name or "").strip() or full_name.rsplit("/", 1)[-1]
    state: dict[str, object] = {"rate_limited": False, "quota": None}

    def probe(path: str, *, contents: bool = True) -> tuple[str, str]:
        raw_url = f"https://raw.githubusercontent.com/{full_name}/HEAD/{path}"
        try:
            payload = _try_get(getter, raw_url)
        except _RateLimited:
            state["rate_limited"] = True
            payload = None
        except _StageQuota as exc:
            state["quota"] = exc
            return "", ""
        text = _as_markdown(payload)
        if text:
            return text, path
        if not contents:
            return "", ""
        api_url = f"https://api.github.com/repos/{full_name}/contents/{path}"
        try:
            payload = _try_get(getter, api_url)
        except _RateLimited:
            state["rate_limited"] = True
            payload = None
        except _StageQuota as exc:
            state["quota"] = exc
            return "", ""
        try:
            text, found = _from_contents(payload, getter)
        except _RateLimited:
            state["rate_limited"] = True
            text, found = "", ""
        except _StageQuota as exc:
            state["quota"] = exc
            text, found = "", ""
        if text:
            return text, found or path
        return "", ""

    text, found = probe(_skill_path(SKILL_PATHS[0], name))
    if text:
        return text, found
    listing = _repo_root_listing(full_name, getter, state)
    if state["quota"] is not None:
        raise state["quota"]
    known_layouts = isinstance(listing, list)
    nested = [_skill_path(template, name) for template in SKILL_PATHS[1:]]
    if known_layouts:
        nested = [path for path in nested if _layout_present(listing, path)]
    for path in nested:
        text, found = probe(path, contents=known_layouts)
        if text:
            return text, found
        if state["quota"] is not None:
            break
    if state["rate_limited"]:
        raise _RateLimited(full_name)
    if state["quota"] is not None:
        raise state["quota"]
    return "", ""


def _try_get(getter: Getter, url: str) -> object:
    try:
        return getter(url)
    except (_RateLimited, _StageQuota):
        raise
    except (OSError, TimeoutError, ValueError, RuntimeError, TypeError) as exc:
        if _is_rate_limit(exc):
            raise _RateLimited(str(exc)) from exc
        return None


def _as_markdown(payload: object) -> str:
    if isinstance(payload, str) and payload.strip() and "<html" not in payload.lower()[:80]:
        return payload
    if isinstance(payload, dict):
        content = payload.get("content")
        if isinstance(content, str) and content.strip():
            import base64

            encoding = str(payload.get("encoding") or "base64")
            if encoding == "base64":
                try:
                    return base64.b64decode(content).decode("utf-8", errors="replace")
                except (ValueError, TypeError):
                    return ""
            return content
    return ""


def _from_contents(payload: object, getter: Getter) -> tuple[str, str]:
    text = _as_markdown(payload)
    if text:
        path = ""
        if isinstance(payload, dict):
            path = str(payload.get("path") or "")
        return text, path
    if not isinstance(payload, list):
        return "", ""
    for entry in payload:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "")
        path = str(entry.get("path") or name)
        if name == "SKILL.md" or path.endswith("SKILL.md"):
            download = str(entry.get("download_url") or "")
            if download:
                nested = _as_markdown(_try_get(getter, download))
                if nested:
                    return nested, path
            html_url = str(entry.get("url") or "")
            if html_url:
                nested = _as_markdown(_try_get(getter, html_url))
                if nested:
                    return nested, path
    return "", ""


def _assign_pending(collected: list[dict[str, object]], stages: list[dict[str, object]]) -> None:
    by_id = {str(stage["id"]): stage for stage in stages}
    fallback = str(stages[0]["id"]) if stages else ""
    for skill in collected:
        if str(skill.get("stage_id") or ""):
            if not skill.get("stage_name"):
                skill["stage_name"] = str(by_id.get(str(skill["stage_id"]), {}).get("name") or "")
            continue
        assigned = _assign_stage(skill, stages) or fallback
        skill["stage_id"] = assigned
        skill["stage_name"] = str(by_id.get(assigned, {}).get("name") or "")


def _plan_jobs(snapshot: dict[str, object], repos: list[dict[str, object]]) -> list[dict[str, object]]:
    """The cover + poster job list for one skill package (ids only, no rendering)."""
    jobs: list[dict[str, object]] = [{"id": "cover", "kind": "cover"}]
    jobs.extend(
        {"id": f"{int(repo['rank']):02d}-{_safe_name(str(repo['name']))}", "kind": "poster"}
        for repo in repos
    )
    return jobs


def _prune_stale_pages(images_dir: Path, keep_ids: set[str]) -> list[str]:
    """Drop pages left over from a previous render into the same package dir.

    The skill lane reuses one package directory per query digest (and a shared
    ``latest``), so without this a shrinking result set keeps last run's
    ``*.html``/``*.png`` and the printed page totals stop matching the package.
    """
    removed: list[str] = []
    for pattern in ("*.html", "*.png"):
        for path in images_dir.glob(pattern):
            if path.stem not in keep_ids:
                try:
                    path.unlink()
                except OSError:
                    continue
                removed.append(path.name)
    return removed


def render_skill_package(
    snapshot: dict[str, object],
    out_dir: Path,
    *,
    theme: str = "dark",
    palette: dict[str, str] | None = None,
    screenshot_fn: Callable[..., Path] | None = None,
    visual_renderer: Callable[..., list[dict[str, object]]] | None = None,
    copy_writer: Callable[[list[dict[str, object]]], list[dict[str, object]]] | None = None,
    on_image: Callable[[dict[str, object]], None] | None = None,
) -> list[dict[str, object]]:
    from .visual.weekly import render_weekly_visual

    images_dir = Path(out_dir)
    images_dir.mkdir(parents=True, exist_ok=True)
    stages = [
        str(stage.get("name") or "")
        for stage in (snapshot.get("stages") or [])
        if isinstance(stage, dict) and stage.get("name") and not stage.get("gap")
    ]
    skills = [
        item
        for item in (snapshot.get("skills") or [])
        if isinstance(item, dict) and not item.get("gap")
    ]
    repos = skills_as_repos(skills)
    _prune_stale_pages(images_dir, {str(job["id"]) for job in _plan_jobs(snapshot, repos)})
    if copy_writer is not None:
        # Skill posters share the weekly copy layer; a model failure keeps the
        # template copy instead of dropping the render (same policy as weekly).
        try:
            enriched = copy_writer(repos)
        except LLMError:
            enriched = None
        if isinstance(enriched, list) and enriched and all(
            isinstance(row, dict) for row in enriched
        ):
            repos = enriched
    jobs: list[dict[str, object]] = [
        {
            "id": "cover",
            "kind": "cover",
            "rank": 0,
            "title": str(snapshot.get("title") or "Skill 查找结果"),
            "visual_title": str(snapshot.get("title") or "Skill 查找结果"),
            "visual_subtitle": str(snapshot.get("theme") or ""),
            "visual_kicker": "SKILL FINDER",
            "visual_footer": "Skill 查找器 · 按覆盖阶段整理",
            "url": "",
            "file": "",
            "selected": True,
        }
    ]
    jobs.extend(
        {
            "id": f"{int(repo['rank']):02d}-{_safe_name(str(repo['name']))}",
            "kind": "poster",
            "rank": int(repo["rank"]),
            "title": str(repo["name"]),
            "url": "",
            "file": "",
            "selected": True,
        }
        for repo in repos
    )
    if visual_renderer is not None:
        # Keep the injected screenshot hook useful for lightweight renderers
        # (tests and local adapters) while the production path below remains a
        # single weekly visual workflow.
        if screenshot_fn is not None:
            render_weekly_visual(
                repos,
                [jobs[0]],
                images_dir,
                theme=theme,
                palette=palette,
                screenshot_fn=screenshot_fn,
            )
        cards = visual_renderer(repos, jobs, images_dir, theme=theme, palette=palette)
    else:
        cards = render_weekly_visual(
            repos,
            jobs,
            images_dir,
            theme=theme,
            palette=palette,
            screenshot_fn=screenshot_fn,
            # B5(a)3: a skill poster must not print GitHub weekly branding, the ISO
            # week, or the weekly footer. ``issue=""`` blanks the week label.
            series="",
            issue="",
            source="skill 查找器",
            footer="skill 查找器 · 按覆盖阶段整理",
            kicker="SKILL FINDER",
        )
    images: list[dict[str, object]] = []
    for row in cards:
        filename = str(row.get("file") or f"{row.get('id')}.png")
        patched = dict(row)
        patched["url"] = f"/api/generated/skills/{filename}"
        if not patched.get("file"):
            patched["file"] = filename
        images.append(patched)
        if on_image is not None:
            on_image(patched)
    return images


def _assign_stage(hit: dict[str, object], stages: list[dict[str, object]]) -> str:
    blob = f"{hit.get('name')} {hit.get('description')} {hit.get('skill_md')}".lower()
    best = ""
    best_score = 0
    for stage in stages:
        tokens = [str(stage.get("name") or "")] + [str(item) for item in (stage.get("queries") or [])]
        score = sum(1 for token in tokens if token and token.lower() in blob)
        if score > best_score:
            best = str(stage["id"])
            best_score = score
    return best


def _stage_skills(collected: list[dict[str, object]], stage_id: str) -> list[dict[str, object]]:
    return [item for item in collected if str(item.get("stage_id") or "") == stage_id]


def _names_from_web(results: object) -> list[dict[str, object]]:
    """Normalize web-search rows into candidate refs, keeping non-GitHub links.

    GitHub rows ingest exactly as before. skills.sh rows are preserved with the
    repo they came from (`https://skills.sh/<owner>/<repo>/<skill>`) so their
    SKILL.md can still be fetched from GitHub; a `/trending`-style link is kept
    as a section ref. Nothing is dropped on the floor any more.
    """
    refs: list[dict[str, object]] = []
    seen: set[str] = set()
    if not isinstance(results, list):
        return refs
    for item in results:
        if not isinstance(item, dict):
            continue
        blob = " ".join(str(item.get(key) or "") for key in ("url", "href", "title", "snippet"))
        link = str(item.get("url") or item.get("href") or "").strip()
        match = GITHUB_REPO_RE.search(blob)
        if match is not None:
            owner, repo = match.group(1), match.group(2).rstrip(".")
            if owner.lower() in SKIP_OWNERS:
                continue
            full_name = f"{owner}/{repo.rstrip('.git')}"
            key = "gh:" + full_name.lower()
            if key in seen:
                continue
            seen.add(key)
            refs.append({"source": "GitHub", "full_name": full_name, "url": link})
            continue
        sh_match = SKILLS_SH_LINK_RE.search(blob)
        if sh_match is not None:
            first = sh_match.group(1)
            second = sh_match.group(2) or ""
            third = sh_match.group(3) or ""
            if first.lower() in SKIP_OWNERS:
                continue
            key = "sh:" + "/".join(part for part in (first, second, third) if part).lower()
            if key in seen:
                continue
            seen.add(key)
            ref: dict[str, object] = {
                "source": SKILLS_SH_SOURCE,
                "source_id": "/".join(part for part in (first, second, third) if part),
                "url": link or f"https://{SKILLS_SH_SOURCE}/{first}",
            }
            if second:
                ref["full_name"] = f"{first}/{second}"
                ref["name"] = third or second
            else:
                ref["section"] = first
                ref["name"] = first
            refs.append(ref)
            continue
        if link:
            refs.append({"source": "web", "url": link, "name": str(item.get("title") or "")[:120]})
    return refs


def _skill_excerpt(skill: dict[str, object], limit: int = 600) -> str:
    """Bounded, readable slice of SKILL.md used as material by the copy layer."""
    raw = str(skill.get("skill_md") or "")
    if not raw:
        return ""
    lines: list[str] = []
    size = 0
    for line in raw.splitlines():
        text = line.strip()
        if not text or text.startswith(("---", "```", "|", "!", ">", "<", "#!")):
            continue
        text = re.sub(r"^#{1,6}\s*", "", text)
        text = re.sub(r"^[-*+]\s+", "", text)
        text = re.sub(r"^\d+[.)]\s+", "", text)
        if text.lower().startswith(
            ("name:", "description:", "license:", "allowed-tools:", "version:", "author:")
        ):
            continue
        if len(text) < 3:
            continue
        lines.append(text)
        size += len(text)
        if size >= limit:
            break
    return "\n".join(lines)[:limit].strip()


def _as_str_list(value: object) -> list[str]:
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value if str(item).strip()]
    return []


def _public_skill(skill: dict[str, object]) -> dict[str, object]:
    return {
        "name": str(skill.get("name") or ""),
        "skill_excerpt": _skill_excerpt(skill),
        "topics": _as_str_list(skill.get("topics")),
        "icon_url": str(skill.get("icon_url") or ""),
        "description": str(skill.get("description") or skill.get("does") or ""),
        "does": str(skill.get("does") or skill.get("description") or ""),
        "url": str(skill.get("url") or ""),
        "stars": int(skill.get("stars") or 0),
        "installs": int(skill.get("installs") or 0),
        "pushed_at": str(skill.get("pushed_at") or ""),
        "source_id": str(skill.get("source_id") or skill.get("full_name") or ""),
        "source": str(skill.get("source") or "GitHub"),
        "stage_id": str(skill.get("stage_id") or ""),
        "stage_name": str(skill.get("stage_name") or ""),
        "skill_path": str(skill.get("skill_path") or ""),
    }


def _default_get(url: str) -> object:
    """Production HTTP path: skills.sh JSON goes through its own stdlib getter."""
    if _source_of_url(url) == SKILLS_SH_SOURCE:
        return _default_skills_sh_get(url)
    return default_github_get(url, timeout=8)


def _default_skills_sh_get(url: str, timeout: float = 20) -> object:
    """Stdlib GET for the free, unauthenticated skills.sh search endpoint.

    Measured 1-7s normally and up to ~12s when the endpoint is under burst load
    (the 2026-xx diagnostic run saw 10.7-12.2s answers), so the timeout is set
    well above the fast path: slower than this counts as a degrade, and the
    per-stage time slice keeps one slow query from starving the tail stages.
    """
    request = urllib.request.Request(
        url,
        headers={"User-Agent": HTTP_USER_AGENT, "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        # The status code stays in the message so _is_rate_limit can see 403/429.
        raise RuntimeError(f"{SKILLS_SH_SOURCE}_http_{exc.code}") from exc
    except (OSError, urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(f"{SKILLS_SH_SOURCE}_unreachable") from exc
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"{SKILLS_SH_SOURCE}_invalid_json") from exc


def _default_web_search(query: str) -> list[dict[str, str]]:
    from .background import search_web

    return search_web(query)


def _parse_time(raw: str) -> datetime | None:
    text = raw.strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        value = datetime.fromisoformat(text)
    except ValueError:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _safe_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-")
    return cleaned[:80] or "skill"
