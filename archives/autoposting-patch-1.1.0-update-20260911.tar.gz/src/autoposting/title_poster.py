"""Title 大字报 cover when an article has no selected cover image."""

from __future__ import annotations

import html
import tempfile
from pathlib import Path
from typing import Callable

POSTER_WIDTH = 1080
POSTER_HEIGHT = 1080
ScreenshotFn = Callable[..., Path]


def poster_html(title: str) -> str:
    text = html.escape((title or "").strip() or "未命名")
    size = _font_size((title or "").strip() or "未命名")
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{text}</title>
<style>
html,body{{margin:0;width:{POSTER_WIDTH}px;height:{POSTER_HEIGHT}px;background:#8b1a1a;color:#f4e4c1}}
body{{display:flex;align-items:center;justify-content:center;font-family:"Songti SC","STSong","SimSun","Noto Serif SC",serif}}
.frame{{box-sizing:border-box;width:960px;height:960px;border:10px solid #f4e4c1;display:flex;align-items:center;justify-content:center;padding:64px}}
h1{{margin:0;font-size:{size}px;line-height:1.2;letter-spacing:.12em;text-align:center;font-weight:700;word-break:break-word}}
</style>
</head>
<body>
<div class="frame"><h1>{text}</h1></div>
</body>
</html>
"""


def render_title_poster(
    title: str,
    *,
    screenshot_fn: ScreenshotFn | None = None,
    tmp_dir: Path | None = None,
) -> bytes:
    from .visual.screenshot import screenshot_html

    shot = screenshot_fn or screenshot_html
    markup = poster_html(title)
    if tmp_dir is None:
        with tempfile.TemporaryDirectory(prefix="autoposting-poster-") as raw:
            return _write_and_shot(Path(raw), markup, shot)
    return _write_and_shot(Path(tmp_dir), markup, shot)


def _font_size(title: str) -> int:
    count = max(len(title), 1)
    if count <= 8:
        return 120
    if count <= 16:
        return 88
    if count <= 24:
        return 68
    return 52


def _write_and_shot(folder: Path, markup: str, shot: ScreenshotFn) -> bytes:
    folder.mkdir(parents=True, exist_ok=True)
    html_path = folder / "title-poster.html"
    png_path = folder / "title-poster.png"
    html_path.write_text(markup, encoding="utf-8")
    shot(html_path, png_path, width=POSTER_WIDTH, height=POSTER_HEIGHT)
    payload = png_path.read_bytes()
    if not payload:
        raise RuntimeError("title_poster_empty")
    return payload
