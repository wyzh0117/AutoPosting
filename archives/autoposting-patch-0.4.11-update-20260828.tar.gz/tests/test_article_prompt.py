import unittest
from pathlib import Path

from autoposting.article_prompt import (
    ARTICLE_BASE_PROMPT_FILENAME,
    ARTICLE_STYLE_PROMPT_FILES,
    ARTICLE_STYLE_PROMPT_IDS,
    article_prompt_paths,
    article_style_prompt_paths,
    article_prompt_version,
    build_article_prompt,
    load_article_prompt_doc,
    load_article_style_prompt,
    parse_article_prompt_doc,
)
from autoposting.llm import LLMService

from test_llm import FakeRunner, _db
import tempfile


class ArticlePromptDocTests(unittest.TestCase):
    def test_numbered_style_prompt_files_are_distinct(self) -> None:
        expected_files = {
            "1": "消息.md",
            "2": "通讯.md",
            "3": "新闻特写.md",
            "4": "新闻专访.md",
            "5": "调查报道.md",
            "6": "深度报道.md",
            "7": "评论述评.md",
            "8": "AI专家.md",
            "经验分享": "经验分享.md",
        }
        self.assertEqual(tuple("12345678") + ("经验分享",), ARTICLE_STYLE_PROMPT_IDS)
        self.assertEqual(expected_files, ARTICLE_STYLE_PROMPT_FILES)
        prompts = {}
        for style_id in ARTICLE_STYLE_PROMPT_IDS:
            prompts[style_id] = load_article_style_prompt(style_id)
            self.assertTrue(prompts[style_id])
            self.assertEqual(expected_files[style_id], article_style_prompt_paths(style_id)[0].name)
        self.assertEqual(9, len(set(prompts.values())))
        for style_id in tuple("12345678"):
            self.assertIn("不要把写作提纲暴露给读者", prompts[style_id])
        for style_id in tuple("1234567"):
            self.assertNotIn("一般人容易看漏的角度", prompts[style_id])
        self.assertIn("一般人容易看漏的角度", prompts["8"])
        self.assertIn("拆解", prompts["经验分享"])
        self.assertIn("梳理", prompts["经验分享"])
        self.assertIn("解读", prompts["经验分享"])
        self.assertIn("分享", prompts["经验分享"])
        for invalid in ("9", "../8"):
            with self.assertRaises(ValueError):
                load_article_style_prompt(invalid)

    def test_repo_doc_is_the_live_source_for_both_platforms(self) -> None:
        path = next(p for p in article_prompt_paths() if p.is_file())
        self.assertEqual(ARTICLE_BASE_PROMPT_FILENAME, path.name)
        self.assertEqual("docs", path.parent.name)
        text = load_article_prompt_doc()
        self.assertIn("文章生成基础约束", text)
        self.assertEqual("article-v8", article_prompt_version())
        self.assertNotIn("一般人容易看漏的角度", text)
        expert = load_article_style_prompt("8")
        self.assertIn("chosen_hooks", expert)
        wechat = build_article_prompt(
            "wechat",
            ("lab_blog",),
            {
                "title": "t",
                "summary": "s",
                "background": {
                    "chosen_hooks": [
                        {"phrase": "协和4+4试点班", "why": "公开检索出现争议"},
                        {"phrase": "第二切口"},
                    ]
                },
            },
            style="短句",
            preset_style=expert,
        )
        self.assertIn("一般人容易看漏的角度", wechat)
        self.assertLess(wechat.index("一般人容易看漏的角度"), wechat.index("短句"))
        self.assertIn("lab_blog", wechat)
        self.assertIn("写作风格要求：", wechat)
        self.assertIn("短句", wechat)
        self.assertIn('"title": "t"', wechat)
        self.assertIn("协和4+4试点班", wechat)
        self.assertIn("第二切口", wechat)
        self.assertIn("主切口", wechat)
        self.assertIn("公开报道曾关注", wechat)
        preset = build_article_prompt(
            "wechat", ("lab_blog",), {"title": "t"}, preset_style=expert
        )
        self.assertIn(f"写作风格要求：\n{expert}", preset)
        notes = build_article_prompt(
            "xiaohongshu",
            ("lab_blog",),
            {"title": "t", "summary": "s", "background": {}},
            preset_style=expert,
        )
        self.assertIn("小红书更快、更短", notes)
        self.assertNotIn("前因与脉络", notes)

    def test_editing_the_doc_changes_the_model_prompt(self) -> None:
        custom = (
            "version: article-test\n\n"
            "## 共用\n共用段 {source_ids}\n\n"
            "## 微信\n微信段\n{style_block}数据：\n{data}\n"
        )
        prompt = build_article_prompt(
            "wechat",
            ("media_feed",),
            {"title": "x"},
            doc_text=custom,
        )
        self.assertIn("共用段 media_feed", prompt)
        self.assertIn("微信段", prompt)
        self.assertEqual("article-test", parse_article_prompt_doc(custom)["version"])

    def test_generate_article_reads_the_repo_doc(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        fake = FakeRunner(
            stdout='{"title": "模型一正式发布", "body": "前因与脉络。lab_blog AIGC"}'
        )
        service = LLMService(_db(temp), runner=fake)
        service.generate_article("wechat", "标题", "摘要", ("lab_blog",))
        prompt = fake.calls[0][2]
        self.assertIn("文章生成基础约束", load_article_prompt_doc())
        self.assertIn(load_article_style_prompt("8"), prompt)
        self.assertIn("一般人容易看漏的角度", prompt)
        self.assertIn("不要把写作提纲暴露给读者", prompt)
