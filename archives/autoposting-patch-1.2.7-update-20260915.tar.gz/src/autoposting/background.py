"""Gather recent background for a hotspot before drafting.

Uses the local SQLite window plus a DuckDuckGo HTML search. Failures stay
empty notes so drafting can still run on the original item.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Callable
from urllib.parse import quote_plus
from urllib.request import Request, urlopen

from .db import Database
from .images import BROWSER_UA
from .linked_works import fetch_linked_works
from .normalize import normalize_text

Fetcher = Callable[[str], bytes]
WEB_RESULT_LIMIT = 5
LOCAL_RESULT_LIMIT = 5
PAGE_TEXT_LIMIT = 1800
ORIGINAL_TEXT_LIMIT = 50_000
RELATED_SELECTION_LIMIT = 2_000
RELATED_CONTEXT_LIMIT = 12_000
RELATED_QUERY_LIMIT = 200
STOPWORDS = {
    "the",
    "and",
    "for",
    "with",
    "from",
    "this",
    "that",
    "新闻",
    "消息",
    "发布",
    "今日",
    "报道",
    "称",
}


def _related_prompt_paths() -> tuple[Path, ...]:
    here = Path(__file__).resolve()
    return (here.parents[2] / "docs" / "RELATED_SEARCH_PROMPT.md", Path.cwd() / "docs" / "RELATED_SEARCH_PROMPT.md")


def load_related_search_prompt() -> str:
    for candidate in _related_prompt_paths():
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8")
    raise FileNotFoundError("related_search_prompt_missing")


def _javascript_offset(text: str, offset: int) -> int:
    """Convert a browser UTF-16 selection offset to a Python string offset."""
    units = 0
    for index, char in enumerate(text):
        if units == offset:
            return index
        units += 2 if ord(char) > 0xFFFF else 1
        if units > offset:
            raise ValueError("selection offset splits a Unicode character")
    if units == offset:
        return len(text)
    raise ValueError("selection offset is outside draft body")


def related_article_context(body: str, selection: str, start: int, end: int) -> str:
    """Return all selected paragraphs and at most one paragraph on either side."""
    if not isinstance(body, str) or not isinstance(selection, str):
        raise ValueError("body and selection must be strings")
    if not selection.strip() or len(selection) > RELATED_SELECTION_LIMIT:
        raise ValueError(f"selection must be 1-{RELATED_SELECTION_LIMIT} characters")
    if isinstance(start, bool) or not isinstance(start, int) or isinstance(end, bool) or not isinstance(end, int):
        raise ValueError("selection_start and selection_end must be integers")
    if start < 0 or end <= start:
        raise ValueError("selection does not match draft body")
    start = _javascript_offset(body, start)
    end = _javascript_offset(body, end)
    if end <= start or end > len(body):
        raise ValueError("selection does not match draft body")
    raw_selection = body[start:end]
    if raw_selection != selection:
        if raw_selection.strip() != selection:
            raise ValueError("selection does not match draft body")
        start += len(raw_selection) - len(raw_selection.lstrip())
        end = start + len(selection)

    spans: list[tuple[int, int]] = []
    cursor = 0
    for boundary in re.finditer(r"\r?\n[ \t]*\r?\n", body):
        if body[cursor : boundary.start()].strip():
            spans.append((cursor, boundary.start()))
        cursor = boundary.end()
    if body[cursor:].strip():
        spans.append((cursor, len(body)))
    selected_indexes = [
        index
        for index, (paragraph_start, paragraph_end) in enumerate(spans)
        if start < paragraph_end and end > paragraph_start
    ]
    if not selected_indexes:
        raise ValueError("selection is outside a paragraph")
    first_index, last_index = selected_indexes[0], selected_indexes[-1]
    selected_start, selected_end = spans[first_index][0], spans[last_index][1]
    selected = body[selected_start:selected_end].strip()
    left_neighbor = body[spans[first_index - 1][0] : spans[first_index - 1][1]].strip() if first_index else ""
    right_neighbor = (
        body[spans[last_index + 1][0] : spans[last_index + 1][1]].strip()
        if last_index + 1 < len(spans)
        else ""
    )
    context = "\n\n".join(piece for piece in (left_neighbor, selected, right_neighbor) if piece)
    if len(context) <= RELATED_CONTEXT_LIMIT:
        return context
    # Preserve the complete selected block before trimming optional neighbors.
    if len(selected) >= RELATED_CONTEXT_LIMIT:
        # The exact selection is bounded above, so retaining it is safer than
        # slicing away part of a cross-paragraph selection.
        return selection[:RELATED_CONTEXT_LIMIT]
    neighbors = [piece for piece in (left_neighbor, right_neighbor) if piece]
    remaining = max(0, RELATED_CONTEXT_LIMIT - len(selected) - 4 * len(neighbors))
    left_piece = right_piece = ""
    if left_neighbor and right_neighbor:
        share = remaining // 2
        left_piece, right_piece = left_neighbor[:share], right_neighbor[:remaining - share]
    elif left_neighbor:
        left_piece = left_neighbor[:remaining]
    elif right_neighbor:
        right_piece = right_neighbor[:remaining]
    pieces = []
    if left_piece:
        pieces.append(left_piece)
    pieces.append(selected)
    if right_piece:
        pieces.append(right_piece)
    return "\n\n".join(piece for piece in pieces if piece).strip()[:RELATED_CONTEXT_LIMIT]


def build_related_search_prompt(title: str, selection: str, context: str) -> str:
    template = load_related_search_prompt()
    return template.format(title=title, selection=selection, context=context)


@dataclass
class BackgroundNote:
    focus: str
    query: str
    local: list[dict[str, str]] = field(default_factory=list)
    web: list[dict[str, str]] = field(default_factory=list)
    source_excerpt: str = ""
    linked_works: list[dict[str, str]] = field(default_factory=list)

    def as_prompt(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "focus": self.focus,
            "query": self.query,
            "source_excerpt": self.source_excerpt,
            "local_related": self.local,
            "web_related": self.web,
        }
        if self.linked_works:
            payload["linked_works"] = self.linked_works
        return payload


def infer_focus(title: str, summary: str = "") -> str:
    text = normalize_text(title or "")
    if not text:
        return normalize_text(summary)[:80]
    return text[:120]


def search_query(title: str) -> str:
    focus = infer_focus(title)
    if "2026" not in focus and "2025" not in focus:
        return f"{focus} 2026"
    return focus


def _tokens(title: str) -> set[str]:
    parts = re.findall(r"[\u4e00-\u9fff]{2,}|[A-Za-z][A-Za-z0-9_-]{2,}", title or "")
    return {part.casefold() for part in parts if part.casefold() not in STOPWORDS}


class _DDGParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.results: list[dict[str, str]] = []
        self._href = ""
        self._in_title = False
        self._in_snippet = False
        self._title: list[str] = []
        self._snippet: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        found = {key: value or "" for key, value in attrs}
        classes = found.get("class", "")
        href = found.get("href", "")
        if tag == "a" and href and (
            "result__a" in classes or "result-link" in classes or found.get("rel") == "nofollow"
        ):
            if href.startswith("http") and "duckduckgo.com" not in href:
                self._href = href
                self._in_title = True
                self._title = []
        elif tag in {"a", "td", "div"} and (
            "result__snippet" in classes or "result-snippet" in classes
        ):
            self._in_snippet = True
            self._snippet = []

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._in_title:
            self._in_title = False
            title = normalize_text("".join(self._title))
            if self._href and title:
                self.results.append({"title": title, "url": self._href, "snippet": ""})
                self._href = ""
        if tag in {"a", "td", "div"} and self._in_snippet:
            self._in_snippet = False
            snippet = normalize_text("".join(self._snippet))
            if snippet and self.results and not self.results[-1]["snippet"]:
                self.results[-1]["snippet"] = snippet[:280]

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self._title.append(data)
        elif self._in_snippet:
            self._snippet.append(data)


class _ArticleTextParser(HTMLParser):
    _BLOCKS = {"p", "h1", "h2", "h3", "li", "blockquote"}
    _SKIP = {"script", "style", "nav", "header", "footer", "aside", "svg", "noscript"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.skip_tags: list[str] = []
        self.focus_depth = 0
        self.block_depth = 0
        self.chunk: list[str] = []
        self.blocks: list[tuple[bool, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        del attrs
        if self.skip_tags:
            if tag in self._SKIP:
                self.skip_tags.append(tag)
            return
        if tag in self._SKIP:
            self.skip_tags.append(tag)
            return
        if tag in {"article", "main"}:
            self.focus_depth += 1
        if tag in self._BLOCKS:
            if self.block_depth == 0:
                self.chunk = []
            self.block_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if self.skip_tags:
            if tag == self.skip_tags[-1]:
                self.skip_tags.pop()
            return
        if tag in self._BLOCKS and self.block_depth:
            self.block_depth -= 1
            if self.block_depth == 0:
                text = " ".join(" ".join(self.chunk).split()).strip()
                if text:
                    self.blocks.append((self.focus_depth > 0, text))
                self.chunk = []
        if tag in {"article", "main"} and self.focus_depth:
            self.focus_depth -= 1

    def handle_data(self, data: str) -> None:
        if not self.skip_tags and self.block_depth:
            self.chunk.append(data)

    def text(self) -> str:
        focused = [text for in_focus, text in self.blocks if in_focus]
        chosen = focused if sum(map(len, focused)) >= 200 else [text for _, text in self.blocks]
        return "\n\n".join(dict.fromkeys(chosen))[:ORIGINAL_TEXT_LIMIT]


def parse_search_html(payload: bytes) -> list[dict[str, str]]:
    parser = _DDGParser()
    parser.feed(payload.decode("utf-8", errors="replace"))
    parser.close()
    seen: set[str] = set()
    unique: list[dict[str, str]] = []
    for item in parser.results:
        url = item["url"]
        if url in seen:
            continue
        seen.add(url)
        unique.append(item)
    return unique


def _default_search_fetcher(url: str) -> bytes:
    request = Request(
        url,
        headers={
            "User-Agent": BROWSER_UA,
            "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(request, timeout=12) as response:
        return response.read(400_000)


def _parse_ddg_json(payload: bytes) -> list[dict[str, str]]:
    try:
        parsed = json.loads(payload.decode("utf-8", errors="replace"))
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, dict):
        return []
    results: list[dict[str, str]] = []
    abstract = str(parsed.get("AbstractText") or "").strip()
    abstract_url = str(parsed.get("AbstractURL") or "").strip()
    heading = str(parsed.get("Heading") or "").strip()
    if abstract and abstract_url:
        results.append({"title": heading or abstract[:80], "url": abstract_url, "snippet": abstract[:280]})
    related = parsed.get("RelatedTopics")
    if isinstance(related, list):
        for entry in related:
            if not isinstance(entry, dict):
                continue
            text = str(entry.get("Text") or "").strip()
            url = str(entry.get("FirstURL") or "").strip()
            if text and url:
                results.append({"title": text.split(" - ", 1)[0][:120], "url": url, "snippet": text[:280]})
    return results


def _parse_wikipedia(payload: bytes) -> list[dict[str, str]]:
    try:
        parsed = json.loads(payload.decode("utf-8", errors="replace"))
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list) or len(parsed) < 4:
        return []
    titles, snippets, urls = parsed[1], parsed[2], parsed[3]
    results: list[dict[str, str]] = []
    for title, snippet, url in zip(titles, snippets, urls):
        if title and url:
            results.append(
                {"title": str(title), "url": str(url), "snippet": str(snippet or "")[:280]}
            )
    return results


def search_web(query: str, fetcher: Fetcher | None = None, limit: int = WEB_RESULT_LIMIT) -> list[dict[str, str]]:
    if not query.strip():
        return []
    load = fetcher or _default_search_fetcher
    encoded = quote_plus(query.strip())
    attempts = (
        (f"https://html.duckduckgo.com/html/?q={encoded}", parse_search_html),
        (f"https://lite.duckduckgo.com/lite/?q={encoded}", parse_search_html),
        (f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1&skip_disambig=1", _parse_ddg_json),
        (
            "https://en.wikipedia.org/w/api.php?action=opensearch&limit=3&format=json"
            f"&search={encoded}",
            _parse_wikipedia,
        ),
    )
    for url, parser in attempts:
        try:
            results = parser(load(url))
        except (OSError, TimeoutError, ValueError):
            continue
        if results:
            return results[:limit]
    return []


def search_local(database: Database, title: str, item_id: str = "", hours: int = 168) -> list[dict[str, str]]:
    tokens = _tokens(title)
    if not tokens:
        return []
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    scored: list[tuple[int, dict[str, str]]] = []
    for row in database.list_recent_items(since):
        other_id = str(row.get("item_id") or "")
        if item_id and other_id == item_id:
            continue
        other_title = str(row.get("title") or "")
        overlap = len(tokens & _tokens(other_title))
        if overlap < 1:
            continue
        scored.append(
            (
                overlap,
                {
                    "title": other_title,
                    "summary": normalize_text(str(row.get("content_text") or ""))[:240],
                    "url": str(row.get("canonical_url") or ""),
                    "source_id": str(row.get("source_id") or ""),
                },
            )
        )
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [item for _, item in scored[:LOCAL_RESULT_LIMIT]]


def excerpt_page(payload: bytes) -> str:
    return article_page_text(payload)[:PAGE_TEXT_LIMIT]


def article_page_text(payload: bytes) -> str:
    parser = _ArticleTextParser()
    parser.feed(payload.decode("utf-8", errors="replace"))
    parser.close()
    return parser.text()


def gather_background(
    database: Database,
    title: str,
    summary: str = "",
    item_id: str = "",
    page_url: str = "",
    fetcher: Fetcher | None = None,
) -> BackgroundNote:
    focus = infer_focus(title, summary)
    note = BackgroundNote(focus=focus, query=search_query(title), source_excerpt=normalize_text(summary)[:PAGE_TEXT_LIMIT])
    try:
        note.local = search_local(database, title, item_id=item_id)
    except (OSError, ValueError):
        note.local = []
    if fetcher is not None and page_url:
        try:
            excerpt = excerpt_page(fetcher(page_url))
            if excerpt:
                note.source_excerpt = excerpt
        except (OSError, TimeoutError, ValueError, UnicodeError):
            pass
    if fetcher is not None:
        try:
            note.web = search_web(note.query, fetcher=fetcher)
        except (OSError, TimeoutError, ValueError):
            note.web = []
        try:
            note.linked_works = fetch_linked_works(f"{title}\n{summary}", fetcher=fetcher)
        except (OSError, TimeoutError, ValueError):
            note.linked_works = []
    return note
