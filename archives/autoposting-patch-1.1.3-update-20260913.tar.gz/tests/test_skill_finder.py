import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from autoposting.db import Database
from autoposting.llm import IMAGE_ASPECT_RATIO, LLMError
from autoposting.models import Source
from autoposting.skill_cover import COVER_HEIGHT, COVER_WIDTH, skill_cover_html
from autoposting.skill_finder import find_skills, passes_quality
from autoposting.web import WebApp, create_server


PODCAST_STAGES = [
    {
        "id": "topic",
        "name": "选题",
        "queries": ["播客选题", "podcast topic"],
        "required": True,
    },
    {
        "id": "script",
        "name": "脚本",
        "queries": ["播客脚本", "podcast script"],
        "required": True,
    },
    {
        "id": "record",
        "name": "录音",
        "queries": ["播客录音", "podcast recording"],
        "required": True,
    },
    {
        "id": "edit",
        "name": "剪辑",
        "queries": ["播客剪辑", "podcast edit"],
        "required": True,
    },
    {
        "id": "cover",
        "name": "封面",
        "queries": ["播客封面", "podcast cover art"],
        "required": True,
    },
    {
        "id": "publish",
        "name": "发布",
        "queries": ["播客发布", "podcast publish"],
        "required": True,
    },
]


def _coverage_json() -> str:
    return json.dumps(
        {
            "title": "从零做播客技能包",
            "theme": "播客从选题到上线",
            "stages": PODCAST_STAGES,
        },
        ensure_ascii=False,
    )


def _repo_item(
    full_name: str,
    *,
    stars: int,
    description: str,
    pushed_at: str,
    topics: list[str] | None = None,
) -> dict[str, object]:
    owner, name = full_name.split("/", 1)
    return {
        "full_name": full_name,
        "name": name,
        "description": description,
        "stargazers_count": stars,
        "html_url": f"https://github.com/{full_name}",
        "language": "Python",
        "topics": topics or ["claude-code-skill"],
        "owner": {"login": owner, "avatar_url": f"https://github.com/{owner}.png"},
        "pushed_at": pushed_at,
        "created_at": pushed_at,
    }


def _skill_md(name: str, stage: str) -> str:
    return f"# {name}\n\n解决播客流程里的{stage}。\n"


class SkillFinderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.now = datetime(2026, 9, 12, tzinfo=timezone.utc)
        self.fresh = "2026-08-20T00:00:00Z"
        self.stale = "2024-01-01T00:00:00Z"

    def _complete(self, prompt: str) -> str:
        if "打包结果" in prompt:
            ids = [
                "acme/podcast-topic",
                "acme/podcast-script",
                "acme/podcast-record",
                "acme/podcast-edit",
                "acme/podcast-cover",
                "acme/podcast-publish",
            ]
            body = "从零做播客。地图：选题到发布。\n" + "\n".join(
                f"{item} 用于对应阶段" for item in ids
            )
            for item in ids:
                self.assertIn(item, prompt)
            return json.dumps(
                {"title": "从零做播客技能包", "body": body + "\nAIGC"},
                ensure_ascii=False,
            )
        return _coverage_json()

    def _github_get(self, url: str, *, gap_first_pass: bool = True) -> object:
        parsed = urlparse(url)
        if parsed.netloc == "api.github.com" and parsed.path == "/search/repositories":
            query = parse_qs(parsed.query).get("q", [""])[0]
            if "stale-empty" in query:
                return {
                    "items": [
                        _repo_item(
                            "old/stale-empty",
                            stars=0,
                            description="empty shell",
                            pushed_at=self.stale,
                        )
                    ]
                }
            if "封面" in query or "cover art" in query:
                if gap_first_pass and "claude skill" not in query and "filename:SKILL.md" not in query:
                    return {"items": []}
                return {
                    "items": [
                        _repo_item(
                            "acme/podcast-cover",
                            stars=42,
                            description="播客封面 skill",
                            pushed_at=self.fresh,
                        )
                    ]
                }
            mapping = (
                ("选题", "acme/podcast-topic", "播客选题"),
                ("topic", "acme/podcast-topic", "播客选题"),
                ("脚本", "acme/podcast-script", "播客脚本"),
                ("script", "acme/podcast-script", "播客脚本"),
                ("录音", "acme/podcast-record", "播客录音"),
                ("recording", "acme/podcast-record", "播客录音"),
                ("剪辑", "acme/podcast-edit", "播客剪辑"),
                ("edit", "acme/podcast-edit", "播客剪辑"),
                ("发布", "acme/podcast-publish", "播客发布"),
                ("publish", "acme/podcast-publish", "播客发布"),
            )
            for needle, full_name, desc in mapping:
                if needle in query:
                    return {
                        "items": [
                            _repo_item(
                                full_name,
                                stars=80,
                                description=desc,
                                pushed_at=self.fresh,
                            )
                        ]
                    }
            return {"items": []}
        if "anthropics/skills" in url or "topic:claude-code-skill" in url or "topic:agent-skills" in url:
            raise RuntimeError("github_fetch_failed:optional-root")
        if "raw.githubusercontent.com" in url or "/contents/" in url:
            if "stale-empty" in url:
                raise RuntimeError("github_fetch_failed:missing-skill")
            for full_name, stage in (
                ("acme/podcast-topic", "选题"),
                ("acme/podcast-script", "脚本"),
                ("acme/podcast-record", "录音"),
                ("acme/podcast-edit", "剪辑"),
                ("acme/podcast-cover", "封面"),
                ("acme/podcast-publish", "发布"),
            ):
                if full_name in url:
                    return _skill_md(full_name.split("/", 1)[1], stage)
            raise RuntimeError("github_fetch_failed:unknown")
        raise RuntimeError(f"github_fetch_failed:{url}")

    def test_coverage_decompose_and_second_pass_fills_gap(self) -> None:
        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        self.assertGreaterEqual(len(result["stages"]), 6)
        cover = next(stage for stage in result["stages"] if stage["id"] == "cover")
        self.assertFalse(cover.get("gap"))
        names = {str(skill["source_id"]) for skill in result["skills"]}
        self.assertIn("acme/podcast-cover", names)
        self.assertIn("acme/podcast-topic", names)

    def test_quality_gate_drops_zero_star_stale_without_skill_md(self) -> None:
        hit = {
            "name": "stale-empty",
            "source_id": "old/stale-empty",
            "stars": 0,
            "pushed_at": self.stale,
            "skill_md": "",
            "skill_path": "",
            "url": "https://github.com/old/stale-empty",
            "registry": False,
        }
        self.assertFalse(passes_quality(hit, now=self.now))
        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        ids = {str(skill["source_id"]) for skill in result["skills"]}
        self.assertNotIn("old/stale-empty", ids)

    def test_package_article_contains_every_source_id(self) -> None:
        result = find_skills(
            "从零做播客",
            complete=self._complete,
            github_get=lambda url: self._github_get(url, gap_first_pass=True),
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
        )
        body = str(result["article"]["body"])
        for skill in result["skills"]:
            self.assertIn(str(skill["source_id"]), body)
            self.assertIn(str(skill["name"]), body)
        package = Path(str(result["package_path"]))
        self.assertTrue((package / "index.json").is_file())
        self.assertTrue((package / "images").is_dir())

    def test_llm_missing_raises_skill_search_failed(self) -> None:
        with self.assertRaises(LLMError) as caught:
            find_skills(
                "从零做播客",
                complete=None,
                github_get=lambda _url: {"items": []},
                web_search=lambda _query: [],
                now=self.now,
                output_root=self.root / "skills",
            )
        self.assertEqual("skill_search_failed", caught.exception.code)
        self.assertFalse(any(self.root.rglob("index.json")))

    def test_network_budget_caps_http_instead_of_crawling_every_repo(self) -> None:
        calls: list[str] = []

        def getter(url: str) -> object:
            calls.append(url)
            if "api.github.com/search/repositories" in url:
                return {
                    "items": [
                        _repo_item(
                            f"flood/repo-{index}",
                            stars=50,
                            description="generic skill",
                            pushed_at=self.fresh,
                        )
                        for index in range(10)
                    ]
                }
            if "raw.githubusercontent.com" in url or "/contents/" in url:
                return "# flood\n\nskill\n"
            return {"full_name": "flood/repo-0"}

        def complete(prompt: str) -> str:
            if "打包结果" in prompt:
                return json.dumps(
                    {"title": "预算内技能包", "body": "收录来源见列表。\nAIGC"},
                    ensure_ascii=False,
                )
            return _coverage_json()

        result = find_skills(
            "从零做播客",
            complete=complete,
            github_get=getter,
            web_search=lambda _query: [],
            now=self.now,
            output_root=self.root / "skills",
            max_fetches=18,
            fetch_deadline_seconds=30,
        )
        self.assertLessEqual(len(calls), 18)
        self.assertTrue(result["stages"])


class SkillCoverTests(unittest.TestCase):
    def test_cover_html_is_three_by_four_dazibao(self) -> None:
        html = skill_cover_html(
            title="从零做播客技能包",
            theme="播客从选题到上线",
            count=6,
            stages=["选题", "脚本", "录音", "剪辑", "封面", "发布"],
        )
        self.assertIn(f"{COVER_WIDTH}px", html)
        self.assertIn(f"{COVER_HEIGHT}px", html)
        self.assertEqual(1080, COVER_WIDTH)
        self.assertEqual(1440, COVER_HEIGHT)
        self.assertIn("#3d2b1f", html)
        self.assertIn("Songti", html)
        self.assertIn("SKILL 查找器", html)
        self.assertIn("从零做播客技能包", html)
        self.assertNotIn("9:16", html)

    def test_render_skill_cover_uses_injected_screenshot_size(self) -> None:
        from autoposting.skill_cover import render_skill_cover

        seen: dict[str, object] = {}

        def fake_shot(html_path: Path, png_path: Path, width=None, height=None) -> Path:
            seen["width"] = width
            seen["height"] = height
            text = html_path.read_text(encoding="utf-8")
            self.assertIn("1080px", text)
            self.assertIn("1440px", text)
            png_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
            return png_path

        payload = render_skill_cover(
            title="从零做播客技能包",
            theme="播客从选题到上线",
            count=6,
            stages=["选题", "脚本"],
            screenshot_fn=fake_shot,
        )
        self.assertTrue(payload.startswith(b"\x89PNG"))
        self.assertEqual(1080, seen["width"])
        self.assertEqual(1440, seen["height"])


class SkillFinderApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.db = Database(self.root / "autoposting.db")
        self.db.initialize()
        self.sources = (
            Source("lab_blog", "AI Lab", "rss", "https://lab.example/feed.xml", "S1", ("models",), True, 15),
        )
        for source in self.sources:
            self.db.upsert_source(source)
        self.app = WebApp(
            self.db,
            self.sources,
            self.root / "packages",
            fetcher=lambda _: b"",
            page_fetcher=lambda _: b"",
        )
        self.server = create_server(self.app, "127.0.0.1", 0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.temp_dir.cleanup()

    def _request(self, method: str, path: str, payload: object = None) -> tuple[int, dict[str, object]]:
        body = None
        headers = {}
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.base_url + path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read().decode("utf-8"))

    def test_search_rejects_empty_query(self) -> None:
        status, payload = self._request("POST", "/api/skills/search", {"query": ""})
        self.assertEqual(400, status)
        self.assertFalse(payload["ok"])

    def test_search_returns_502_when_llm_missing(self) -> None:
        status, payload = self._request("POST", "/api/skills/search", {"query": "从零做播客"})
        self.assertEqual(502, status)
        self.assertEqual("skill_search_failed", payload["error"])
        self.assertTrue(payload.get("error_code"))

    def test_image_aspect_ratio_stays_nine_sixteen(self) -> None:
        self.assertEqual("9:16", IMAGE_ASPECT_RATIO)


if __name__ == "__main__":
    unittest.main()
