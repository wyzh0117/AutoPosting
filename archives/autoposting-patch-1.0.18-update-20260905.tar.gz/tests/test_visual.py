import json
import tempfile
import unittest
from pathlib import Path

from autoposting.visual.pipeline import (
    PNG_HEIGHT,
    PNG_WIDTH,
    render_examples,
    render_page,
)
from autoposting.visual.rules import apply_project_rules, apply_ranking_rules, format_compact_number
from autoposting.visual.schema import ContentValidationError, load_example, validate_content
from autoposting.visual.tokens import load_tokens, resolve_tokens, token


class DesignTokenTests(unittest.TestCase):
    def test_canvas_is_fixed_3_by_4(self) -> None:
        tokens = load_tokens()
        self.assertEqual(1080, tokens["canvas"]["width"])
        self.assertEqual(1440, tokens["canvas"]["height"])
        self.assertEqual("3:4", tokens["canvas"]["aspect"])
        self.assertEqual(1080, PNG_WIDTH)
        self.assertEqual(1440, PNG_HEIGHT)
        self.assertEqual("#0B0D12", token("color.background"))
        self.assertEqual(16, token("radius.card"))
        self.assertEqual(100, tokens["typography"]["h1"]["size"])
        self.assertEqual(58, tokens["typography"]["h2"]["size"])

    def test_light_theme_switches_surface_group(self) -> None:
        dark = resolve_tokens("dark")
        light = resolve_tokens("light")
        self.assertEqual("#0B0D12", dark["color"]["background"])
        self.assertNotEqual(dark["color"]["background"], light["color"]["background"])
        self.assertNotEqual(dark["color"]["text"]["primary"], light["color"]["text"]["primary"])
        html = render_page(load_example("ranking"), screenshot=False, tokens=light)["html_text"]
        self.assertIn(light["color"]["background"], html)

    def test_palette_overrides_main_secondary_accent(self) -> None:
        tokens = resolve_tokens(
            "dark",
            {"main": "#112233", "secondary": "#334455", "accent": "#FF6600"},
        )
        self.assertEqual("#112233", tokens["color"]["background"])
        self.assertEqual("#334455", tokens["color"]["surface"])
        self.assertEqual("#FF6600", tokens["color"]["primary"])
        self.assertEqual("#FF6600", tokens["color"]["progressFill"])
        html = render_page(load_example("ranking"), screenshot=False, tokens=tokens)["html_text"]
        self.assertIn("#112233", html)
        self.assertIn("#FF6600", html)


class ContentSchemaTests(unittest.TestCase):
    def test_example_ranking_validates(self) -> None:
        payload = load_example("ranking")
        validate_content("ranking", payload)
        self.assertEqual("ranking-overview", payload["page"])
        self.assertGreaterEqual(len(payload["items"]), 3)
        self.assertNotIn("agency-agents", json.dumps(load_tokens()))

    def test_example_project_validates(self) -> None:
        payload = load_example("project")
        validate_content("project", payload)
        self.assertEqual("agency-agents", payload["name"])
        self.assertIsInstance(payload["features"], list)

    def test_missing_title_is_rejected(self) -> None:
        payload = dict(load_example("ranking"))
        payload.pop("title")
        with self.assertRaises(ContentValidationError):
            validate_content("ranking", payload)


class RenderingRuleTests(unittest.TestCase):
    def test_compact_number_and_progress(self) -> None:
        self.assertEqual("11k", format_compact_number(11000))
        payload = apply_ranking_rules(
            {
                "page": "ranking-overview",
                "brand": "AutoPosting",
                "series": "GitHub 本周爆火 AI 项目榜",
                "issue": "第1期",
                "dateRange": "2026-09-01 — 2026-09-07",
                "title": "GitHub",
                "subtitle": "本周爆火 AI 项目榜",
                "items": [
                    {
                        "rank": 1,
                        "name": "alpha",
                        "description": "d",
                        "metric": {"label": "Stars", "value": 20000},
                    },
                    {
                        "rank": 2,
                        "name": "beta",
                        "description": "d",
                        "metric": {"label": "Stars", "value": 10000},
                    },
                ],
                "tags": [],
            }
        )
        self.assertEqual("20k", payload["items"][0]["metric"]["display"])
        self.assertAlmostEqual(1.0, payload["items"][0]["progress"])
        self.assertAlmostEqual(0.5, payload["items"][1]["progress"])

    def test_drops_items_beyond_ten_and_clips_long_copy(self) -> None:
        items = [
            {
                "rank": index + 1,
                "name": "n",
                "description": "这是一句会被裁切的非常长的项目介绍" * 6,
                "metric": {"label": "Stars", "value": 100 - index},
            }
            for index in range(12)
        ]
        payload = apply_ranking_rules(
            {
                "page": "ranking-overview",
                "brand": "B",
                "series": "S",
                "issue": "1",
                "dateRange": "d",
                "title": "T",
                "subtitle": "U",
                "items": items,
                "tags": [],
            }
        )
        self.assertEqual(10, len(payload["items"]))
        self.assertLessEqual(len(payload["items"][0]["description"]), 42)

    def test_project_rules_format_url_and_features(self) -> None:
        payload = apply_project_rules(
            {
                "page": "project-detail",
                "brand": "AutoPosting",
                "series": "S",
                "issue": "1",
                "pageNumber": "02 / 11",
                "rank": 1,
                "category": "AI Agent / 多智能体",
                "name": "agency-agents",
                "tagline": "把一个 AI 团队塞进电脑里",
                "keyMessage": "将多个不同职责的 AI Agent 组织成协作团队。",
                "features": ["a", "b", "c", "d", "e", "f", "g"],
                "workflow": ["接任务", "分工", "协作", "反馈"],
                "audience": ["研究者"],
                "url": "https://github.com/example/agency-agents/tree/main/very/long/path",
                "metrics": [{"label": "Stars", "value": 11000}],
            }
        )
        self.assertEqual(5, len(payload["features"]))
        self.assertEqual("11k", payload["metrics"][0]["display"])
        self.assertTrue(payload["urlDisplay"].endswith("…") or "github.com" in payload["urlDisplay"])


class HtmlRendererTests(unittest.TestCase):
    def test_ranking_html_uses_tokens_and_components(self) -> None:
        html = render_page(load_example("ranking"), screenshot=False)["html_text"]
        self.assertIn("c-brand-header", html)
        self.assertIn("c-ranking-item", html)
        self.assertIn("c-progress-bar", html)
        self.assertIn("--color-background", html)
        self.assertIn("#0B0D12", html)
        self.assertIn("GitHub", html)
        self.assertIn("本周爆火 AI 项目榜", html)
        self.assertIn("agency-agents", html)
        self.assertIn("1080px", html)
        self.assertIn("1440px", html)

    def test_project_html_contains_required_blocks(self) -> None:
        html = render_page(load_example("project"), screenshot=False)["html_text"]
        self.assertIn("c-quote-card", html)
        self.assertIn("c-feature-list", html)
        self.assertIn("c-bullet-panel", html)
        self.assertNotIn("c-bullet-featured", html)
        self.assertIn("agency-agents", html)
        self.assertIn("把一个 AI 团队塞进电脑里", html)
        self.assertIn("一句话看懂", html)
        self.assertIn("做什么", html)
        self.assertIn("如何实现", html)
        self.assertIn("适合哪些人群", html)
        self.assertIn("使用场景", html)
        self.assertIn("c-project-shell", html)
        self.assertIn("c-project-pair", html)
        self.assertIn("c-masthead", html)
        self.assertIn("c-masthead-logo", html)
        self.assertIn("c-feature-icon", html)
        self.assertIn("<svg", html)
        self.assertIn(".c-masthead-logo .c-project-logo", html)
        self.assertIn("border: none", html)
        body = html.split("<body>", 1)[-1]
        self.assertNotIn("c-hero-visual", body)
        self.assertNotIn("c-story", body)
        self.assertNotIn("功能示意", body)
        self.assertNotIn("c-metric-panel", body)
        self.assertNotIn("c-workflow", body)
        self.assertLess(body.find("一句话看懂"), body.find("做什么"))
        self.assertLess(body.find("做什么"), body.find("如何实现"))
        self.assertLess(body.find("如何实现"), body.find("适合哪些人群"))
        self.assertLess(body.find("适合哪些人群"), body.find("使用场景"))
        self.assertNotIn("开源仓库，安装步骤和文档在项目主页", html)
        self.assertNotIn("max-height: 36%", html)
        self.assertRegex(html, r"\.c-project-shell \{[^}]*justify-content: center")
        self.assertRegex(html, r"\.c-project-pair \{[^}]*grid-template-columns: 1fr 1fr")
        self.assertRegex(html, r"\.c-bullet-panel \{[^}]*height: auto")

    def test_audience_and_scene_use_title_icons_not_row_icons(self) -> None:
        html = render_page(load_example("project"), screenshot=False)["html_text"]
        body = html.split("<body>", 1)[-1]
        panels = _bullet_panels(body)
        self.assertIn("做什么？", panels)
        self.assertIn("适合哪些人群", panels)
        self.assertIn("使用场景", panels)
        self.assertIn("c-feature-icon", panels["做什么？"]["items"])
        self.assertIn("<svg", panels["适合哪些人群"]["title"])
        self.assertIn("<svg", panels["使用场景"]["title"])
        self.assertNotEqual(panels["适合哪些人群"]["title"], panels["使用场景"]["title"])
        self.assertNotIn("c-feature-icon", panels["适合哪些人群"]["items"])
        self.assertNotIn("c-feature-icon", panels["使用场景"]["items"])
        self.assertIn("<li><span>", panels["适合哪些人群"]["items"])
        self.assertIn("<li><span>", panels["使用场景"]["items"])
        self.assertNotIn("  ", panels["适合哪些人群"]["items"])


class MarkCatalogTests(unittest.TestCase):
    def test_github_avatar_is_not_a_product_logo(self) -> None:
        from autoposting.visual.marks import is_author_avatar

        self.assertTrue(is_author_avatar("https://github.com/acme.png"))
        self.assertTrue(is_author_avatar("https://avatars.githubusercontent.com/u/12?v=4"))
        self.assertFalse(
            is_author_avatar("https://raw.githubusercontent.com/acme/tool/HEAD/docs/logo.png")
        )

    def test_catalog_reuses_tagged_svg_and_skips_stretched_tags(self) -> None:
        from autoposting.visual.marks import resolve_mark

        temp = Path(tempfile.mkdtemp())
        self.addCleanup(lambda: __import__("shutil").rmtree(temp, ignore_errors=True))
        first = resolve_mark(
            name="agency-agents",
            kind="Agent",
            topics=["agent", "multi-agent"],
            description="把不同 AI 角色组成团队",
            catalog_dir=temp,
        )
        self.assertTrue(first["svg"].lstrip().startswith("<svg"))
        self.assertIn("agent", first["tags"])
        self.assertNotIn("rag", first["tags"])
        second = resolve_mark(
            name="crew-lite",
            kind="Agent",
            topics=["agent"],
            description="多个助手一起协作",
            catalog_dir=temp,
        )
        self.assertEqual(first["id"], second["id"])
        self.assertEqual(first["svg"], second["svg"])
        cli = resolve_mark(
            name="fast-cli",
            kind="CLI",
            topics=["cli"],
            description="在终端里调用模型",
            catalog_dir=temp,
        )
        self.assertNotEqual(first["id"], cli["id"])
        self.assertNotIn("agent", cli["tags"])
        self.assertIn("cli", cli["tags"])


class PosterCopyTests(unittest.TestCase):
    def test_generic_install_line_is_not_the_one_liner(self) -> None:
        from autoposting.visual.adapter import project_from_repo

        payload = project_from_repo(
            {
                "rank": 1,
                "name": "agency-agents",
                "kind": "Agent",
                "description": "把前端、运营、内容等 AI 角色组成一个小团队。",
                "summary": "把前端、运营、内容等 AI 角色组成一个小团队。",
                "does": "组织前端、运营、内容、社区等不同角色一起协作",
                "how": "开源仓库，安装步骤和文档在项目主页。",
                "scene": "本地把开发、内容和运营串成一条流水线",
                "icon_url": "https://github.com/acme.png",
                "url": "https://github.com/acme/agency-agents",
                "stars": 11000,
            }
        )
        self.assertNotIn("项目主页", payload["keyMessage"])
        self.assertNotIn("安装步骤", payload["keyMessage"])
        self.assertFalse(payload["keyMessage"].startswith("它"))
        self.assertIn("给", payload["keyMessage"])
        self.assertFalse(payload.get("tagline"))
        self.assertFalse(payload.get("logo"))
        self.assertGreaterEqual(len(payload["features"]), 2)
        self.assertTrue(all(len(item) <= 36 for item in payload["features"]))
        self.assertTrue(payload["how"])
        self.assertNotIn("项目主页", " ".join(payload["how"]))
        self.assertGreaterEqual(len(payload["scene"]), 1)
        self.assertGreaterEqual(len(payload["audience"]), 1)

    def test_long_does_becomes_short_bullets(self) -> None:
        from autoposting.visual.adapter import to_bullets

        items = to_bullets("组织前端角色，安排运营写内容，让社区机器人和开发助手一起协作")
        self.assertGreaterEqual(len(items), 2)
        self.assertTrue(all(len(item) <= 36 for item in items))

    def test_space_separated_cjk_becomes_one_item_per_line(self) -> None:
        from autoposting.visual.adapter import project_from_repo, to_bullets

        items = to_bullets("做架构设计的人 写技术文档的人 要快速上手的人")
        self.assertEqual(
            ["做架构设计的人", "写技术文档的人", "要快速上手的人"],
            items,
        )
        payload = project_from_repo(
            {
                "rank": 1,
                "name": "agency-agents",
                "kind": "Agent",
                "audience": "做架构设计的人 写技术文档的人 要快速上手的人",
                "scene": "本地把开发、内容和运营串成一条流水线 先用一个真实任务看完整协作",
            }
        )
        self.assertEqual(
            ["做架构设计的人", "写技术文档的人", "要快速上手的人"],
            payload["audience"],
        )
        self.assertTrue(all(" " not in item for item in payload["audience"]))
        self.assertGreaterEqual(len(payload["scene"]), 2)
        self.assertTrue(all(" " not in item for item in payload["scene"]))

    def test_to_bullets_does_not_invent_ellipsis(self) -> None:
        from autoposting.visual.adapter import to_bullets

        items = to_bullets("给不会命令行的同事把复杂操作收成按钮并当场演示带动效的页面")
        self.assertTrue(items)
        self.assertTrue(all("…" not in item and "..." not in item for item in items))
        self.assertTrue(any("带动效" in item for item in items))

    def test_clipped_ellipsis_lines_are_dropped(self) -> None:
        from autoposting.visual.adapter import project_from_repo, to_bullets

        self.assertEqual([], to_bullets("做带动效的演…"))
        payload = project_from_repo(
            {
                "rank": 1,
                "name": "demo-webui",
                "kind": "WebUI",
                "scene": "做带动效的演…\n给不会命令行的同事试用",
            }
        )
        self.assertTrue(payload["scene"])
        self.assertTrue(all("…" not in item and "..." not in item for item in payload["scene"]))
        self.assertTrue(any("同事" in item or "命令行" in item for item in payload["scene"]))

    def test_kind_does_fallback_uses_complete_sentences(self) -> None:
        from autoposting.visual.adapter import KIND_DOES, project_from_repo

        payload = project_from_repo(
            {
                "rank": 1,
                "name": "archify",
                "kind": "Agent",
                "description": "Agent skill for architecture.",
                "does": "Agent skill for beautiful architecture",
            }
        )
        self.assertGreaterEqual(len(payload["features"]), 3)
        self.assertTrue(all(item.endswith("。") for item in payload["features"]))
        self.assertTrue(all(len(item) >= 16 for item in payload["features"]))
        self.assertTrue(all(item.endswith("。") for item in KIND_DOES["Agent"]))

    def test_four_panel_kind_copy_does_not_lead_with_it(self) -> None:
        from autoposting.visual.adapter import KIND_AUDIENCE, KIND_DOES, KIND_HOW, KIND_SCENE

        banned = ("它", "这个工具")
        for table in (KIND_DOES, KIND_HOW, KIND_AUDIENCE, KIND_SCENE):
            for kind, items in table.items():
                for item in items:
                    lead = str(item).lstrip()
                    self.assertFalse(
                        lead.startswith(banned),
                        f"{kind} {item!r} starts with 它-style subject",
                    )

    def test_it_led_does_falls_back_to_kind_copy(self) -> None:
        from autoposting.visual.adapter import project_from_repo

        payload = project_from_repo(
            {
                "rank": 1,
                "name": "agency-agents",
                "kind": "Agent",
                "does": "它把不同职责的角色编成一支小团队。\n它帮你把任务交给下一位。",
            }
        )
        self.assertTrue(payload["features"])
        self.assertTrue(all(not item.lstrip().startswith("它") for item in payload["features"]))
        self.assertTrue(any("角色" in item or "助手" in item for item in payload["features"]))

    def test_english_does_falls_back_to_chinese_kind_bullets(self) -> None:
        from autoposting.visual.adapter import project_from_repo, to_bullets

        self.assertEqual([], to_bullets("Agent skill for beautiful, verifiable architecture"))
        payload = project_from_repo(
            {
                "rank": 1,
                "name": "archify",
                "kind": "Agent",
                "description": "Agent skill for beautiful, verifiable architecture.",
                "summary": "它可以帮你把不同的 AI 角色组织起来一起干活，而不是只会聊天。",
                "does": "Agent skill for beautiful\nverifiable architecture\nworkflow",
                "how": "先定角色和各自职责",
                "scene": "本地把开发、内容和运营串成一条流水线",
                "icon_url": "https://github.com/tt-a1i.png",
            }
        )
        self.assertTrue(payload["features"])
        self.assertTrue(all("architecture" not in item.lower() for item in payload["features"]))
        self.assertTrue(any("角色" in item or "任务" in item for item in payload["features"]))
        self.assertFalse(payload.get("tagline"))
        self.assertFalse(payload["keyMessage"].startswith("它"))

    def test_render_weekly_visual_cache_busts_image_url(self) -> None:
        from autoposting.visual.weekly import render_weekly_visual

        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        out = Path(temp.name) / "github-weekly"
        rendered = render_weekly_visual(
            [
                {
                    "rank": 1,
                    "name": "demo-cli",
                    "kind": "CLI",
                    "owner": "",
                    "summary": "它可以帮你在终端里直接调用 AI，少绕一层界面。",
                    "does": "A tiny LLM CLI agent.",
                    "how": "装到本机命令行",
                    "description": "A tiny LLM CLI agent.",
                    "url": "https://github.com/acme/demo-cli",
                }
            ],
            [{"id": "01-demo-cli", "kind": "poster", "rank": 1, "title": "demo-cli"}],
            out,
            screenshot=False,
        )
        self.assertTrue(rendered[0].get("url"))
        self.assertIn("?v=", str(rendered[0]["url"]))
        html = (out / "01-demo-cli.html").read_text(encoding="utf-8")
        self.assertIn("做什么？", html)
        self.assertNotIn("tiny LLM CLI", html)
        self.assertIn("终端", html)


class FeatureIconTests(unittest.TestCase):
    def test_mixed_panel_bullets_use_distinct_glyphs(self) -> None:
        from autoposting.visual.icons import feature_icon

        labels = [
            "把不同职责的助手编成一支能一起干活的小团队。",
            "在终端里直接跟模型说话，不必再绕一层网页。",
            "把文档放进去之后，可以用大白话追问里面写了什么。",
            "用几行代码把 AI 接到自己的程序里。",
            "把 AI 能力收成网页上的按钮，打开就能用。",
            "把模型在自己的机器上跑起来、试起来。",
            "提供能直接练、能直接评的样本。",
            "把 AI 接到已经在用的工具里，不用换窗口。",
        ]
        glyphs = [_icon_glyph(feature_icon(label, f"panel-{index}")) for index, label in enumerate(labels)]
        self.assertGreaterEqual(len(set(glyphs)), 6)

    def test_generic_fallback_glyphs_vary_by_seed(self) -> None:
        from autoposting.visual.icons import feature_icon

        first = _icon_glyph(feature_icon("暂无匹配关键词的句子。", "做什么？-0"))
        second = _icon_glyph(feature_icon("暂无匹配关键词的句子。", "做什么？-1"))
        self.assertNotEqual(first, second)


def _bullet_panels(html: str) -> dict[str, dict[str, str]]:
    import re

    found: dict[str, dict[str, str]] = {}
    for title, items in re.findall(
        r'<section class="c-panel c-bullet-panel[^"]*"><h3>(.*?)</h3>'
        r'<ul class="c-feature-list">(.*?)</ul></section>',
        html,
        flags=re.S,
    ):
        label = "".join(re.sub(r"<[^>]+>", "", title).split())
        found[label] = {"title": title, "items": items}
    return found


def _icon_glyph(svg: str) -> str:
    marker = 'stroke-width="1.4" opacity="0.55"/>'
    return svg.split(marker, 1)[-1].replace("</svg>", "").strip()


class StoryExtractTests(unittest.TestCase):
    def test_readme_images_become_snake_beats(self) -> None:
        from autoposting.visual.story import extract_story_beats, snake_rows

        readme = """
# Tool
Intro paragraph.

## Install
![install](docs/install.png)

Then you run the agent.

## Workflow
<img src="https://example.com/flow.webp">

![build](https://img.shields.io/badge/build-ok)
"""
        beats = extract_story_beats(readme, owner="acme", repo="tool")
        self.assertEqual(2, len(beats))
        self.assertIn("raw.githubusercontent.com/acme/tool/HEAD/docs/install.png", beats[0]["image"])
        self.assertEqual("https://example.com/flow.webp", beats[1]["image"])
        rows = snake_rows(list("ABCD"))
        self.assertEqual([["A", "B"], ["D", "C"]], rows)


class ExamplePngTests(unittest.TestCase):
    def test_examples_write_html_and_9_by_16_png(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        results = render_examples(Path(temp.name), screenshot=True)
        self.assertEqual(["ranking-overview", "project-detail"], [row["page"] for row in results])
        for row in results:
            html_path = Path(row["html"])
            png_path = Path(row["png"])
            self.assertTrue(html_path.is_file())
            self.assertTrue(png_path.is_file())
            self.assertGreater(png_path.stat().st_size, 20_000)
            width, height = _png_size(png_path)
            self.assertEqual((PNG_WIDTH, PNG_HEIGHT), (width, height))


class StyleBibleCompatTests(unittest.TestCase):
    def test_style_md_still_feeds_image_model_jobs(self) -> None:
        from autoposting.image_gen import build_weekly_image_jobs, load_image_prompt

        style = load_image_prompt("style")
        self.assertIn("9:16", style)
        self.assertIn("Dark Technology", style)
        jobs = build_weekly_image_jobs(
            [{"rank": 1, "name": "demo", "summary": "s", "does": "d", "scene": "sc", "kind": "CLI"}]
        )
        self.assertTrue(all(style in job["prompt"] for job in jobs))


def _png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a png: {path}")
    return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
